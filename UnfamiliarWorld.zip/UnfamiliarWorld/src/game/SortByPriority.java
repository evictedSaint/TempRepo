package game;

import java.util.Comparator;
import java.util.HashMap;

public class SortByPriority implements Comparator<String> {
 	HashMap<String, Faction> factions = new HashMap<String, Faction>();
	public SortByPriority( HashMap<String, Faction> factions) {
		this.factions = factions;
	}

	@Override
	public int compare(String f1, String f2) {
		Faction F1 = factions.get(f1);
		Faction F2 = factions.get(f2);
		if (F1.getPriority() < F2.getPriority()) return -1;
		else if (F1.getPriority() == F2.getPriority()) return 0;
		else return 1;
	}
}