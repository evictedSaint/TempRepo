package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.imageio.ImageIO;

/** This class is primarily used to keep factions, techs, improvements, and territories as global variables.  Game objects shouldn't really ever be created.
 * 
 */
public class Game  {
	
	public static boolean debug = false;
	
	protected static Map map = new Map();
	//  
	protected static HashMap<String, Faction> factions = new HashMap<String, Faction>();
	protected static HashMap<String, Tech> techs = new HashMap<String, Tech>();
	protected static HashMap<String, Improvement> improvements = new HashMap<String, Improvement>();
	protected static HashMap<String, Territory> territories = new HashMap<String, Territory>();
	
	public Game() {
		
	}

	
	
	public static Map getMap() {
		return map;
	}
	public static void setMap(Map map) {
		Game.map = map;
	}
	public static HashMap<String, Faction> getFactions() {
		return factions;
	}
	public static Faction getFaction(String faction) {
		return factions.get(faction);
	}
	public static HashMap<String, Tech> getTechs() {
		return techs;
	}
	public static Tech getTech(String tech) {
		return techs.get(tech);
	}
	public static HashMap<String, Improvement> getImprovements() {
		return improvements;
	}
	public static Improvement getImprovement(String improvement) {
		return improvements.get(improvement);
	}
	public static HashMap<String, Territory> getTerritories() {
		return territories;
	}
	public static Territory getTerritory(String territory) {
		return territories.get(territory);
	}
}
