package game;

import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Queue;
import java.util.Set;

public class Territory implements Serializable {
	
	private String ID = "";
	private String regex = "";
	private int xCoord = 0;
	private int yCoord = 0;
	
	private HashMap<String, Boolean> improvements = new HashMap<String, Boolean>();
	
	private boolean launchedAirstrike = false;
	private boolean launchedNukeMissile = false;
	private List<String> connectedTerritoriesList = new ArrayList<String>();
	private List<String> connectedChokepointList = new ArrayList<String>();
	private List<String> connectedImpassableList = new ArrayList<String>();
	private HashMap<String, Integer> allDistances = new HashMap<String, Integer>();
	private int fallout = 0;
	private int interceptions = 0;
	
	public Territory() {
	}
	
	public void populateImprovements(HashMap<String, Improvement> improvements) {
		for (String improvement : improvements.keySet()) {
			this.improvements.put(improvement, false);
		}
	}
	
	public void addImprovement(String improvement) {
		this.improvements.put(improvement,  true) ;
	}
	
	public void removeImprovement(String improvement) {
		this.improvements.put(improvement,  false) ;
	}
	
	public boolean hasImprovement(String improvement) {
		return this.improvements.get(improvement) ;
	}
	
	public HashMap<String, Boolean> getImprovements() {
		return this.improvements;
	}
	
	public String getID() {
		return ID;}
	
	public void setID(String ID) {
		this.ID = ID;}	
	
	public String getRegex() {
		return regex;}

	public void setRegex(String regex) {
		this.regex = regex;}

	public int getxCoord() {
		return xCoord;}

	public void setxCoord(int xCoord) {
		this.xCoord = xCoord;}

	public int getyCoord() {
		return yCoord;}

	public void setyCoord(int yCoord) {
		this.yCoord = yCoord;}

	
	
	public boolean isLaunchedAirstrike() {
		return launchedAirstrike;
	}

	public void setLaunchedAirstrike(boolean launchedAirstrike) {
		this.launchedAirstrike = launchedAirstrike;
	}

	
	
	public boolean isLaunchedNukeMissile() {
		return launchedNukeMissile;
	}

	public void setLaunchedNukeMissile(boolean launchedNukeMissile) {
		this.launchedNukeMissile = launchedNukeMissile;
	}

	public void setDistanceMap(HashMap<String, Territory> territoriesMap) {
		this.allDistances = computeAllDistances(this.ID, territoriesMap);
	}
	
	public HashMap<String, Integer> getDistanceMap() {
		return this.allDistances;
	}
	
	public Set<String> getAllWithinDistance(int distance) {
		Set<String> territoriesWithinDistance = new HashSet<String>();
		for (String territory : this.allDistances.keySet()) {
			if (getDistanceToTarget(territory) <= distance) {
				territoriesWithinDistance.add(territory);
			}
		}		
		return territoriesWithinDistance;
	}
	
	public Integer getDistanceToTarget(String target) {
		return this.allDistances.get(target);
	}
	
	public HashMap<String, Integer> computeAllDistances(String source, HashMap<String, Territory> territoriesMap) {
	    Queue<String> q = new ArrayDeque<>();
	    HashMap<String, Integer> dist = new HashMap<>();
	    q.add(source);
	    dist.put(source, 0);
	    while (!q.isEmpty()) {
	        Territory cur = territoriesMap.get(q.poll());
	        int curDist = dist.get(cur.getID());
	        for (String neighbor : cur.getConnectedTerritoriesList()) {
	            if (!dist.containsKey(neighbor)) {
	                dist.put(neighbor, curDist + 1);
	                q.add(neighbor);
	            }
	        }
	    }
	    return dist;
	}	
	
	public void setInterceptions(int interceptions) {
		this.interceptions = interceptions;
	}

	public int getInterceptions() {
		return this.interceptions;
	}

	public void resetInterceptions() {
		this.interceptions = 0;}
	
	public void incInterceptions() {
		this.interceptions += 1;}

	public List<String> getConnectedTerritoriesList() {
		return connectedTerritoriesList;}

	public void setConnectedTerritoriesList(List<String> connectedTerritoriesList) {
		this.connectedTerritoriesList = connectedTerritoriesList;}
	
	public void addConnectedTerritory(String connectedTerritory) {
		this.connectedTerritoriesList.add(connectedTerritory);}
	
	public List<String> getConnectedChokepointList() {
		return connectedChokepointList;}

	public void setConnectedChokepointList(List<String> connectedMountainList) {
		this.connectedChokepointList = connectedMountainList;}

	public void addConnectedChokepoint(String connectedTerritory) {
		this.connectedChokepointList.add(connectedTerritory);}
	//
	public List<String> getConnectedImpassableList() {
		return connectedImpassableList;}

	public void setConnectedImpassableList(List<String> connectedImpassableList) {
		this.connectedImpassableList = connectedImpassableList;}

	public void addConnectedImpassable(String connectedTerritory) {
		this.connectedImpassableList.add(connectedTerritory);}
	
	public int getFallout() {
		return fallout;}

	public void setFallout(int fallout) {
		this.fallout = fallout;}
	
	public void addFallout(int fallout) {
		this.fallout = this.fallout + fallout;
	}
}

