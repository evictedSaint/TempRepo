package game;

import java.util.Comparator;

public class SortByImprovementPriority implements Comparator<Improvement> { 	
	
	public SortByImprovementPriority( ) {
	}

	@Override
	public int compare(Improvement i1, Improvement i2) {
		int I1 = i1.getPriority();
		int I2 = i2.getPriority();
		
		if (I1 < I2) return -1;
		else if (I1 == I2) return 0;
		else return 1;
	}
}