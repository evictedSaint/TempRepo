package game;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class CommandParser extends Game {

	
	
 	public static HashMap<String, List<String>> parseCommandBlock(String inputBlock) throws IOException {
 		
 		
		HashMap<String, List<String>> orders = new HashMap<String, List<String>>();
		
		String outputBlock = "";
		String output = "";
		
		//send each line through parseCommand
		BufferedReader bufReaderInput = new BufferedReader(new StringReader(inputBlock));
		String line = null;
		Scanner commandCorrection = new Scanner(System.in);
		String newInput = "";
		
		while((line = bufReaderInput.readLine()) != null) {
			output = parseCommand(line);
			while (Pattern.matches("^Error.*?", output)) {
				System.out.println(output);
				System.out.println("Please input correct command (q to quit): ");
				newInput = commandCorrection.nextLine();
				if (newInput.equals("q")) {output = "";}
				else {output = parseCommand(newInput);}
			}
			outputBlock += output + "\n";				
		}
		commandCorrection.close();
		
		//System.out.println(outputBlock);
		
		//separate out by faction
		BufferedReader bufReaderOutput = new BufferedReader(new StringReader(outputBlock));
		line = null;
		String currentFaction = "";
		while((line = bufReaderOutput.readLine()) != null) {
			if (Pattern.matches("^order.*?", line)) {

				currentFaction = line.split("|")[1];
				orders.put(currentFaction, new ArrayList<String>());
			} else {
				orders.get(currentFaction).add(line);}
		}
		

		
		return orders;
		
	}
	
	
	
	
	/**
	 * parseCommand
	 * 
	 * Processes a player-written command String.  Prefaces String with the command type, followed by relevant information. 
	 * @param inputRaw the raw String of an unparsed player command.
	 * @return
	 */
 	public static String parseCommand(String inputRaw) {
 	
 		//### Figure out how to build regex for improvements/factions/tech/etc only once, rather than every time parsecommand is run.  Faster, more efficient that way.
 		
 		/*
 		 * There are currently thirteen different commands a player can give:
 		 * 
 		 * 1) Change Diplomacy (this covers exchange pacts)
 		 * 2) Change Research
 		 * 3) Prime Transports
 		 * 4) Decommission a Unit or Navy
 		 * 5) Airstrike 
 		 * 6) Nuclear Airstrike
 		 * 7) Nuclear Missilestrike
 		 * 8) Build Improvement
 		 * 9) Give a Technology/Territory 
 		 * 10) Build Units
 		 * 11) Build Navies
 		 * 12) Move Units
 		 * 13) Move Navies
 		 * 
 		 * Note: parseCommand only validates to make sure the command makes sense syntax-wise. For example, a players move order that doesn't
 		 * contain an origin territory will cause the parser to ask the GM to validate the command (with the option to discard the order altogether), 
 		 * but a move order that tries to move a nonexistant unit to a territory out of range will not throw an error.  Commands are instead  
 		 * validated in that manner as they are referenced during the turn.  
 		 * 
 		 * As this method relies pretty heavily on regex to make sense of player text commands, it's possible for errors to occur - ESPECIALLY
 		 * if territory, tech, and faction names are oddly or confusingly named (e.g. The faction "Move Units" gives the order to begin research on 
 		 * the technology "Declare War on France", etc.)  It is up to the GM to perform an initial and final check on the input and results. I've
 		 * tried to make the parser intelligent enough to catch discrepancies in order syntax (players are dumb, after all) but it's by no means
 		 * perfect.
 		 */
 		
 		
		String output = "";

		//###might not be necessary; i think regex has a way to make case irrelevant
		String input = inputRaw.replaceAll("[^A-Za-z0-9\\s]", "").toLowerCase(); 	//all lowercase, only alphanumeric characters
		input = input.replaceAll("\\s{2,}", " ").trim(); 							//this makes sure there are no double spaces
		
		if (input.isEmpty()) {              
			return "";
		}

		
		//Setting up the regex patterns.  Most of these rely on the regex string fields in Faction, Tech, and Improvement, but a few are just hardcoded for now.
		//getting all the faction regex codes piled into one big lump.  I know, it's not elegant. ###Maybe come back and make this more efficient? Have a match automatically pick out the faction?
		String factionRegex = ".*?(";
		for (Faction faction : factions.values()) {
			if (!faction.getRegex().equals("")) {             //make sure it's actually got a regex command
				factionRegex += faction.getRegex() + "|"; 
			}
		}
		factionRegex = factionRegex.substring(0, factionRegex.length() - 1);
		factionRegex += ").*?";
		
		//Research - ###See faction regex note above. Make this more efficent, pick out it's own tech object based on the match?
		//###probably rename researchRegex to techRegex, for uniformity.
		String researchRegex = ".*?(";
		for (Tech tech : techs.values()) {
			if (!tech.getRegex().equals("")) {
				researchRegex += tech.getRegex() + "|";
			}
		}
		researchRegex = researchRegex.substring(0, researchRegex.length() - 1);
		researchRegex += ").*?";
		
		//Research - ###See faction regex note above. Make this more efficent, pick out it's own tech object based on the match?
		String improvementRegex = ".*?(";
		for (Improvement improvement : improvements.values()) {
			if (!improvement.getRegex().equals("")) {
				improvementRegex += improvement.getRegex() + "|"; 
			}
		}
		improvementRegex = improvementRegex.substring(0, improvementRegex.length() - 1);
		improvementRegex += ").*?";
		
		//Territories
		String territoryRegex = ".*?(";
		for (Territory territory : territories.values()) {
			if (!territory.getRegex().equals("")) {
				System.out.println(territory.getID() + ": " + territory.getRegex());
				territoryRegex += territory.getRegex() + "|"; 
			}
		}
		territoryRegex = territoryRegex.substring(0, territoryRegex.length() - 1);
		territoryRegex += ").*?";
		
		//airstrikes - make sure it doesn't include the word nuclear in it.
		String airstrikeRegex = ".*?(?:(?<!nuke|nuclear) ?(?:air|bomb(?:ing)?) ?(?:raid|strike)|(?<!nuke|nuclear) ?bomb).*?";

		//diplomacy - Note: While it does look for synonyms, the only three valid diplomacy stances are "ally, war, neutral"
		String diplomacyRegex = ".*?((?:declare war)|(?:peace)|(?:non ?-? ?aggression)|(?:exchange (?:pact|treaty))|(?:alliance|ally)).*?"; 

		//nuclear airstrike - nukes dropped from planes
		String nukebombRegex = ".*?(?:(?:(?<=nuke|nuclear) ?(?:air|bomb(?:ing)?) ?(?:raid|strike)|(?<=nuke|nuclear) ?bomb)|drop (?:a )?nuke).*?";
		
		//nuclear missilestrike - nukes launched from silos
		String missilestrikeRegex = ".*?(?:(?<=nuke|nuclear)? ?(?:missile|icbm) ?(?:strike)?|launch (?:a )?nuke|(?<=nuke|nuclear) (?:missile )strike).*?";
		
		//because there are so many damn terms for spawning units and navies...
		String unitspawnRegex = ".*?(?:spawn ?(?!point)|build|construct|muster|rally ?(?!point)|raise|pop).*?";
		String armyRegex = ".*?(?:unit|army|troop|men|man).*?";
		String navyRegex = ".*?(?:navy|naval|fleet|ship ?(?!yard)|boat).*?";
		String transportRegex = ".*?(?:prime|prepare|prep|ready).*?";
		String shipRegex = ".*?(?:fleet|ship|boat|armada).*?";
		
		
		//-----
		//### Should probably convert this massive ifelse statement into a case statement.
		
		// get nation
		// We need to actually know who's orders we're parsing right now.  This just swaps the key to the hashmap based on detecting the key phrase "nation" + "orders"
		// It's not particularly robust, since it's assuming the incoming format is correct.  Idk how to make it more robust other than 
		// feeding in player orders one at a time, or maybe stipulating they start each order with their faction name.  Additionally, if there is any 
		// overlap between faction names, or improvements or techs, you run the risk of improperly parsing the order.  It's up the GM to verify valid names.
		// output: "orders|factionname"
		

		
		
		if (Pattern.matches(factionRegex, input) && !Pattern.matches(diplomacyRegex, input) && Pattern.matches(".*?orders.*?", input)) {
			output = "orders|";
			for (Faction faction : factions.values()) {
				Matcher match = Pattern.compile(faction.getRegex()).matcher(input);
				if (match.matches()) {
					output += faction.getFactionName();
					break;
				}
			}
			return output;
		}

		
		//-----
		
		
		
		
		// change diplomacy
		// "diplomacy|factionname|war/peace/alliance/exchange/endexchange"
		else if (Pattern.matches(diplomacyRegex, input) && Pattern.matches(factionRegex, input) && !Pattern.matches(researchRegex, input)) {
			output = "diplomacy|";
			for (Faction faction : factions.values()) {
				Matcher match = Pattern.compile(faction.getRegex()).matcher(input);
				if (match.matches()) {
					output += faction.getFactionName();
					break;
				}
			}
			
			

			Matcher match = Pattern.compile(diplomacyRegex).matcher(input);
			Boolean endChecker = false;
			String diploHolder = "";
			if (match.matches()) {
				if (Pattern.matches(".*?(end|break|terminate).*?", input)) {
					endChecker = true;
				}
				if (match.group(1).equals("aggression")) {diploHolder += "peace"; //because "non-aggression pacts"
				} else {diploHolder += match.group(1); }
				
				if (endChecker == true) {
					if (diploHolder.equals("war")) {
						output += "peace";
					} else if (diploHolder.equals("peace")) {
						output += "war";
					} else if (diploHolder.equals("alliance")|diploHolder.equals("ally")) {
						output += "peace";
					} else if (diploHolder.equals("exchange")) {
						output += "endexchange";
					} else {
						return "Error - Suspected Diplomacy Change Failed: 'ending' something unclear ==> " + input;
					}
				} else {
					
					output += diploHolder;
				}
			}
			return output;
		}
		

		// change research
		// "research|researchName"
		else if (Pattern.matches(researchRegex, input) && !Pattern.matches(factionRegex, input)) {
			output = "research|";
			for (Tech tech : techs.values()) {
				Matcher match = Pattern.compile(tech.getRegex()).matcher(input);
				if (match.matches()) {
					output += tech.getTechName();
					break;
				}
			}
			return output;
		}

		// prime transports
		// "prime - # - territory"
		else if (Pattern.matches(transportRegex, input) && Pattern.matches(shipRegex, input)) {
			output = "prime|";

			String primeRegex = ".*?(?:prime|prepare|prep|ready) ?";
			if (Pattern.matches(primeRegex + "all.*?", input)) {									output += "all|";
			} else if (Pattern.matches(primeRegex + "(?:fleets|ships|boats|armada).*?", input)) {	output += "all|";
			} else if (Pattern.matches(primeRegex + "(?:one |1 ).*?", input)) {						output += "1|";
			} else if (Pattern.matches(primeRegex + "(?:two |2 ).*?", input)) {						output += "2|";
			} else if (Pattern.matches(primeRegex + "(?:three |3 ).*?", input)) {					output += "3|";
			} else if (Pattern.matches(primeRegex + "(?:four |4 ).*?", input)) {					output += "4|";
			} else if (Pattern.matches(primeRegex + "(?:five |5 ).*?", input)) {					output += "5|";
			} else if (Pattern.matches(primeRegex + "(?:six |6 ).*?", input)) {						output += "6|";
			} else if (Pattern.matches(primeRegex + "(?:seven |7 ).*?", input)) {					output += "7|";
			} else if (Pattern.matches(primeRegex + "(?:eight |8 ).*?", input)) {					output += "8|";
			} else if (Pattern.matches(primeRegex + "(?:nine |9 ).*?", input)) {					output += "9|";
			} else if (Pattern.matches(primeRegex + "(?:a )?(?:fleet |ship |boat ).*?", input)) {	output += "1|";
			} else { return "Error - Suspected Transport Priming Failed: fleet amount unclear ==> " + input; }

			// note: sea zones are listed as "sz#"
			Matcher match = Pattern.compile(".*?(?:in|at|on)(.*?)").matcher(input);
			if (match.matches()) {
				String snippedInput = input.substring(input.indexOf(match.group(1)));
				
				for (Territory territory : territories.values()) {
					Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)(" + territory.getRegex() + ")(?!\\d|\\w).*?").matcher(snippedInput);
					if (matchTerritory.matches()) {
						output += territory.getID();
						break;
					}
				}
				
			} else { return "Error - Suspected Transport Priming Failed: target territory unclear for which territory selected ==> " + input; }

			 return output;
		}

		
		
		// decommission
		// "decommission - numberUnits - territory(sz# optional)"
		else if (Pattern.matches(".*?(?:decomm?iss?ion).*?", input) && Pattern.matches(territoryRegex, input)) {
			output = "decommission|";
			if (Pattern.matches(".*?(?:decomm?iss?ion) all.*?", input)) {								output += "all|"; 
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:units|armies|troops|fleets|ships|boats|armada).*?", input)) {	output += "all|"; 
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:one |1 ).*?", input)) {				output += "1|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:two |2 ).*?", input)) {				output += "2|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:three |3 ).*?", input)) {				output += "3|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:four |4 ).*?", input)) {				output += "4|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:five |5 ).*?", input)) {				output += "5|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:six |6 ).*?", input)) {				output += "6|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:seven |7 ).*?", input)) {				output += "7|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:eight |8 ).*?", input)) {				output += "8|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:nine |9 ).*?", input)) {				output += "9|";
			} else if (Pattern.matches(".*?(?:decomm?iss?ion) (?:unit |army |troop |men |man |fleet |ship |boat ).*?", input)) {	output += "1|";
			} else {return "Error - Suspected Unit or Fleet Decommission Failed: troop amount unclear ==> " + input;	}

			// note: sea zones are listed as "sz#"
			Matcher match = Pattern.compile(".*?(?:in|at|on)(.*?)").matcher(input);
			if (match.matches()) {
				String snippedInput = input.substring(input.indexOf(match.group(1)));
				
				for (Territory territory : territories.values()) {
					Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)(" + territory.getRegex() + ")(?!\\d|\\w).*?").matcher(snippedInput);
					if (matchTerritory.matches()) {
						output += territory.getID();
						break;
					}
				}
				
			} else { return "Error - Suspected Unit or Fleet Decommission Failed: target territory unspecified ==> " + input; }
			
			return output;
		}
		
		
		
		// airstrike
		// "airstrike - startzone# - endzone# - improvement"
		else if (Pattern.matches(airstrikeRegex, input) && Pattern.matches(improvementRegex, input) && Pattern.matches(territoryRegex, input)) {
			output = "airstrike|";
			
			//source
			Matcher match1 = Pattern.compile(".*? from (.*?)").matcher(input);
			if (match1.matches()) {	
				String snippedInput = input.substring(input.indexOf(match1.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID() + "|";
							break;
						}
					}
				} else {return "Error - Suspected Airstrike Failed: source territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Airstrike Failed: source territory unclear (no 'from') ==> " + input;	}
			
			//target
			Matcher match2 = Pattern.compile(".*? (?:in|at) (.*?)").matcher(input);
			if (match2.matches()) {	
				String snippedInput = input.substring(input.indexOf(match2.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);

				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID() + "|";
							break;
						}
					}
				} else {return "Error - Suspected Airstrike Failed: target territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Airstrike Failed: target territory unclear (no 'in') ==> " + input;	}

			//improvement
			Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + improvementRegex + "(?!\\d|\\w).*?").matcher(input);
			if (matchTerritory.matches()) {
				output += matchTerritory.group(1);
			}
			else {return "Error - Suspected Airstrike Failed: target improvement unclear ==> " + input;	}
			
			return output;
		}
			

		// nukestrike - plane-dropped
		// "nukebomb - startzone# - endzone#"
		else if (Pattern.matches(nukebombRegex, input) && Pattern.matches(territoryRegex, input)) {
			output = "nukebomb|";
			
			//source
			Matcher match1 = Pattern.compile(".*? from (.*?)").matcher(input);
			if (match1.matches()) {	
				String snippedInput = input.substring(input.indexOf(match1.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID() + "|";
							break;
						}
					}
				} else {return "Error - Suspected Nuclear Airstrike Failed: source territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Nuclear Airstrike Failed: source territory unclear (no 'from') ==> " + input;	}
			
			//target
			Matcher match2 = Pattern.compile(".*? (?:at|on) (.*?)").matcher(input);
			if (match2.matches()) {	
				String snippedInput = input.substring(input.indexOf(match2.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);

				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID();
							break;
						}
					}
				} else {return "Error - Suspected Nuclear Airstrike Failed: target territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Nuclear Airstrike Failed: target territory unclear (no 'in') ==> " + input;	}
			
			
			return output;
		}
		
		
		
		// nukestrike - silo-launched
		// "nukemissile - startzone# - endzone#"
		else if (Pattern.matches(missilestrikeRegex, input)) {
			output = "nukemissile|";
			
			//source
			Matcher match1 = Pattern.compile(".*? from (.*?)").matcher(input);
			if (match1.matches()) {	
				String snippedInput = input.substring(input.indexOf(match1.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID() + "|";
							break;
						}
					}
				} else {return "Error - Suspected Nuclear Missile Strike Failed: source territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Nuclear Missile Strike Failed: source territory unclear (no 'from') ==> " + input;	}
			
			//target
			Matcher match2 = Pattern.compile(".*? (?:at|on) (.*?)").matcher(input);
			if (match2.matches()) {	
				String snippedInput = input.substring(input.indexOf(match2.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);

				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID();
							break;
						}
					}
				} else {return "Error - Suspected Nuclear Missile Strike Failed: target territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Nuclear Missile Strike Failed: target territory unclear (no 'in') ==> " + input;	}
			
			
			return output;
		}
		
		
		
		
		// build improvement
		// "improvement - territory# - improvement
		// silo, railroad, academy, harbor, hq, airfield, fortifications, aa, factory, etc 
		


		else if (!Pattern.matches(airstrikeRegex, input) && Pattern.matches(improvementRegex, input) && Pattern.matches(territoryRegex, input)
				&& !Pattern.matches(missilestrikeRegex, input) && !Pattern.matches(nukebombRegex, input)) {
			output = "improvement|";
			
			//target
			Matcher match2 = Pattern.compile(".*? (?:in|at) (.*?)").matcher(input);
			if (match2.matches()) {	
				String snippedInput = input.substring(input.indexOf(match2.group(1)));
				
				Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);

				if (matchTerritory.matches()) {
					for (Territory territory : territories.values()) {
						Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
						if (specificTerritory.matches()) {
							output += territory.getID() + "|";
							break;
						}
					}
				} else {return "Error - Suspected Improvement Construction Failed: target territory unclear (no territory name recognized) ==> " + input; }
			} else {return "Error - Suspected Improvement Construction Failed: target territory unclear (no 'in') ==> " + input;	}

			//improvement
			Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + improvementRegex + "(?!\\d|\\w).*?").matcher(input);
			if (matchTerritory.matches()) {
				output += matchTerritory.group(1);
			}
			else {return "Error - Suspected Improvement Construction Failed: target improvement unclear ==> " + input;	}
			
			return output;
		}

		
		// give tech/territory
		// "giveTech/giveTerritory - togive - target"
		else if (Pattern.matches(".*?(?:send|give|donate|surrender|tribute|transfer).*?", input) && Pattern.matches(factionRegex, input) 
				&& !Pattern.matches(missilestrikeRegex, input) && !Pattern.matches(nukebombRegex, input)
				&& (Pattern.matches(researchRegex, input) || Pattern.matches(territoryRegex, input))) {
			
			//if it has a territory and not a research
			if (Pattern.matches(territoryRegex, input) && !Pattern.matches(researchRegex, input)) {
				Matcher match1 = Pattern.compile(".*?(?:send|give|donate|surrender|tribute|transfer)(.*?)").matcher(input);
				if (match1.matches()) {	
					String snippedInput = input.substring(input.indexOf(match1.group(1)));
					
					Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
	
					if (matchTerritory.matches()) {
						for (Territory territory : territories.values()) {
							Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
							if (specificTerritory.matches()) {
								output += territory.getID() + "|";
								break;
							}
						}
					} 
					else {return "Error - Suspected Territory Transfer Failed: territory unclear (no territory name recognized) ==> " + input; }
				} 
				else {return "Error - Suspected Territory Transfer Failed: target territory unclear (no 'give') ==> " + input;}	
			}
			
			//if it has a research and not a territory
			else if (!Pattern.matches(territoryRegex, input) && Pattern.matches(researchRegex, input)) {
				Matcher match2 = Pattern.compile(".*?(?:send|give|donate|surrender|tribute|transfer)(.*?)").matcher(input); 
				if (match2.matches()) {	
					String snippedInput = input.substring(input.indexOf(match2.group(1)));
					
					Matcher matchResearch = Pattern.compile(".*?(?<!\\d|\\w)" + researchRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
	
					if (matchResearch.matches()) {
						for (Tech tech : techs.values()) {
							Matcher specificResearch = Pattern.compile(tech.getRegex()).matcher(input);
							if (specificResearch.matches()) {
								output += "giveResearch|" + tech.getTechName() + "|";
								break;
							}
						}
					} 
					else {return "Error - Suspected Technology Transfer Failed: tech unclear (no tech name recognized) ==> " + input; }
				} 
				else {return "Error - Suspected Technology Transfer Failed: target tech unclear (no 'give') ==> " + input;}	
			}
			
			//if it doesn't pass either of those checks
			else {
				return "Error - Suspected Tech/Territory Transfer Failed: tech/territory unclear ==> " + input;
			}
		
			//now for the faction being given it:
			for (Faction faction : factions.values()) {
				Matcher match = Pattern.compile(faction.getRegex()).matcher(input);
				if (match.matches()) {
					output += faction.getFactionName();
					break;
				}
			}
			
			return output;
		}

		
		
		// build unit
		// "spawnArmy - territory#"
		if (Pattern.matches(unitspawnRegex, input) && Pattern.matches(armyRegex, input) && !Pattern.matches(improvementRegex, input) && Pattern.matches(territoryRegex, input)) {
			output = "spawnArmy|";

			if (Pattern.matches(territoryRegex, input) && !Pattern.matches(researchRegex, input)) {
				Matcher match1 = Pattern.compile(".*?(?:in|at|on) (?:territory |zone )?(.*?)").matcher(input);
				if (match1.matches()) {	
					String snippedInput = input.substring(input.indexOf(match1.group(1)));
					
					Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
	
					if (matchTerritory.matches()) {
						for (Territory territory : territories.values()) {
							Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
							if (specificTerritory.matches()) {
								output += territory.getID() + "|";
								break;
							}
						}
					} 
					else {return "Error - Suspected Unit Spawn Failed: territory unclear (no territory name recognized) ==> " + input; }
				} 
				else {return "Error - Suspected Unit Spawn Failed: target territory unclear (no 'in') ==> " + input;}	
			}
			
			return output;
		}

		// build navy  "build a navy in sz3 from the unit in 1\n"
		// "spawnNavy - seazone# - sourceTerritory#"

		if (Pattern.matches(unitspawnRegex, input) && Pattern.matches(navyRegex, input) && !Pattern.matches(improvementRegex, input) && Pattern.matches(territoryRegex, input)) {
			output = "spawnNavy|";

			if (Pattern.matches(territoryRegex, input) && !Pattern.matches(researchRegex, input)) {
				Matcher match1 = Pattern.compile(".*?(?:in|at|on) (?:territory |zone )?(.*?)").matcher(input);
				if (match1.matches()) {	
					String snippedInput = input.substring(input.indexOf(match1.group(1)));
					
					Matcher matchTerritory = Pattern.compile(".*?(?<!\\d|\\w)" + territoryRegex + "(?!\\d|\\w).*?").matcher(snippedInput);
	
					if (matchTerritory.matches()) {
						for (Territory territory : territories.values()) {
							Matcher specificTerritory = Pattern.compile(territory.getRegex()).matcher(matchTerritory.group(1));
							if (specificTerritory.matches()) {
								output += territory.getID() + "|";
								break;
							}
						}
					} 
					else {return "Error - Suspected Unit Spawn Failed: territory unclear (no territory name recognized) ==> " + input; }
				} 
				else {return "Error - Suspected Unit Spawn Failed: target territory unclear (no 'in') ==> " + input;}	
			}
			
			return output;
		}

		// movement unit   move two men from 19 to 16 by railroad through 13, 14, and 15.
		// "moveUnit - numberUnits - source - end - midpoint(optional)(sz# optional)"
		if (Pattern.matches(".*(?:move|send).*", input)&Pattern.matches(".*(?:unit|army|armies|troop|men|man).*", input)&!Pattern.matches(factionRegex, input)) {
			output = "moveUnit ";
			if (Pattern.matches(".*(?:move|send) all.*", input)) {								output += "9 "; //### gonna switch from 9 to all
			} else if (Pattern.matches(".*(?:move|send) (?:units|armies|troops).*", input)) {	output += "9 ";
			} else if (Pattern.matches(".*(?:move|send) (?:one |1 ).*", input)) {				output += "1 ";
			} else if (Pattern.matches(".*(?:move|send) (?:two |2 ).*", input)) {				output += "2 ";
			} else if (Pattern.matches(".*(?:move|send) (?:three |3 ).*", input)) {				output += "3 ";
			} else if (Pattern.matches(".*(?:move|send) (?:four |4 ).*", input)) {				output += "4 ";
			} else if (Pattern.matches(".*(?:move|send) (?:five |5 ).*", input)) {				output += "5 ";
			} else if (Pattern.matches(".*(?:move|send) (?:six |6 ).*", input)) {				output += "6 ";
			} else if (Pattern.matches(".*(?:move|send) (?:seven |7 ).*", input)) {				output += "7 ";
			} else if (Pattern.matches(".*(?:move|send) (?:eight |8 ).*", input)) {				output += "8 ";
			} else if (Pattern.matches(".*(?:move|send) (?:nine |9 ).*", input)) {				output += "9 ";
			} else if (Pattern.matches(".*(?:move|send) (?:unit |army |troop |men |man ).*", input)) {	output += "1 ";
			} else {return "Error - Suspected Unit Movement Failed: troop amount unclear ==> " + input;	}

			if (Pattern.matches(".*(?:in|from) (?:territory |zone )?(\\d+).*", input)) {
				Matcher match = Pattern.compile(".*(?:in|from) (?:territory )?(\\d+).*").matcher(input);
				if (match.matches()) {	output += match.group(1) + " ";}
			} else {return "Error - Suspected Unit Movement Failed: source territory unclear ==> " + input;	}

			if (Pattern.matches(".*(?:to|into) (?:territory |zone )?(\\d+).*", input)) {
				Matcher match = Pattern.compile(".*(?:to|into) (?:territory )?(\\d+).*").matcher(input);
				if (match.matches()) {	output += match.group(1);}
			} else {return "Error - Suspected Unit Movement Failed: target territory unclear ==> " + input;	}

			if (Pattern.matches(".*through (?:territory |territories |zones? )?\\d+.*", input)) {
				Matcher match = Pattern.compile(".*through (?:territory |territories |zones? )?(\\d+).*").matcher(input);
				if (match.matches()) {
					match = Pattern.compile("(\\d+)").matcher(input.substring(input.indexOf("through")));
					if (match.find()) {
						do {output += " " + match.group();} 
						while (match.find());}
				} else {return "Error - Suspected Unit Multi-Tile Move Failed: intermediary zones unclear ==> " + input;	}
				
			} else if (Pattern.matches(".*through (?:territory |territories |seazones? |sea zones? |zones? )?sz\\d+.*", input)) {
				Matcher match = Pattern.compile(".*through (?:territory |territories |seazones? |sea zones? |zones? )?(sz\\d+).*").matcher(input);
				if (match.matches()) {
					match = Pattern.compile("(sz\\d+)").matcher(input.substring(input.indexOf("through")));
					if (match.find()) {
						do {output += " " + match.group();} 
						while (match.find());
					}
				} else {return "Error - Suspected Sea Transport Move Failed: intermediary zones unclear ==> " + input;	}
			}

			return output;
		}
		
		
		// movement navy
		// "moveFleet - numberUnits - source(sz#) - end(sz#) - midpoint(optional)(sz#) - midpoint(optional)(sz#)"
		if (Pattern.matches(".*(?:move|send|sail).*", input) && Pattern.matches(".*(?:fleet|ship|boat|armada).*", input)) {
			output = "moveFleet ";
			if (Pattern.matches(".*(?:move|send|sail) all.*", input)) {										output += "9 "; //### switch from 9 to all
			} else if (Pattern.matches(".*(?:move|send|sail) (?:fleets |ships |boats |armada ).*", input)) {output += "9 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:one |1 ).*", input)) {						output += "1 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:two |2 ).*", input)) {						output += "2 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:three |3 ).*", input)) {					output += "3 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:four |4 ).*", input)) {						output += "4 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:five |5 ).*", input)) {						output += "5 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:six |6 ).*", input)) {						output += "6 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:seven |7 ).*", input)) {					output += "7 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:eight |8 ).*", input)) {					output += "8 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:nine |9 ).*", input)) {						output += "9 ";
			} else if (Pattern.matches(".*(?:move|send|sail) (?:fleet |ship |boat ).*", input)) {			output += "1 ";
			} else {return "Error - Suspected Fleet Movement Failed: fleet amount unclear ==> " + input;	}

			if (Pattern.matches(".*(?:in|from) (?:territory |sea ?zone |zones? )?(sz\\d+).*", input)) {
				Matcher match = Pattern.compile(".*(?:in|from) (?:territory |sea ?zone |zones? )?(sz\\d+).*").matcher(input);
				if (match.matches()) {	output += match.group(1) + " ";}
			} else {return "Error - Suspected Fleet Movement Failed: source territory unclear ==> " + input;	}

			if (Pattern.matches(".*(?:to|into) (?:territory |sea ?zone |zone )?(sz\\d+).*", input)) {
				Matcher match = Pattern.compile(".*(?:to|into) (?:territory |sea ?zone |zones? )?(sz\\d+).*").matcher(input);
				if (match.matches()) {	output += match.group(1);}
			} else {return "Error - Suspected Fleet Movement Failed: target territory unclear ==> " + input;	}

			
			if (Pattern.matches(".*through (?:territory |territories |seazones? |sea zones? )?sz\\d+.*", input)) {
				Matcher match = Pattern.compile(".*through (?:territory |territories |seazone |sea zone )?(sz\\d+).*").matcher(input);
				if (match.matches()) {
					match = Pattern.compile("(sz\\d+)").matcher(input.substring(input.indexOf("through")));
					if (match.find()) {
						do {output += " " + match.group();} 
						while (match.find());
					}
				} else {return "Error - Suspected Fleet Multi-Tile Movement Failed: intermediary zones unclear ==> " + input;	}
			}
			return output;
		}
		
		
		return "Error - Command Failed To Parse: not a recognized command ==> " + input;
	}
}
