package game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class TechManager extends Game {

	private static String techDirectory = System.getProperty("user.dir") + "\\src\\raws\\";
	
	public TechManager() {
	}
	
	public static void initializeTechs(String gameType) {
		loadTechs(gameType);
	}
	
	private static void loadTechs(String gameType) {
		File dir = new File(techDirectory + gameType + "techs");
		File[] dirListing = dir.listFiles();
		if (dirListing != null) {
			for (File techChild : dirListing) {
				if (techChild.isFile()) { //make sure this is actually a file, not a directory that somehow found its way in
					
					Tech newTech = new Tech();
					String techRaw = "";
					try {
						techRaw = readFile(techChild.getPath());
					} catch (IOException e) {
						e.printStackTrace();
					}
					if (!techRaw.isEmpty()) {
						try {
							newTech.parseTech(techRaw);
							techs.put(newTech.getTechName(), newTech);							
						}
						catch (Exception e) {
							System.out.println("Error reading loading Faction - unable to parse."); //###These system.out's really need to be replaced with logs.							
						}
					}
				}
			}
		}
		else {
			System.out.println("Warning: No technology files found in raw/techs!");
		}		
	}
	
	
	//this code stolen from: https://stackoverflow.com/questions/4716503/reading-a-plain-text-file-in-java
	private static String readFile(String fileName) throws FileNotFoundException, IOException { //###string appending is slow and silly.  I should switch to Apache IOUtils when I get the chance. see link above.
		String everything = "";
		try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    everything = sb.toString();
		}
		catch(Exception e) {
			System.out.println("Could not read tech file: " + fileName);
			e.printStackTrace();
		}
		return everything;
	}
	
	
	public static void addTech(Tech tech) {
		techs.put(tech.getTechName(), tech);
	}

	public static void removeTech(String tech) {
		techs.remove(tech);
	}
	
	public static void setTechs(HashMap<String, Tech> techs) {
		Game.techs = techs;
	}
}
