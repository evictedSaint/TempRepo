package game;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;


/** Map primarily handles creating and editing the finalized map png.  
 */
public class Map extends Game {
	
	//###These shouldn't be hardcoded paths.  Base these on gameType.
	private static String imagePath = System.getProperty("user.dir") + "\\src\\raws\\images\\map_blank.png";
	private static String outputPath = System.getProperty("user.dir") + "\\src\\raws\\images\\test.png";
	private String blankMap = "map_blank";
	
	public Map() {
		
	}
	
		
	public static List<String> facOrder(HashMap<String, Faction> factionMap) { //### should probably replace this with a sort (sortbypriority)
		int i = factionMap.size();
		List<String> factionsOrdered = new ArrayList<String>();
		for (int j = 1; j <= i; j++) {
			for (String key : factionMap.keySet()) {
				if (factionMap.get(key).getPriority() == j) {
					factionsOrdered.add(key);
				}
			}
		}
		return factionsOrdered;
	}
	
	public void putFleets(HashMap<String, Faction> factions, int year, String month) {
		//get map (should already have faction colors on it by this point)
		BufferedImage mapImage = null;
		try {
			mapImage = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//build the new map
		BufferedImage newMap = new BufferedImage(mapImage.getWidth(), mapImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics g = newMap.getGraphics();
		g.drawImage(mapImage,  0,  0, null);
		
		HashMap<String, Integer> numberOfUnits = new HashMap<String, Integer>();
		for (String territoryID : territories.keySet()) {
			numberOfUnits.put(territoryID, 0);
		}

		for (String factionName : facOrder(factions)) {
			int numUnits = 0;
			HashMap<String, Integer> factionUnitsNumber = new HashMap<String, Integer>();
			for (Fleet fleet : factions.get(factionName).getFleets()) {
				String unitTerritory = fleet.getMoveList().get(fleet.getMoveList().size()-1);
				if (factionUnitsNumber.containsKey(unitTerritory)) {
					factionUnitsNumber.put(unitTerritory, factionUnitsNumber.get(unitTerritory)+1);
				} else {
					factionUnitsNumber.put(unitTerritory, 1);
				}
			}

			for (String territory : factionUnitsNumber.keySet()) {
				
				//how many are already drawn in this territory
				int offset = numberOfUnits.get(territory)*13;
				numberOfUnits.put(territory, numberOfUnits.get(territory) + 1);
				
				//get the number of units to place
				numUnits = factionUnitsNumber.get(territory);
				
				//get the coords of the territory
				int x = territories.get(territory).getxCoord();
				int y = territories.get(territory).getyCoord();
				//get the number path
				String numIcon = "";
				if (numUnits > 9) {
					numIcon = "9";
				}
				else {
					numIcon = Integer.toString(numUnits);
				}
				String numPath = new File("").getAbsolutePath() + "\\src\\raws\\numbers\\" + numIcon + ".png";
				String armyPath = new File("").getAbsolutePath() + "\\src\\raws\\symbols\\navy.png";

				//color the unit icon
				BufferedImage fleetBox = null;
				try {
					fleetBox = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\symbols\\navy.png")); //+ Integer.toString(year) + "_" + month +
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Color facColor = factions.get(factionName).getFactionColor();
				new FloodFill().floodFill(fleetBox, new Point(9,8), facColor);	
				try {
					ImageIO.write(fleetBox, "png", new File(System.getProperty("user.dir") + "\\src\\raws\\symbols\\navy.png"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//drawing all icons now
				BufferedImage iconImage;
				//draw the unit box
				try {
					iconImage = ImageIO.read(new File(armyPath));
					g.drawImage(iconImage, x, y+15+offset, null);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//draw the number in the box
				try {
					iconImage = ImageIO.read(new File(numPath));
					g.drawImage(iconImage, x, y+15+offset, null);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//output drawn map
				try {
					ImageIO.write(newMap,  "png",  new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
	public void putUnits(HashMap<String, Faction> factions, int year, String month) {
		//get map (should already have faction colors on it by this point)
		BufferedImage mapImage = null;
		try {
			mapImage = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		//build the new map
		BufferedImage newMap = new BufferedImage(mapImage.getWidth(), mapImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics g = newMap.getGraphics();
		g.drawImage(mapImage,  0,  0, null);
					
		
		
		HashMap<String, Integer> numberOfUnits = new HashMap<String, Integer>();
		for (String territoryID : territories.keySet()) {
			numberOfUnits.put(territoryID, 0);
		}


		int numUnits = 0;
		for (String factionName : factions.keySet()) {
			for (String unitTerritory : territories.keySet()) {

				//get the number of units to place
				numUnits = factions.get(factionName).getUnitsIn(unitTerritory).size();
				if (numUnits == 0) {													//if there are none, check the next territory
					continue;
				}
				
				//how many are already drawn in this territory
				int offset = numberOfUnits.get(unitTerritory)*13;
				numberOfUnits.put(unitTerritory, numberOfUnits.get(unitTerritory) + 1);
				
				//get the coords of the territory
				int x = territories.get(unitTerritory).getxCoord();
				int y = territories.get(unitTerritory).getyCoord();
				//get the number path
				String numIcon = "";
				if (numUnits > 9) {
					numIcon = "9";
				}
				else {
					numIcon = Integer.toString(numUnits);
				}
				String numPath = new File("").getAbsolutePath() + "\\src\\raws\\numbers\\" + numIcon + ".png";
				String armyPath = new File("").getAbsolutePath() + "\\src\\raws\\symbols\\army.png";
				

				//color the unit icon
				BufferedImage armyBox = null;
				try {
					armyBox = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\symbols\\army.png")); //+ Integer.toString(year) + "_" + month +
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				Color facColor = factions.get(factionName).getFactionColor();
				new FloodFill().floodFill(armyBox, new Point(9,8), facColor);	
				try {
					ImageIO.write(armyBox, "png", new File(System.getProperty("user.dir") + "\\src\\raws\\symbols\\army.png"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//drawing all icons now
				BufferedImage iconImage;
				//draw the unit box
				try {
					iconImage = ImageIO.read(new File(armyPath));
					g.drawImage(iconImage, x, y+26+offset, null);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//draw the number in the box
				try {
					iconImage = ImageIO.read(new File(numPath));
					g.drawImage(iconImage, x, y+26+offset, null);
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//output drawn map
				try {
					ImageIO.write(newMap,  "png",  new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	
	public void blankOutputMap(int year, String month) {
		try {
			BufferedImage blankImage = ImageIO.read(new File(imagePath));
			Graphics g = blankImage.getGraphics();
			g.drawImage(blankImage,  0,  0, null);
			ImageIO.write(blankImage,  "png",  new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void putColors(HashMap<String, Faction> factions, int year, String month) {
		
		//the output.  since this should be the first time we're painting the map, we need to check that it exists.
		BufferedImage outImage = null;
		try {
			outImage = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png")); //+ Integer.toString(year) + "_" + month +
		} catch (IOException e1) {
			// if the file doesn't exist, make a new one
			try {	
				outImage = ImageIO.read(new File(imagePath));
				ImageIO.write(outImage, "png",new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		for (String key : factions.keySet()) {
			Set<String> occTerritory = factions.get(key).getOccupiedTerritories();
			Color facColor = factions.get(key).getFactionColor();
			for (String occKey : occTerritory) {
				int x = territories.get(occKey).getxCoord();
				int y = territories.get(occKey).getyCoord();
				
				new FloodFill().floodFill(outImage, new Point(x+10,y+25), facColor);
				try {
					ImageIO.write(outImage, "png", new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}
	
	public void putNumbers(String gameType, int year, String month) {
		//get map (should already have faction colors on it by this point)
		BufferedImage mapImage = null;
		try {
			mapImage = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\maps\\" + gameType + ".png")); // + Integer.toString(year) + "_" + month + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		//build the new map
		BufferedImage newMap = new BufferedImage(mapImage.getWidth(), mapImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
		Graphics g = newMap.getGraphics();
		g.drawImage(mapImage,  0,  0, null);
		
		//put numbers on map for each territory
		for (String id : territories.keySet()) {
			int x = territories.get(id).getxCoord();
			int y = territories.get(id).getyCoord();

			int iconPixelWidth = 0;
			int iconPixelHeight = 0;
			int iconPixelHeightTotal = 0;
			
			//name of the territory
			for(int i = 0, n = id.length() ; i < n ; i++) { 
			    char c = Character.toLowerCase(id.charAt(i)); //currently, all names are case-insensitive.

				String iconPath = new File("").getAbsolutePath() + "\\src\\raws\\lettersandnumbers\\" + c + ".png";
				try {
					BufferedImage iconImage = ImageIO.read(new File(iconPath));
					g.drawImage(iconImage, x+iconPixelWidth, y, null);
					iconPixelWidth += iconImage.getWidth();
					if (iconImage.getHeight() > iconPixelHeight) {
						iconPixelHeight = iconImage.getHeight();
					}
					
				} catch (IOException e) {
					System.out.println("Error in painting name: Character '" + c + "' in '" + id + "'is not a valid icon.");
				}
			}
			
			iconPixelWidth = 0;
			iconPixelHeightTotal += iconPixelHeight;
			iconPixelHeight = 0;
			
			
			
			//fallout
			if (territories.get(id).getFallout() > 0) {
				try {
					int falloutAmount = territories.get(id).getFallout();
					if (falloutAmount > 9) {falloutAmount = 9;}
					
					String iconPath = new File("").getAbsolutePath() + "\\src\\raws\\symbols\\fallout.png";
					BufferedImage iconImage = ImageIO.read(new File(iconPath));
					g.drawImage(iconImage, x, y+iconPixelHeight, null);
					
					Integer.toString(falloutAmount);
					String iconPath2 = new File("").getAbsolutePath() + "\\src\\raws\\lettersandnumbers\\" + Integer.toString(falloutAmount) + ".png";
					BufferedImage iconImage2 = ImageIO.read(new File(iconPath2));
					g.drawImage(iconImage2, x+3, y+iconPixelHeight, null);
					iconPixelWidth += iconImage.getWidth();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
				
			
			//all other improvements
			List<Improvement> sortedImprovements = new ArrayList<Improvement>();
			sortedImprovements.addAll(improvements.values());
			Collections.sort(sortedImprovements, new SortByImprovementPriority());

			for (Improvement improvement : sortedImprovements) {
				if (improvement.isDisplayImprovement()) {
					if (iconPixelWidth > 45) { 
						iconPixelWidth = 0;
						iconPixelHeightTotal += iconPixelHeight;
						iconPixelHeight = 0;
					}
					
					try {
						String iconPath = new File("").getAbsolutePath() + "\\src\\raws\\symbols\\" + improvement.getIconName() + ".png";
						BufferedImage iconImage = ImageIO.read(new File(iconPath));
						g.drawImage(iconImage, x+iconPixelWidth, y+iconPixelHeightTotal, null);

						iconPixelWidth += iconImage.getWidth();
						if (iconImage.getHeight() > iconPixelHeight) {
							iconPixelHeight = iconImage.getHeight();
						}
					} catch (IOException e) {
						e.printStackTrace();
						System.out.println("Error: Unable to add '" + improvement.getImprovementName() + "' to the map.");
					}	
				}		
			}
		}
			
		//output drawn map
		try {
			ImageIO.write(newMap,  "png",  new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("Error: Unable to output map.");
		}
	}
			
		
	//depricated - too slow as it reloaded and drew the entire map each time  ###Delete this (double-check, first)
	public void colorSpot(int x, int y, Color color, int year, String month) throws IOException {
		//set the output map
		BufferedImage outImage = null;
		try {
			outImage = ImageIO.read(new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png")); //+ Integer.toString(year) + "_" + month +
		} catch (IOException e1) {
			// if the file doesn't exist, make a new one
			try {	
				outImage = ImageIO.read(new File(imagePath));
				ImageIO.write(outImage, "png",new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		new FloodFill().floodFill(outImage, new Point(x,y), color);
		ImageIO.write(outImage, "png", new File(System.getProperty("user.dir") + "\\src\\raws\\images\\" + Integer.toString(year) + "_" + month + ".png"));
	}
	
	
	//depricated - too slow as it reloaded and drew the entire map each time ### delete this!!! 
	public void addIcon_(String icon, int x, int y) throws IOException {
		String iconPath = new File("").getAbsolutePath() + "\\src\\raws\\symbols" + icon;
		
		BufferedImage mapImage = ImageIO.read(new File(outputPath));
		BufferedImage iconImage = ImageIO.read(new File(iconPath));
		
		BufferedImage newMap = new BufferedImage(mapImage.getWidth(), mapImage.getHeight(), BufferedImage.TYPE_INT_ARGB);
		
		Graphics g = newMap.getGraphics();
		g.drawImage(mapImage,  0,  0, null);
		g.drawImage(iconImage,  x,  y, null);
		ImageIO.write(newMap,  "png",  new File(outputPath));
	}
	
	public void outputMap() throws IOException {
		ImageIO.write(ImageIO.read(new File(imagePath)), "png", new File(outputPath));
		//color
//		for (Faction faction : factions) {
//			for (Territory territory : faction.getOccupiedTerritories()) {
//				colorSpot(territory.getxCoord(),territory.getyCoord(),faction.getFactionColor());
//			}
//		}
		//improvements
		for (Territory territory : territories.values()) {
			
			
		}
	}

	public static String getImagePath() {
		return imagePath;
	}

	public static void setImagePath(String imagePath) {
		Map.imagePath = imagePath;
	}

	public static String getOutputPath() {
		return outputPath;
	}

	public static void setOutputPath(String outputPath) {
		Map.outputPath = outputPath;
	}
	
}
