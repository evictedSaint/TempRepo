package game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.Color;
import java.io.Serializable;

public class Faction implements Serializable {
	
	private String factionName = "";
	private String regex = "";
	private String userName = "";
	private Boolean alive = true;
	private String govType = "";
	private String capitol1 = "";
	private String capitol2 = "";
	private String exchangeTreaty1;
	private String exchangeTreaty2;
	private int priority = 0;
	private Set<String> occupiedTerritories = new HashSet<String>();
	private List<Integer> diceDeck = new ArrayList<Integer>();
	private int maxUnits = 0;
	private int pi = 0;
	private int nukeAirThisTurn = 0;
	private int nukeAirLimit = 0;
	private int nukeMissileThisTurn = 0;
	private HashMap<String, String> diplomacy = new HashMap<String, String>(); //ally, war, neutral, nonaggression //###Make sure nonaggression is included
	private Set<Unit> units = new HashSet<Unit>();
	private Set<Fleet> fleets = new HashSet<Fleet>();
	private Color factionColor = new Color(150,150,150);
	
	public Faction() {
//		this.alive = true;
//		this.exchangeTreaty1 = "open";
//		this.exchangeTreaty2 = "open";
//		this.priority = priority;
//		this.factionName = name;
//		this.factionShort = shortName;
//		this.factionColor = new Color(r,g,b);
//		shuffleDeck();
	}
	
	
	//###Faction also needs to load diplomacy, if available. 
	public void parseFaction(String factionRaw) {
		
		String tokenRegex = ".*?\\[(.*?)\\].*?";
		Matcher match = Pattern.compile(tokenRegex).matcher(factionRaw);

		List<Integer> temp = new ArrayList<Integer>();
		if (match.find()) {
			do {
				String[] token = match.group(1).split(":");
				
				try {
					switch(token[0]) {
					//base values
					case "factionName":
						factionName = token[1];
						break;				
					case "regex":
						regex = match.group(1).substring(match.group(1).indexOf(":")+1);
						break;
					case "userName":
						userName = token[1];
						break;
					case "priority":
						priority = Integer.valueOf(token[1]);
						break;
					case "factionColor":
						this.factionColor = new Color(Integer.valueOf(token[1]),Integer.valueOf(token[2]),Integer.valueOf(token[3]));
						break;
					case "units":
						for (int i = 1; i < token.length; i++) {
							units.add(new Unit(token[i]));
						}
						break;
					case "fleets":
						for (int i = 1; i < token.length; i++) {
							fleets.add(new Fleet(token[i]));
						}
						break;
					case "occupiedTerritories":
						for (int i = 1; i < token.length; i++) {
							occupiedTerritories.add(token[i]);
						}
						break;
					}					
				} catch(Exception e) {
					System.out.println("Error reading faction file for faction: " + factionName);
					System.out.println("-> Attempted to parse: " + token[0]);
					System.out.println(e);
				}
			} while (match.find());
		}
	}

	
	
	public Integer pullCard() {
		if (diceDeck.size() == 0) {
			shuffleDeck();
		}
		int index = (int)(Math.random()*(diceDeck.size()));
		int card = diceDeck.get(index);
		diceDeck.remove(index);
		return card;
	}
	
	
	//###shuffle deck into tech dice size
	public void shuffleDeck() {
		List<Integer> tempDeck = new ArrayList<Integer>();
		tempDeck.add(1);
		tempDeck.add(2);
		tempDeck.add(3);
		tempDeck.add(4);
		tempDeck.add(5);
		tempDeck.add(6);
		this.diceDeck = new ArrayList<Integer>(tempDeck);
	}

	public String getFactionName() {
		return factionName;
	}

	public void setFactionName(String factionName) {
		this.factionName = factionName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public Boolean getAlive() {
		return alive;
	}

	public void setAlive(Boolean alive) {
		this.alive = alive;
	}

	public String getGovType() {
		return govType;
	}

	public void setGovType(String govType) {
		this.govType = govType;
	}

	public String getCapitol1() {
		return capitol1;
	}

	public void setCapitol1(String capitol) {
		this.capitol1 = capitol;
	}
	
	public String getCapitol2() {
		return capitol2;
	}

	public void setCapitol2(String capitol) {
		this.capitol2 = capitol;
	}
	
	public String getExchangeTreaty1() {
		return exchangeTreaty1;
	}

	public void setExchangeTreaty1(String exchangeTreaty1) {
		this.exchangeTreaty1 = exchangeTreaty1;
	}

	public String getExchangeTreaty2() {
		return exchangeTreaty2;
	}

	public void setExchangeTreaty2(String exchangeTreaty2) {
		this.exchangeTreaty2 = exchangeTreaty2;
	}

	public Boolean checkExchangeTreatyAvailable(String faction) {
		if (this.exchangeTreaty1.equals("open") || this.exchangeTreaty2.equals("open")) {
			if (!this.exchangeTreaty1.equals(faction) && !this.exchangeTreaty2.equals(faction)) {
				return true;
			}
		}
		return false;
	}	
	
	//###exchange treaties into a Set, rather than just 2.  Make treaty number into a tech.
	public Boolean breakExchangeTreaty(String faction) {
		if (this.exchangeTreaty1.equals(faction)) {
			this.exchangeTreaty1 = "broken";
			return true;
		}
		if (this.exchangeTreaty2.equals(faction)) {
			this.exchangeTreaty2 = "broken";
			return true;
		}
		return false;
	}
	
	public Boolean putExchangeTreaty(String faction) {
		if (this.exchangeTreaty1.equals("open")) {
			this.exchangeTreaty1 = faction;
			return true;
		}
		if (this.exchangeTreaty2.equals("open")) {
			this.exchangeTreaty2 = faction;
			return true;
		}
		return false;
	}
	
	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	public int getPi() {
		return pi;
	}

	public void setPi(int pi) {
		this.pi = pi;
	}

	public int getNukeAirThisTurn() {
		return nukeAirThisTurn;
	}

	public void setNukeAirThisTurn(int nukeAirThisTurn) {
		this.nukeAirThisTurn = nukeAirThisTurn;
	}
	
	public void incNukeAirThisTurn() {
		this.nukeAirThisTurn++;
	}

	public int getNukeAirLimit() {
		return nukeAirLimit;
	}

	public void setNukeAirLimit(int nukeAirLimit) {
		this.nukeAirLimit = nukeAirLimit;
	}
	
	public int getNukeMissileThisTurn() {
		return nukeMissileThisTurn;
	}

	public void incNukeMissileThisTurn() {
		this.nukeMissileThisTurn++;
	}
	
	public void setNukeMissileThisTurn(int nukeMissileThisTurn) {
		this.nukeMissileThisTurn = nukeMissileThisTurn;
	}

	public Set<String> getOccupiedTerritories() {
		return occupiedTerritories;
	}

	public void setOccupiedTerritories(Set<String> occupiedTerritories) {
		this.occupiedTerritories = new HashSet(occupiedTerritories);
	}
	
	public void addOccupiedTerritory(String territory) {
		this.occupiedTerritories.add(territory);
	}
	
	public boolean checkOccupiedTerritory(String territory) {
		if (this.occupiedTerritories.contains(territory)) {
			return true;
		}
		return false;
	}
	
	public void removeOccupiedTerritory(String territory) {
		this.occupiedTerritories.remove(territory);
	}

	public int getMaxUnits() {
		return maxUnits;
	}

	public void setMaxUnits(int totalUnits) {
		this.maxUnits = totalUnits;
	}

	public HashMap<String, String> getDiplomacy() {
		return diplomacy;
	}
	
	public Set<String> getAllies() {
		Set<String> allies = new HashSet<String>();
		for (String potentialAlly : this.diplomacy.keySet()) {
			if (getDiplomacySpecific(potentialAlly).equals("alliance")) {
				allies.add(potentialAlly);
			}
		}
		return allies;
	}
	
	public Set<String> getNeutrals() {
		Set<String> neutrals = new HashSet<String>();
		for (String potentialNeutral : this.diplomacy.keySet()) {
			if (getDiplomacySpecific(potentialNeutral).equals("neutral")) {
				neutrals.add(potentialNeutral);
			}
		}
		return neutrals;
	}
	
	public Set<String> getEnemies() {
		Set<String> enemies = new HashSet<String>();
		for (String potentialEnemy : this.diplomacy.keySet()) {
			if (getDiplomacySpecific(potentialEnemy).equals("war")) {
				enemies.add(potentialEnemy);
			}
		}
		return enemies;
	}
	
	public String getDiplomacySpecific(String targetFaction) {
		return this.diplomacy.get(targetFaction);
	}

	public void changeDiplomacy(String faction, String stance) {
		this.diplomacy.put(faction, stance);
	}
	
	public void setDiplomacy(HashMap<String, String> diplomacy) {
		HashMap<String, String> tempMap = new HashMap<String, String>(diplomacy);
		this.diplomacy = tempMap;
	}

	public Set<Unit> getUnits() {
		return units;
	}
	
	public Set<Unit> getUnitsIn(String territory) {
		Set<Unit> localUnits = new HashSet<Unit>();
		for (Unit unit : units) {
			if (unit.getMoveList().get(unit.getMoveList().size()-1).equals(territory)) {
				localUnits.add(unit);
			}
		}
		return localUnits;
	}
	
	public boolean unitIn(String territory) {
		boolean success = false;
		for (Unit unit : units) {
			if (unit.getMoveList().get(unit.getMoveList().size()-1).equals(territory)) {
				success = true;
				break;
			}
		}
		return success;
	}

	public void setUnits(Set<Unit> units) {
		this.units = new HashSet<Unit>(units);
	}

	public void addUnit(String territory) {
		this.units.add(new Unit(territory));
	}
	
	public void resetUnitMovement() {
		for (Unit unit : this.units) {
			unit.setMovedThisTurn(false);
		}
	}
	
	public void removeUnit(Unit unit) {
		this.units.remove(unit);
	}
	
	public Set<Fleet> getFleets() {
		return fleets;
	}
	
	public Set<Fleet> getFleetsIn(String territory) {
		Set<Fleet> localFleets = new HashSet<Fleet>();
		for (Fleet fleet : fleets) {
			if (fleet.getMoveList().get(fleet.getMoveList().size()-1).equals(territory)) {
				localFleets.add(fleet);
			}
		}
		return localFleets;
	}
	
	public boolean fleetIn(String territory) {
		boolean success = false;
		for (Fleet fleet : fleets) {
			if (fleet.getMoveList().get(fleet.getMoveList().size()-1).equals(territory)) {
				success = true;
				break;
			}
		}
		return success;
	}

	public void setFleets(Set<Fleet> fleets) {
		this.fleets = new HashSet<Fleet>(fleets);
	}

	public void addFleet(String territory) {
		this.fleets.add(new Fleet(territory));
	}
	
	public void resetFleetMovement() {
		for (Fleet fleet : this.fleets) {
			fleet.setMovedThisTurn(false);
		}
	}
	
	public void removeFleet(Fleet fleet) {
		this.fleets.remove(fleet);
	}
	
	public Color getFactionColor() {
		return factionColor;
	}

	public void setFactionColor(Color factionColor) {
		this.factionColor = factionColor;
	}


	public String getRegex() {
		return regex;
	}


	public void setRegex(String regex) {
		this.regex = regex;
	}


	public List<Integer> getDiceDeck() {
		return diceDeck;
	}


	public void setDiceDeck(List<Integer> diceDeck) {
		this.diceDeck = diceDeck;
	}
	
}
