package game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class ImprovementsManager extends Game {

	private static String improvementDirectory = System.getProperty("user.dir") + "\\src\\raws\\";
	
	public ImprovementsManager() {
	}
	
	public static void initializeImprovements(String gameType) {
		loadImprovements(gameType);
	}
	
	private static void loadImprovements(String gameType) {
		File dir = new File(improvementDirectory + gameType + "improvements");
		File[] dirListing = dir.listFiles();
		if (dirListing != null) {
			for (File improvementChild : dirListing) {
				if (improvementChild.isFile()) { //make sure this is actually a file, not a directory that somehow found its way in
					
					Improvement newImprovement = new Improvement();
					String improvementRaw = "";
					try {
						improvementRaw = readFile(improvementChild.getPath());
					} catch (IOException e) {
						e.printStackTrace();
					}
					if (!improvementRaw.isEmpty()) {
						try {
							newImprovement.parseImprovement(improvementRaw);
							improvements.put(newImprovement.getImprovementName(), newImprovement);							
						}
						catch(Exception e) {
							System.out.println("Error reading loading improvement - unable to parse."); //###These system.out's really need to be replaced with logs.
						}
					}
				}
			}
		}
		else {
			System.out.println("Warning: No technology files found in raw/techs!"); //###again, this should be logfiles, not system.out's.
		}		
	}
	
	
	//this code stolen from: https://stackoverflow.com/questions/4716503/reading-a-plain-text-file-in-java
	private static String readFile(String fileName) throws FileNotFoundException, IOException { //###string appending is slow and silly.  I should switch to Apache IOUtils when I get the chance. see link above.
		String everything = "";
		try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    everything = sb.toString();
		}
		catch(Exception e) {
			System.out.println("Could not read improvements file: " + fileName);
			e.printStackTrace();
		}
		return everything;
	}
	

	public static void addImprovement(Improvement improvement) {
		improvements.put(improvement.getImprovementName(), improvement);
	}
	
	public static void removeImprovement(String improvement) {
		improvements.remove(improvement);
	}
	
	public static void setImprovements(HashMap<String, Improvement> improvements) {
		Game.improvements = improvements;
	}
}
