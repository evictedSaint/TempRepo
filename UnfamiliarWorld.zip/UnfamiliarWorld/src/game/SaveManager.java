package game;

import java.io.*;
import java.util.*;

public class SaveManager {

	private String saveString = "";
	
	
	public static void saveGame2(Game game) throws IOException {
		//create new save file using the year and month
		String fileName= System.getProperty("user.dir") + "\\src\\Saves\\" + Turn.getYear() + "_" + Turn.getMonth() + ".ser";
		File newSaveFile = new File(fileName);
		if (newSaveFile.createNewFile()) {
			System.out.println("file '" + Turn.getYear() + "_" + Turn.getMonth() + "' created successfully.");
		} else {System.out.println("file '" + Turn.getYear() + "_" + Turn.getMonth() + "' NOT created - already exists.");}
		
	    FileOutputStream fos = new FileOutputStream(fileName);
	    ObjectOutputStream oos = new ObjectOutputStream(fos);
	    HashMap<String, Object> save = new HashMap<String, Object>();
	    save.put("Game", game);
	    save.put("Map", game.getMap());
	    save.put("Turn", game.getTurn());
	    oos.writeObject(save);
	    oos.close();		
		
	}	
	
	
	public static Game loadGame2(String saveName) throws IOException, ClassNotFoundException {
		

		String fileName= System.getProperty("user.dir") + "\\src\\Saves\\" + saveName + ".ser";
		FileInputStream fin;
		fin = new FileInputStream(fileName);
		ObjectInputStream ois = new ObjectInputStream(fin);
		HashMap<String, Object> save = (HashMap<String, Object>) ois.readObject();
		Game game = (Game) save.get("Game");
		game.setMap((Map) save.get("Map"));
		game.setTurn((Turn) save.get("Turn")); 
		ois.close();
		
		return game;
		
	}
	
	public static void saveGame(Game game) throws IOException {
		//create new save file using the year and month
		String fileName= System.getProperty("user.dir") + "\\src\\Saves\\" + Turn.getYear() + "_" + Turn.getMonth() + ".ser";
		File newSaveFile = new File(fileName);
		if (newSaveFile.createNewFile()) {
			System.out.println("file '" + Turn.getYear() + "_" + Turn.getMonth() + "' created successfully.");
		} else {System.out.println("file '" + Turn.getYear() + "_" + Turn.getMonth() + "' NOT created - already exists.");}
		
	    FileOutputStream fos = new FileOutputStream(fileName);
	    ObjectOutputStream oos = new ObjectOutputStream(fos);
	    oos.writeObject(game);
	    oos.close();		
		
	}	
	
	
	public static Game loadGame(String saveName) throws IOException, ClassNotFoundException {
		

		String fileName= System.getProperty("user.dir") + "\\src\\Saves\\" + saveName + ".ser";
		FileInputStream fin;
		fin = new FileInputStream(fileName);
		ObjectInputStream ois = new ObjectInputStream(fin);
		Game game = (Game) ois.readObject();
		ois.close();
		
		return game;
		
	}
}
