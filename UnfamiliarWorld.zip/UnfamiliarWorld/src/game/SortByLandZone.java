package game;

import java.util.Comparator;

public class SortByLandZone implements Comparator<String> { 	
	public SortByLandZone( ) {
	}

	@Override
	public int compare(String lz1, String lz2) {
		
		int LZ1 = Integer.parseInt(lz1);
		int LZ2 = Integer.parseInt(lz2);
		
		if (LZ1 < LZ2) return -1;
		else if (LZ1 == LZ2) return 0;
		else return 1;
	}
}