package game;

public class Initializer extends Game {
	
	/*//###since these are all static, I don't need to create a class, I think? Could probably remove all this.
	private static ImprovementsManager improvementsManager = new ImprovementsManager();
	private static TechManager techManager = new TechManager();
	private static FactionsManager factionsManager = new FactionsManager();
	private static TerritoriesManager territoriesManager = new TerritoriesManager();
	*/
	public Initializer() {
		
		
	}

	
	public static void initializeAll(String gameType) { //###finish filling this out
		//###these functions need to have the option between first-time initialization vs loading from a save file.
		initializeFactions(gameType); 
		initializeImprovements(gameType);
		initializeTechs(gameType);
		initializeTerritories(gameType);
	}
	
	static void initializeTerritories(String gameType) {
		TerritoriesManager.initializeTerritories(gameType);
	}
	
	static void initializeImprovements(String gameType) {
		//###redo initializeTechnologies, have it build improvements.
		ImprovementsManager.initializeImprovements(gameType);
	}
	
	static void initializeTechs(String gameType) { //###figure out if there's a way to make techs less dependent on improvements (improve robustness)
		TechManager.initializeTechs(gameType);
		//Tech.setMap(map.getTerritoriesMap());
		//Tech.setImprovements(improvementsManager.getImprovements());	//Important - make sure improvements are initialized first!!!	
	}
	
	static void initializeFactions(String gameType) {
		FactionsManager.initializeFactions(gameType);
	}
	
	
}
