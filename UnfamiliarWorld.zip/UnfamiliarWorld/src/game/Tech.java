package game;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


/** Tech handles each Technology in the game.  Because techs can provide a multitude of different bonuses under a multitude of different circumstances,
 * this class also auto-calculates that bonus based on the game state.  It's fairly easy to include a new bonus to tech that's not explicitly covered
 * here.  Create a new variable and edit the relevant method below to include it in its calculations.  If this bonus somehow applies to something not covered
 * by one of the methods below, then you'll have to create a new method and integrate it into the relevant portion of the Turn.   
 * 
 * By default, most bonuses a tech provides will be 0.  Technically, the game can function without ANY techs, but it would be pretty boring - players couldn't
 * spawn new units, they would roll nothing but 1's, and they would be unable to move their pieces or build any new infastructure.  
 * 
 * It's recommended to have at least 1 tech that provides all the base stats for a faction (such as _BaseStats).  Have all the relevant factions start with it,
 * and have it provide all the flat bonuses they need (i.e. moveUnitBonus = 1, so they can move their pieces. diceBonus =5, so they roll 1d6's.  Etc).
 * For asymmetrical games, you can have a couple different base stat techs, which provide factions with different starting bonuses.
 * 
 * If you need to edit this class, it's strongly recommended you create a backup first.
 */
public class Tech extends Game{
	
	String techName = "";
	String regex = "";
	boolean displayTech = false;
	boolean canResearch = false;
	List<String> prereqTechs = new ArrayList<String>();
	List<String> factionsWithThisTech = new ArrayList<String>();
	int techCost = 0;
	
	//improvements
	List<String> improvementsEnabled = new ArrayList<String>(); //list of improvements this tech allows the faction to construct
	List<String> improvementsUnitPassable = new ArrayList<String>();  //by default, units cannot cross into areas containing a building unless it's listed here. "terrain" is basically "improvements" so you can do oceans here.
	List<String> improvementsFleetPassable = new ArrayList<String>(); //for standard gameplay, all buildings will be listed here since there's no "roadblock" type improvements
	HashMap<String, Integer> improvementsAllowAirstrike = new HashMap<String, Integer>(); //list of improvements that can perform an airstrike (usually just airfield) and the range
	HashMap<String, Integer> improvementsAllowNukeAirstrike = new HashMap<String, Integer>(); //list of improvements that can launch a nuclear airstrike. Note: Does not ENABLE use of nukes. See nukeAirstrikeEnabled below.
	HashMap<String, Integer> improvementsAllowMissilestrike = new HashMap<String, Integer>(); //list of improvements that can launch a nuclear missile strike
	HashMap<String, Integer> improvementsResearchPercentBonuses = new HashMap<String, Integer>(); //how much you get per building - standard is +1 per academy.
	HashMap<String, Integer> improvementsChainable = new HashMap<String, Integer>(); //ie railroads, and how far they can be chained together.
	
	HashMap<String, Integer> improvementsUnitCombatBonus = new HashMap<String, Integer>(); //barricades, airfields, etc - bonuses to units in the territory
	HashMap<String, Integer> improvementsFleetCombatBonus = new HashMap<String, Integer>(); //

	HashMap<String, Integer> improvementsUnitCombatBonusNeutral = new HashMap<String, Integer>(); //faction doesn't need to own the territory to use the bonus
	HashMap<String, Integer> improvementsFleetCombatBonusNeutral = new HashMap<String, Integer>(); //
	
	HashMap<String, List<Integer>> improvementsUnitCombatBonusRange = new HashMap<String, List<Integer>>(); //silos, airfields - things that provide a combat bonus from nearby territories
	HashMap<String, List<Integer>> improvementsFleetCombatBonusRange = new HashMap<String, List<Integer>>(); //format is <improvement <range, bonus>>
	
	//Production Points
	int prodPointsFlatBonus = 0;
	HashMap<String, Integer> improvementsProdPointsPercentBonus = new HashMap<String, Integer>();  //note: the integer is the percent. 50 = 1 per 2.  34 = 1 per 3. 100 = 1 per 1. etc.
	
	//Max Army
	int maxArmyFlatBonus = 0;
	HashMap<String, Integer> improvementsMaxArmyPercentBonus = new HashMap<String, Integer>();  //note: the integer is the percent. 50 = 1 per 2.  34 = 1 per 3. 100 = 1 per 1. etc.
	
	//Spawn Points
	HashMap<String, Integer> improvementsUnitSpawn = new HashMap<String, Integer>(); //Improvement, number that can spawn
	HashMap<String, Integer> improvementsFleetSpawn = new HashMap<String, Integer>();
	
	//airstrikes
	boolean airstrikeUnitEnabled = false;
	int airstrikeUnitRange = 0;
	int airsupportUnitRange = 0;
	boolean airstrikeFleetEnabled = false;
	int airstrikeFleetRange = 0;
	int airsupportFleetRange = 0;
	
	//anti-air
	HashMap<String, Integer> improvementsAAInterceptionPercent = new HashMap<String, Integer>();
	HashMap<String, Integer> improvementsMissileInterceptionPercent = new HashMap<String, Integer>();
	HashMap<String, Integer> improvementsAAInterceptionAmount = new HashMap<String, Integer>();
	HashMap<String, Integer> improvementsMissileInterceptionAmount = new HashMap<String, Integer>();
	
	//nukes
	boolean nukeAirstrikeEnabled = false;      //flat-out whether or not a faction can use nukes
	boolean nukeMissilestrikeEnabled = false;
	HashMap<String, Integer> nukeMissilestrikeRange = new HashMap<String, Integer>(); //improvement, range
	
	//movements
	int moveUnitBonus = 0;
	int moveFleetBonus = 0;
	boolean moveTransportEnabled = false;   //allows fleets to carry units.
	
	//combat
	int diceBonus = 0;  //improves dice size (base is 1, so for a 1d6 this value should be 5) //###make sure deck is shuffled after one of these techs
	int combatFleetAttackBonusFlat = 0;
	int combatFleetDefenseBonusFlat = 0;
	int combatUnitAttackBonusFlat = 0;
	int combatUnitDefenseBonusFlat = 0;
	
	int combatAmphibiousAssaultBonusFlat = 0;
	
	int combatFleetSizeBonus = 0;  //basically a percent; for example, +1 for every 4 unit advantage would be 25. +1 for every 3, 34. +1 for every 2, 50. etc.
	int combatUnitSizeBonus = 0;
	
	
	//research
	int researchFlatBonus = 0;
	int researchArmyPercentBonus = 0;       //in case you want a tech like, "for every five soldiers you get +1 research" or w/e
	int researchMaxArmyPercentBonus = 0;
	int researchNavyPercentBonus = 0;
	int researchTerritoryPercentBonus = 0;         //research per territories "+1 for every 3 territories" etc.
	int researchAllyPercentBonus = 0;              //bonus for the number of allies, etc
	int researchNeutralPercentBonus = 0;
	int researchEnemyPercentBonus = 0;
	
	//victory!
	boolean victory = false;
	
	
	public Tech() {
		
	}
	
	public String getTechName() {
		return this.techName;
	}
		
	public int getUnitMove(Faction faction) {
		int bonus = 0; 
		
		if (!factionsWithThisTech.contains(faction.getFactionName())) {
			return 0;
		}
		
		bonus += moveUnitBonus;
		
		return bonus;
	}
	

	public int getFleetMove(Faction faction) {
		int bonus = 0; 
		
		if (!factionsWithThisTech.contains(faction.getFactionName())) {
			return 0;
		}
		
		bonus += moveFleetBonus;
		
		return bonus;
	}
	
	//improvementmove
	public List<String> getUnitPassableImprovements(Faction faction) {

		if (!factionsWithThisTech.contains(faction.getFactionName())) {
			return new ArrayList<String>();
		}
		return improvementsUnitPassable;
	}
	
	public List<String> getFleetPassableImprovements(Faction faction) {

		if (!factionsWithThisTech.contains(faction.getFactionName())) {
			return new ArrayList<String>();
		}
		return improvementsFleetPassable;
	}
	
	
	/*
	 * 
	//movements
	boolean moveTransportEnabled = false;   //allows fleets to carry units.
		List<String> improvementsUnitPassable = new ArrayList<String>();  //by default, units cannot cross into areas containing a building unless it's listed here.
	List<String> improvementsFleetPassable = new ArrayList<String>(); //for standard gameplay, all buildings will be listed here since there's no "roadblock" type improvements
	HashMap<String, Integer> improvementsChainable = new HashMap<String, Integer>(); //ie railroads, and how far they can be chained together.
	 */
	
	
	public int getResearchBonus(Faction faction) {
		int bonus = 0;
		
		//does this faction even have this tech?
		if (!factionsWithThisTech.contains(faction.getFactionName())) {
			return 0;
		}
		
		bonus += researchFlatBonus;
		bonus += faction.getMaxUnits()*researchMaxArmyPercentBonus/100;
		bonus += faction.getUnits().size()*researchArmyPercentBonus/100;
		bonus += faction.getFleets().size()*researchNavyPercentBonus/100;
		bonus += faction.getOccupiedTerritories().size()*researchTerritoryPercentBonus/100;
		bonus += faction.getAllies().size()*researchAllyPercentBonus/100;
		bonus += faction.getNeutrals().size()*researchNeutralPercentBonus/100;
		bonus += faction.getEnemies().size()*researchEnemyPercentBonus/100;
		
		//buildings bonus is a bit tricky, gotta check each building for a bonus and tally up how many of each a faction has
		HashMap<Improvement, Integer> totalBuildingsForFaction = new HashMap<Improvement, Integer>();
		for (Improvement improvement : improvements.values()) {
			totalBuildingsForFaction.put(improvement, 0);
		}
		for (String territory : faction.getOccupiedTerritories()) {
			for (String improvement : territories.get(territory).getImprovements().keySet()) {
				totalBuildingsForFaction.put(improvements.get(improvement), totalBuildingsForFaction.get(improvements.get(improvement)) + 1);
			}
		}
		for (String improvementGettingBonus : improvementsResearchPercentBonuses.keySet()) {
			bonus += totalBuildingsForFaction.get(improvementGettingBonus)*improvementsResearchPercentBonuses.get(improvementGettingBonus)/100;
		}
		
		return bonus;
	}
	
	public void parseTech(String techRaw) {
		
		String tokenRegex = ".*?\\[(.*?)\\].*?";
		Matcher match = Pattern.compile(tokenRegex).matcher(techRaw);

		List<Integer> temp = new ArrayList<Integer>();
		if (match.find()) {
			do {
				String[] token = match.group(1).split(":");
				
				try {
					switch(token[0]) {
					//base values
					case "techName":
						techName = token[1];
						break;				
					case "regex":
						regex = match.group(1).substring(match.group(1).indexOf(":")+1);
						break;
					case "displayTech":
						displayTech = true;
						break;
					case "prereqTechs":
						for (int i = 1; i < token.length; i++) {
							prereqTechs.add(token[i]);
						}
						break;
					case "factionsWithThisTech":
						for (int i = 1; i < token.length; i++) {
							factionsWithThisTech.add(token[i]);
						}
						break;
					case "techCost":
						techCost = Integer.valueOf(token[1]);
						break;
					
					//improvements
					case "improvementsEnabled":
						for (int i = 1; i < token.length; i++) {
							improvementsEnabled.add(token[i]);
						}
						break;
					case "improvementsUnitPassable":
						for (int i = 1; i < token.length; i++) {
							improvementsUnitPassable.add(token[i]);
						}
						break;	
					case "improvementsFleetPassable":
						for (int i = 1; i < token.length; i++) {
							improvementsFleetPassable.add(token[i]);
						}
						break;	
					case "improvementsAllowAirstrike":
						improvementsAllowAirstrike.put(token[1], Integer.valueOf(token[2]));
						break;	
					case "improvementsAllowNukeAirstrike":
						improvementsAllowNukeAirstrike.put(token[1], Integer.valueOf(token[2]));
						break;	
					case "improvementsAllowMissilestrike":
						improvementsAllowMissilestrike.put(token[1], Integer.valueOf(token[2]));
						break;	
					case "improvementsResearchPercentBonuses":
						improvementsResearchPercentBonuses.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsChainable":
						improvementsChainable.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsUnitCombatBonus":
						improvementsUnitCombatBonus.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsFleetCombatBonus":
						improvementsFleetCombatBonus.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsUnitCombatBonusNeutral":
						improvementsUnitCombatBonusNeutral.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsFleetCombatBonusNeutral":
						improvementsFleetCombatBonusNeutral.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsUnitCombatBonusRange":
						temp = new ArrayList<Integer>();
						temp.add(Integer.valueOf(token[2]));
						temp.add(Integer.valueOf(token[3]));
						improvementsUnitCombatBonusRange.put(token[1], temp);
						break;
					case "improvementsFleetCombatBonusRange":
						temp = new ArrayList<Integer>();
						temp.add(Integer.valueOf(token[2]));
						temp.add(Integer.valueOf(token[3]));
						improvementsFleetCombatBonusRange.put(token[1], temp);
						break;
						
					//Production Points
					case "prodPointsFlatBonus":
						prodPointsFlatBonus = Integer.valueOf(token[1]);
						break;
					case "improvementsProdPointsBonus":
						improvementsProdPointsPercentBonus.put(token[1], Integer.valueOf(token[2]));
						break;
						
					//Max Army
					case "maxArmyFlatBonus":
						maxArmyFlatBonus = Integer.valueOf(token[1]);
						break;
					case "improvementsMaxArmyBonus":
						improvementsMaxArmyPercentBonus.put(token[1], Integer.valueOf(token[2]));
						break;

					//Spawn Points
					case "improvementsUnitSpawn":
						improvementsUnitSpawn.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsFleetSpawn":
						improvementsFleetSpawn.put(token[1], Integer.valueOf(token[2]));
						break;
						
						
					//airstrikes
					case "airstrikeUnitEnabled":
						airstrikeUnitEnabled = true;
						break;
					case "airstrikeUnitRange:":
						airstrikeUnitRange = Integer.valueOf(token[1]);
						break;
					case "airsupportUnitRange:":
						airsupportUnitRange = Integer.valueOf(token[1]);
						break;
					case "airstrikeFleetEnabled":
						airstrikeFleetEnabled = true;
						break;
					case "airstrikeFleetRange:":
						airstrikeFleetRange = Integer.valueOf(token[1]);
						break;
					case "airsupportFleetRange:":
						airsupportFleetRange = Integer.valueOf(token[1]);
						break;
						
					//anti-air
					case "improvementsAAInterceptionPercent":
						improvementsAAInterceptionPercent.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsMissileInterceptionPercent":
						improvementsMissileInterceptionPercent.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsAAInterceptionAmount":
						improvementsAAInterceptionAmount.put(token[1], Integer.valueOf(token[2]));
						break;
					case "improvementsMissileInterceptionAmount":
						improvementsMissileInterceptionAmount.put(token[1], Integer.valueOf(token[2]));
						break;
						
						
					//nukes
					case "nukeAirstrikeEnabled":
						nukeAirstrikeEnabled = true;
						break;
					case "nukeMissilestrikeEnabled":
						nukeMissilestrikeEnabled = true;
						break;
					case "nukeMissilestrikeRange":
						nukeMissilestrikeRange.put(token[1], Integer.valueOf(token[2]));
						break;
					//movement
					case "moveUnitBonus":
						moveUnitBonus = Integer.valueOf(token[1]);
						break;
					case "moveFleetBonus":
						moveFleetBonus = Integer.valueOf(token[1]);
						break;
					case "moveTransportEnabled":
						moveTransportEnabled = true;
						break;
						
					//combat
					case "diceBonus":
						diceBonus = Integer.valueOf(token[1]);
						break;
					case "combatFleetAttackBonusFlat":
						combatFleetAttackBonusFlat = Integer.valueOf(token[1]);
						break;
					case "combatFleetDefenseBonusFlat":
						combatFleetDefenseBonusFlat = Integer.valueOf(token[1]);
						break;
					case "combatUnitAttackBonusFlat":
						combatUnitAttackBonusFlat = Integer.valueOf(token[1]);
						break;
					case "combatUnitDefenseBonusFlat":
						combatUnitDefenseBonusFlat = Integer.valueOf(token[1]);
						break;
					case "combatAmphibiousAssaultBonusFlat":
						combatAmphibiousAssaultBonusFlat = Integer.valueOf(token[1]);
						break;
					case "combatFleetSizeBonus":
						combatFleetSizeBonus = Integer.valueOf(token[1]);
						break;
					case "combatUnitSizeBonus":
						combatUnitSizeBonus = Integer.valueOf(token[1]);
						break;
					
					//research
					case "researchFlatBonus":
						researchFlatBonus = Integer.valueOf(token[1]);
						break;
					case "researchArmyPercentBonus":
						researchArmyPercentBonus = Integer.valueOf(token[1]);
						break;
					case "researchMaxArmyPercentBonus":
						researchMaxArmyPercentBonus = Integer.valueOf(token[1]);
						break;
					case "researchNavyPercentBonus":
						researchNavyPercentBonus = Integer.valueOf(token[1]);
						break;
					case "researchTerritoryPercentBonus":
						researchTerritoryPercentBonus = Integer.valueOf(token[1]);
						break;
					case "researchAllyPercentBonus":
						researchAllyPercentBonus = Integer.valueOf(token[1]);
						break;
					case "researchNeutralPercentBonus":
						researchNeutralPercentBonus = Integer.valueOf(token[1]);
						break;
					case "researchEnemyPercentBonus":
						researchEnemyPercentBonus = Integer.valueOf(token[1]);
						break;
					
					//victory
					case "victory":
						victory = true;
						break;
					}
					
				} catch(Exception e) {
					System.out.println("Error reading tech file for tech: " + techName);
					System.out.println("-> Attempted to parse: " + token[0]);
					System.out.println(e);
				}
				
			} while (match.find());
			
		}
		
	}

	public List<String> getFactionsWithTech() {
		return factionsWithThisTech;
	}
	
	public void addFactionToTech(String faction) {
		if (!factionsWithThisTech.contains(faction)) {
			factionsWithThisTech.add(faction);
		}
	}

	public String getRegex() {
		return regex;
	}
	
}
/*
 * 
		"Long Range Aircraft"	//Airfields range of 2. Airraids range of 2.
		"Rocketry"				//+1 to all attack rolls.
		"Jet Planes"			//Airfields range of 3. Airraids range of 3.
		"Advanced Rocketry"		//+1 to all attack rolls. Airfields block 2 raids.
		"Nuclear Missiles"		//Allows Missile Silos to be built.
		
		"Advanced Tanks"		//+1 to all attack rolls. +1 to all defense rolls.
		"Mechanized Infantry"	//Ground unit movement of 2.
		"Advanced Tanks MkII"	//+1 to ground attack rolls. +1 to ground defense rolls.
		"Advanced Tanks MkIII"	//+1 to ground attack rolls. +1 to ground defense rolls.
		
		"Oil Revolution"		//+2 PI per turn.
		"Offshore Platforms"	//+1 PI per 2 adjacent Sea Zones (capped to 3, no bonus if enemy fleet in zone).
		"Pesticides"			//+1 Max Army per territory.
		"Plastics"				//+1 PI per turn.
		"Megaurbanization"		//Capitol and Populous provide +4 Max Army.
		"Electric&Diesel Trains"//Railroads allow travel over +1 territories.
		
		"Computers"				//+1 RP per Academy.
		"Nuclear Fission"		//+5 RP per turn.
		"Vaccinations"			//+2 Max Army limit.
		"Advanced Computers"	//+1 RP per Academy.
		"Nuclear Power"			//Allows Nuclear Airstrikes. +1 PI per turn.
		"Antibiotics"			//+2 Max Army limit.
		
		"Aircraft Carriers"		//+1 to navy attack rolls. +1 to navy defense rolls. Airstrikes from Sea Zones.
		"Mixed Fleets"			//+1 to navy attack rolls. +1 to navy defense rolls.
		"Missile Cruisers"		//+1 to navy attack rolls. +1 to navy defense rolls. +1 to amphibious assaults.
		"Nuclear Engines"		//Fleets move 3 per turn.

		"Space Program"			//+5 RP per turn.
		"Satellites"			//+10 RP per turn.
		"Manned Missions"		//+15 RP per turn.
		"Lunar Landing"			//Victory!
		
 */











