package game;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Improvement {

	private String improvementName = "";
	private String regex = "";
	private String iconName = "";
	private boolean displayImprovement = false;          //whether this improvement is to be displayed on the map (e.g. ocean markers wouldn't be displayed). Generally set to true.
	private boolean vulnerableToAirstrikes = false;      //whether improvement can be targetted by an airstrike
	private boolean vulnerableToNukeAirstrikes = false;  //whether this improvement has the chance to be randomly destroyed when the territory is hit with a nuclear air strike
	private boolean vulnerableToMissilestrikes = false;  //as above, but with missile strikes
	private boolean destroyedWithNukes = false;          //whether this improvement is automatically destroyed when the territory is nuked (e.g. populous territories)
	private int unitsRequired = 0;                       //how many units are required to build this improvement (e.g. HQ)
	private int priority = 0;                            //used for what order multiple improvements are displayed in
	
	public Improvement() {
		
	}
	
	public void parseImprovement(String improvementRaw) {
		
		String tokenRegex = ".*?\\[(.*?)\\].*?";
		Matcher match = Pattern.compile(tokenRegex).matcher(improvementRaw);

		List<Integer> temp = new ArrayList<Integer>();
		if (match.find()) {
			do {
				String[] token = match.group(1).split(":");
				
				try {
					switch(token[0]) {
					//base values
					case "improvementName":
						improvementName = token[1];
						break;				
					case "regex":
						regex = match.group(1).substring(match.group(1).indexOf(":")+1);
						break;
					case "iconName":
						iconName = token[1];
						break;
					case "displayImprovement":
						displayImprovement = true;
						break;
					case "vulnerableToAirstrikes":
						vulnerableToAirstrikes = true;
						break;
					case "vulnerableToNukeAirstrikes":
						vulnerableToNukeAirstrikes = true;
						break;
					case "vulnerableToMissilestrikes":
						vulnerableToMissilestrikes = true;
						break;
					case "destroyedWithNukes":
						destroyedWithNukes = true;
						break;
					case "unitsRequired":
						unitsRequired = Integer.valueOf(token[1]);
						break;
					case "priority":
						priority = Integer.valueOf(token[1]);
					}					
				} catch(Exception e) {
					System.out.println("Error reading improvement file for improvement: " + improvementName);
					System.out.println("-> Attempted to parse: " + token[0]);
					System.out.println(e);
				}
				
			} while (match.find());
			
		}
		
	}

	public String getImprovementName() {
		return improvementName;
	}

	public void setImprovementName(String improvementName) {
		this.improvementName = improvementName;
	}

	public String getRegex() {
		return regex;
	}

	public void setRegex(String regex) {
		this.regex = regex;
	}

	public String getIconName() {
		return iconName;
	}

	public void setIconName(String iconName) {
		this.iconName = iconName;
	}

	public boolean isDisplayImprovement() {
		return displayImprovement;
	}

	public void setDisplayImprovement(boolean displayImprovement) {
		this.displayImprovement = displayImprovement;
	}

	public boolean isVulnerableToAirstrikes() {
		return vulnerableToAirstrikes;
	}

	public void setVulnerableToAirstrikes(boolean vulnerableToAirstrikes) {
		this.vulnerableToAirstrikes = vulnerableToAirstrikes;
	}

	public boolean isVulnerableToNukeAirstrikes() {
		return vulnerableToNukeAirstrikes;
	}

	public void setVulnerableToNukeAirstrikes(boolean vulnerableToNukeAirstrikes) {
		this.vulnerableToNukeAirstrikes = vulnerableToNukeAirstrikes;
	}

	public boolean isVulnerableToMissilestrikes() {
		return vulnerableToMissilestrikes;
	}

	public void setVulnerableToMissilestrikes(boolean vulnerableToMissilestrikes) {
		this.vulnerableToMissilestrikes = vulnerableToMissilestrikes;
	}

	public boolean isDestroyedWithNukes() {
		return destroyedWithNukes;
	}

	public void setDestroyedWithNukes(boolean destroyedWithNukes) {
		this.destroyedWithNukes = destroyedWithNukes;
	}

	public int getUnitsRequired() {
		return unitsRequired;
	}

	public void setUnitsRequired(int unitsRequired) {
		this.unitsRequired = unitsRequired;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	
	
}