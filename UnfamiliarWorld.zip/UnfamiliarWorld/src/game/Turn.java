package game;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.io.Serializable;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.*;
import java.awt.Color;

public class Turn extends Game {

	private static int turn;
	private static int year;	
	private static String month;
	private static HashMap<String, String> turnReport = new HashMap<String, String>();
	private static HashMap<String, List<String>> parsedOrders = new HashMap<String, List<String>>();
	
	public Turn(int turn, int year, String month) {
		this.turn = turn;
		this.year = year;
		this.month = month;
	}
	
	
	public void startRound() throws IOException {

		// Update turn/month/year
		incrimentTurn();
		
		// Input Commands
		String rawOrders = readTextFile("Orders_" + year + "_" + month);
		
		// Parse and Separate
		parsedOrders = CommandParser.parseCommandBlock(rawOrders);
		for (String a : parsedOrders.keySet()) {
			for (String b : parsedOrders.get(a)) {

				System.out.println(b);
			}
		}
		// add order slots for nations that didnt give orders
		fillVacantOrders();
		
		//diplomacy
		String turnReportDiplo = parseDiplomacy();
		turnReport.put("diplomacy", turnReportDiplo);
		System.out.println(turnReportDiplo); //for debugging
		
				
		//airstrike
		String turnReportAirstrike = parseAirstrike();
		turnReport.put("airstrike", turnReportAirstrike);
		System.out.println(turnReportAirstrike);
		
		//Nuke Air Strike
		String turnReportNukeAirstrike = parseNukeAirstrike();
		turnReport.put("nukeairstrike", turnReportNukeAirstrike);
		System.out.println(turnReportNukeAirstrike);
		

		//Nuke Missile Strike
		String turnReportNukeMissile = parseNukeMissile();
		turnReport.put("nukemissile", turnReportNukeMissile);
		System.out.println(turnReportNukeMissile);
		
		//fallout damage
		String turnReportFalloutDamage = processFalloutDamage();
		turnReport.put("falloutdamage", turnReportFalloutDamage);
		System.out.println(turnReportFalloutDamage);

		//reset navy move
		resetNavyMove();
		
		//navy movement
		String turnReportNavyMove = parseNavyMove();
		turnReport.put("navymove", turnReportNavyMove);
		System.out.println(turnReportNavyMove);
		
		//navy combat
		String turnReportNavyCombat = parseNavyCombat();
		turnReport.put("navycombat", turnReportNavyCombat);
		System.out.println(turnReportNavyCombat);

		//reset unit move
		resetUnitMove();
		
		//navy movement
		String turnReportUnitMove = parseUnitMove();
		turnReport.put("unitmove", turnReportUnitMove);
		System.out.println(turnReportUnitMove);
		
		//navy combat
		String turnReportUnitCombat = parseUnitCombat();
		turnReport.put("unitcombat", turnReportUnitCombat);
		System.out.println(turnReportUnitCombat);
	}//end start round
			
	//xUpdate turn/month/year
	//xRead in commands
	//xParse and separate commands
	//xFill Vacant Orders	
	//xDiplomacy
	//xAirstrike
	//xNuke air Strike
	//xNuke Missile strike
	//xfallout damage
	//xReset Navy Move
	//xNavy Movement
	//xNavy Combat
	// Unit Movement
	// Check Valid terrain
	// Check Rails
	// Check sea travel
	// Sea Approval
	// Lock Sea unit
	// Update prev/current territory
	// Combat
	// Iterate through all territories
	// Iterate through all units in a territory
	// While enemy:
	// get total bonuses
	// combat roll loop
	// get #'s advantage'roll+bonuses
	// loser loses 1 unit
	// tie, both lose 1
	// declare winner
	// if no Enemy and in enemy territory, claim territory and damage improvement
	// iterate through all territories/units
	// combine units
	// update previous/current territory
	// build improvements
	// decommission units
	// deincriment fallout
	// update possible unit max limit
	// update players unit limits
	// update player PI limit
	// update player nuke air limit
	// update player nuke missile limit
	// spawn units
	// Get/Give Tech
	// count research points
	// change research, if selected
	// update research count
	// Get/Give Territory
	// flip "broken" exchange pacts to "open"
	// reset territory interceptions to 0
	// reset player nuke airstrike this turn (to 0)
	// recompute PI
	// recompute nukeairlimit (PI/2)
	// reset player nuke missile strikes this turn (to 0)
	// recompute nukemissilelimite (PI/3)
	// reset silo launches for territory (to 0)
	// draw map

	
	
	//###need to integrate unit transport into this
	public static String parseUnitCombat() {
		String turnReportUnitCombat = "";
		int movePhase = 0;
		
		while (unitCanMove(movePhase)) { 
		
			turnReportUnitCombat += "\n[b][i][u]Army Turn/Move Phase " + movePhase + "[/u][/i][/b]\n";
			
			HashMap<String, HashMap<String, HashMap<String, Set<Unit>>>> allUnits = new HashMap<String, HashMap<String, HashMap<String, Set<Unit>>>>(); //curr, prev, faction
		
			//going through each unit from each faction
			//if the path doesn't exist in allUnits, we add it
			for (String faction : factions.keySet()) {
				for (Unit unit : factions.get(faction).getUnits()) {
					
					unit.getPrevCurr(movePhase);
					String curr = unit.getCurrent();
					String prev = unit.getPrevious();
					
					if (!allUnits.containsKey(curr)) {
						allUnits.put(curr, new HashMap<String, HashMap<String, Set<Unit>>>());
					}
						
					if (!allUnits.get(curr).containsKey(prev)) {
						allUnits.get(curr).put(prev, new HashMap<String, Set<Unit>>());
					}
					
					if (!allUnits.get(curr).get(prev).containsKey(faction)) {
						allUnits.get(curr).get(prev).put(faction, new HashSet<Unit>());
					}
					
					allUnits.get(curr).get(prev).get(faction).add(unit);					
				}
			}
			
			//bypass combat
			for (String currentTerritory : orderLandZones(allUnits.keySet())) {

				for (String previousTerritory : orderLandZones(allUnits.get(currentTerritory).keySet())) {

					for (String currentFaction : orderFactions(allUnits.get(currentTerritory).get(previousTerritory).keySet())) { //start parsing through factions in a territory by priority

						if (!unitCanFight(allUnits.get(currentTerritory).get(previousTerritory).get(currentFaction))) { //if this unit has already been destroyed, skip it
							continue;
						}

						try {
							HashMap<String, Set<Unit>> crossedFactions = allUnits.get(previousTerritory).get(currentTerritory); //if there's at least 1 faction that crossed the path (even self) 
							
							//now check to see if the ships crossed are their own or allied/neutral
							for (String crossedFaction : orderFactions(crossedFactions.keySet())) {

								if (!crossedFaction.equals(currentFaction)) { //if it's not their own ships
									
									if (factions.get(crossedFaction).getDiplomacySpecific(currentFaction).equals("war")) { //if they are at war

										if (!unitCanFight(allUnits.get(previousTerritory).get(currentTerritory).get(crossedFaction))) { //if the enemy unit has already been destroyed, skip it
											continue;
										}
										if (!unitCanFight(allUnits.get(currentTerritory).get(previousTerritory).get(currentFaction))) { //if the current unit been destroyed in previous, skip this.
											continue;
										}

										//NOW we can do the combat.
										Set<Unit> availableCurrentUnit = getFightingUnits(allUnits.get(currentTerritory).get(previousTerritory).get(currentFaction));
										Set<Unit> availableCrossedUnit = getFightingUnits(allUnits.get(previousTerritory).get(currentTerritory).get(crossedFaction));

										 turnReportUnitCombat += runUnitCombat(currentFaction, availableCurrentUnit, crossedFaction, availableCrossedUnit, true);
									}
								}	
							}
						} catch (NullPointerException e) {}
					}	
				}
			}
			
			//rebuild allUnits2 for regular combat (remove destroyed ships, build it without previous territory, etc)
			//--
			//remove dead ships from each faction unit set
			for (String faction : factions.keySet()) {
				Set<Unit> newUnit = new HashSet<Unit>();
				for (Unit unit : factions.get(faction).getUnits()) {
					if (!unit.isToBeRemoved()) {
						newUnit.add(unit);
					}
				}
				factions.get(faction).setUnits(newUnit);
			}
			
			//allships2
			HashMap<String, HashMap<String, Set<Unit>>> allUnits2 = new HashMap<String, HashMap<String, Set<Unit>>>(); //curr, faction
			for (String faction : factions.keySet()) {
				for (Unit unit : factions.get(faction).getUnits()) {
					unit.getPrevCurr(movePhase); //###redundant, remove this line
					String curr = unit.getCurrent();
					
					if (!allUnits2.containsKey(curr)) {
						allUnits2.put(curr, new HashMap<String, Set<Unit>>());
					}
					
					if (!allUnits2.get(curr).containsKey(faction)) {
						allUnits2.get(curr).put(faction, new HashSet<Unit>());
					}
					
					allUnits2.get(curr).get(faction).add(unit);					
				}
			}
			// --
			
			//regular combat
			for (String currentTerritory : orderLandZones(allUnits2.keySet())) {
				
				for (String currentFaction : orderFactions(allUnits2.get(currentTerritory).keySet())) { //start parsing through factions in a territory by priority
					
					if (!unitCanFight(allUnits2.get(currentTerritory).get(currentFaction))) { //if this unit has already been destroyed, skip it.  probably redundant, see duplicate below
						continue;
					}
					try {
						HashMap<String, Set<Unit>> crossedFactions = allUnits2.get(currentTerritory); //if there's at least 1 faction that crossed the path (even self) 
						
						//now check to see if the ships crossed are their own or allied/neutral
						for (String crossedFaction : orderFactions(crossedFactions.keySet())) {
							
							if (!crossedFaction.equals(currentFaction)) { //if it's not their own ships
								
								if (factions.get(crossedFaction).getDiplomacySpecific(currentFaction).equals("war")) { //if they are at war
									
									if (!unitCanFight(allUnits2.get(currentTerritory).get(crossedFaction))) { //if the enemy unit has already been destroyed, skip it
										continue;
									}
									if (!unitCanFight(allUnits2.get(currentTerritory).get(currentFaction))) { //if the current unit been destroyed in previous, skip this.
										continue;
									}
									
									//NOW we can do the combat.
									Set<Unit> availableCurrentUnit = getFightingUnits(allUnits2.get(currentTerritory).get(currentFaction));
									Set<Unit> availableCrossedUnit = getFightingUnits(allUnits2.get(currentTerritory).get(crossedFaction));
									
									turnReportUnitCombat += runUnitCombat(currentFaction, availableCurrentUnit, crossedFaction, availableCrossedUnit, false);
								}
							}	
						}
					} catch (NullPointerException e) {}
				}	
				
			}
			
			//now, remove the destroyed units from the factions unit set
			for (String faction : factions.keySet()) {
				Set<Unit> newUnit = new HashSet<Unit>();
				for (Unit unit : factions.get(faction).getUnits()) {
					if (!unit.isToBeRemoved()) {
						newUnit.add(unit);
					}
				}
				factions.get(faction).setUnits(newUnit);
			}

			//progress movePhase			
			movePhase++;
		}
		
		System.out.println(turnReportUnitCombat);

		return turnReportUnitCombat = "";
		
	}
	
	public static boolean unitCanMove(int movePhase) {
		for (Faction faction : factions.values()) {
			for (Unit unit : faction.getUnits()) {
				if (movePhase < unit.getMoveList().size()) {
					return true;
				}
			}
		}
		return false;		
	}
	
	public static boolean unitCanFight(Set<Unit> mixedUnit) {
		for (Unit unit : mixedUnit) {
			if (!unit.isToBeRemoved()) {
				return true;
			}
		}
		return false;
	}
	
	
	public static Set<Unit> getFightingUnits(Set<Unit> mixedUnit) {
		Set<Unit> fightingUnit = new HashSet<Unit>();
		
		for (Unit unit : mixedUnit) {
			if (!unit.isToBeRemoved()) {
				fightingUnit.add(unit);
			}
		}
		
		return fightingUnit;
	}
	
	public static List<String> orderLandZones(Set<String> unsortedlz) {
		List<String> sortedlz = new ArrayList<String>();
		sortedlz.addAll(unsortedlz); 

		Collections.sort(sortedlz, new SortByLandZone());
			
		return sortedlz;
	}
	
	
	public static String runUnitCombat(String faction1, Set<Unit> moveGroup1, String faction2, Set<Unit> moveGroup2, boolean bypass) {
		String combatReport = "";
		Unit ftemp1 = null;
		
		for (Unit ftemp : moveGroup1) { ftemp1 = ftemp; break; }
		String territory1 = ftemp1.getCurrent();
		String territory2 = ftemp1.getPrevious();
		if (bypass && !(ftemp1.getCurrent().equals(ftemp1.getPrevious()))) {
			combatReport += "[b]" + facSwap(faction1) + "[/b] and [b]" + facSwap(faction2) + "[/b] encounter one another as they cross the border of " 
					+ territory1 + " and " + territory2 + ".\n[spoiler=Combat: " + facSwap(faction1) + " and " + facSwap(faction2) + " between "+ territory1 + " and " + territory2 + "]\n";
		}
		else {
			String territory = "";
			for (Unit unit : moveGroup1) {  //### maybe switch this to some collection method that lets you query a specific element?
				territory = unit.getCurrent();
				break;
			}
			combatReport += "[b]" + facSwap(faction1) + "[/b] and [b]" + facSwap(faction2) + "[/b] encounter one another in " 
					+ territory + ".\n[spoiler=Combat: " + facSwap(faction1) + " and " + facSwap(faction2) + " in "+ territory + "]\n";
		}
			
			
		int bonus1 = 0;
		int bonus2 = 0;
		//tech check 
		//### maybe one day switch this so that the tech's know what advantage they provide, and a method in the faction that returns the total technological advantage for the requested situation rather than having it hard-coded like this
		//Rocketry
		if (factions.get(faction1).getAllResearchedTech().contains("Rocketry")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Rocketry")) {
			bonus2++;
		}
		//Advanced Rocketry
		if (factions.get(faction1).getAllResearchedTech().contains("Advanced Rocketry")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Advanced Rocketry")) {
			bonus2++;
		}
		//Advanced Tanks
		if (factions.get(faction1).getAllResearchedTech().contains("Advanced Tanks")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Advanced Tanks")) {
			bonus2++;
		}
		//Advanced Tanks MkII
		if (factions.get(faction1).getAllResearchedTech().contains("Advanced Tanks MkII")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Advanced Tanks MkII")) {
			bonus2++;
		}
		//Advanced Tanks MkIII
		if (factions.get(faction1).getAllResearchedTech().contains("Advanced Tanks MkIII")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Advanced Tanks MkIII")) {
			bonus2++;
		}

		//Airfield Bonus
		Faction tempFaction = factions.get(faction1);
		tempFaction = factions.get(faction2);
		if (bypass) {
			int range1 = 1;
			if (factions.get(faction1).getAllResearchedTech().contains("Long Range Aircraft")) {
				range1++;
			}
			if (factions.get(faction1).getAllResearchedTech().contains("Jet Planes")) {
				range1++;
			}
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(range1)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= range1) {     //make sure it's within range of the other territory
						if (factions.get(faction1).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus1++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction1).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus1++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
			
			int range2 = 1;
			if (factions.get(faction2).getAllResearchedTech().contains("Long Range Aircraft")) {
				range2++;
			}
			if (factions.get(faction2).getAllResearchedTech().contains("Jet Planes")) {
				range2++;
			}
			found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(range2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= range2) {     //make sure it's within range of the other territory
						if (factions.get(faction2).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus2++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction2).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus2++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
		} 
		if (!bypass) {
			int range1 = 1;
			if (factions.get(faction1).getAllResearchedTech().contains("Long Range Aircraft")) {
				range1++;
			}
			if (factions.get(faction1).getAllResearchedTech().contains("Jet Planes")) {
				range1++;
			}
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(range1)) { //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                   //make sure they have an airfield
					if (factions.get(faction1).checkOccupiedTerritory(territory)) {               //make sure player owns the territory
						bonus1++;                                                                       //if all this is true, give them the airfield bonus
						break;
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction1).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus1++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}
			
			int range2 = 1;
			if (factions.get(faction2).getAllResearchedTech().contains("Long Range Aircraft")) {
				range2++;
			}
			if (factions.get(faction2).getAllResearchedTech().contains("Jet Planes")) {
				range2++;
			}
			for (String territory : territories.get(territory2).getAllWithinDistance(range2)) { //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                   //make sure they have an airfield
					if (factions.get(faction2).checkOccupiedTerritory(territory)) {               //make sure player owns the territory
						bonus2++;                                                                       //if all this is true, give them the airfield bonus
						break;
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction2).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus2++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}
		}
		
		//Silo Bonus
		if (bypass) {
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= 2) {     //make sure it's within range of the other territory
						if (factions.get(faction1).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus1++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction1).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus1++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
			
			
			found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= 2) {     //make sure it's within range of the other territory
						if (factions.get(faction2).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus2++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction2).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus2++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
		} 
		if (!bypass) {
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (factions.get(faction1).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
						bonus1++;                                                             //if all this is true, give them the airfield bonus
						found = true;
						break;
						
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction1).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus1++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}			
			
			found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (factions.get(faction2).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
						bonus2++;                                                             //if all this is true, give them the airfield bonus
						found = true;
						break;
						
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction2).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus2++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}
		}
		
		//combat loop
		int round = 0;
		while ((moveGroup1.size() > 0)&&(moveGroup2.size() > 0)) {
			round++;
			int roundbonus1 = bonus1;
			int roundbonus2 = bonus2;			

			if (moveGroup1.size() > moveGroup2.size()) {
				roundbonus1 += (int) Math.floor((moveGroup1.size() - moveGroup2.size())/2);
			}
			if (moveGroup1.size() < moveGroup2.size()) {
				roundbonus2 += (int) Math.floor((moveGroup2.size() - moveGroup1.size())/2);
			}
			
			
			//now for the actual combat! 
			int roll1 = factions.get(faction1).pullCard();
			int roll2 = factions.get(faction2).pullCard();
			int sum1 = roll1 + roundbonus1;
			int sum2 = roll2 + roundbonus2;
			
			combatReport += "[b][u]Round " + round + ":[/u][/b]\n";
			
			//if both roll a 1
			if ((roll1 == 1)&&(roll2 == 1)) {


				if (moveGroup1.size() > 1) {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " units) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " unit) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				}
				if (moveGroup2.size() > 1) {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " units) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " unit) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				}
				combatReport += "Both sides have rolled a 1.  Both sides lose a unit!\n\n";
				
				for (Unit unit : moveGroup1) {  
					unit.setToBeRemoved(true);
					moveGroup1.remove(unit);
					break;
				}
				for (Unit unit : moveGroup2) { 
					unit.setToBeRemoved(true);
					moveGroup2.remove(unit);
					break;
				}
			}
			//if one rolls a 1
			else if ((roll1 == 1)&&(roll2 != 1)) {
				if (moveGroup1.size() > 1) {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " units) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " unit) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				}
				if (moveGroup2.size() > 1) {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " units) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = " + sum2 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " unit) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = " + sum2 + "\n";
				}
				combatReport += "[b]" + facSwap(faction1) + "[/b] has rolled a 1 - [b]" + facSwap(faction2) + "[/b] wins!\n\n";
				
				for (Unit unit : moveGroup1) {  
					unit.setToBeRemoved(true);
					moveGroup1.remove(unit);
					break;
				}
			}
			//if the other rolls a 1
			else if ((roll1 != 1)&&(roll2 == 1)) {
				if (moveGroup1.size() > 1) {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " units) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = " + sum1 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " unit) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = " + sum1 + "\n";
				}
				if (moveGroup2.size() > 1) {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " units) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " unit) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				}
				combatReport += "[b]" + facSwap(faction2) + "[/b] has rolled a 1 - [b]" + facSwap(faction1) + "[/b] wins!\n\n";
				
				for (Unit unit : moveGroup2) { 
					unit.setToBeRemoved(true);
					moveGroup2.remove(unit);
					break;
				}
			}
			//if it's a tie (with bonuses)
			else {
				if ((sum1 == sum2)) { //### should both sides lose a unit in a tie?  Or should it just bounce and they try again?
					if (moveGroup1.size() > 1) {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " units) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " unit) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					}
					if (moveGroup2.size() > 1) {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " units) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " unit) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					}
					combatReport += "[b]" + facSwap(faction1) + "[/b] and [b]" + facSwap(faction2) + "[/b] are tied - both sides lose a unit!\n\n";

					for (Unit unit : moveGroup1) {  
						unit.setToBeRemoved(true);
						moveGroup1.remove(unit);
						break;
					}
					
					for (Unit unit : moveGroup2) { 
						unit.setToBeRemoved(true);
						moveGroup2.remove(unit);
						break;
					}
				}

				//if one side has the higher roll (with bonuses)
				else if ((sum1 > sum2)) {
					if (moveGroup1.size() > 1) {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " units) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " unit) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					}
					if (moveGroup2.size() > 1) {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " units) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " unit) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					}
					combatReport += "[b]" + facSwap(faction1) + "[/b] wins!\n\n";
					
					for (Unit unit : moveGroup2) { 
						unit.setToBeRemoved(true);
						moveGroup2.remove(unit);
						break;
					}
				}

				//if the other side has the higher roll (with bonuses)
				else if ((sum1 < sum2)) {
					if (moveGroup1.size() > 1) {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " units) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " unit) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					}
					if (moveGroup2.size() > 1) {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " units) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " unit) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					}
					combatReport += "[b]" + facSwap(faction2) + "[/b] wins!\n\n";
					
					for (Unit unit : moveGroup1) { 
						unit.setToBeRemoved(true);
						moveGroup1.remove(unit);
						break;
					}
				}
			}
		}//end combat loop
		
		//find out if one side won or if it was a tie
		if ((moveGroup1.size() == 0)&&(moveGroup2.size() == 0)) {
			combatReport += "Both sides have been destroyed!";
		}
		else if (moveGroup1.size() > 0) {
			if (moveGroup1.size() == 1) {
				combatReport += "[b]" + facSwap(faction1) + "[/b] wins with " + moveGroup1.size() + " unit remaining.";
			}
			else {
				combatReport += "[b]" + facSwap(faction1) + "[/b] wins with " + moveGroup1.size() + " units remaining.";
			}
		}
		else {
			if (moveGroup2.size() == 1) {
				combatReport += "[b]" + facSwap(faction2) + "[/b] wins with " + moveGroup2.size() + " unit remaining.";
			}
			else {
				combatReport += "[b]" + facSwap(faction2) + "[/b] wins with " + moveGroup2.size() + " units remaining.";
			}
		}
		
		combatReport += "\n[/spoiler]\n\n";
		
		return combatReport;		
	}
	
	

	public static void resetUnitMove() {
		for (String facName : factions.keySet()) {//HashMap<String, List<Unit>> units 
			for (Unit unit : factions.get(facName).getUnits()) {
				List<String> temp = new ArrayList<String>();
				temp.add(unit.getMoveList().get(unit.getMoveList().size()-1));
				unit.setMoveList(temp);
			} 
		}
	}
	
	
	public static String parseUnitMove2() {
		//###uuugh, I need to reformat parsedOrders to be a hashmap of lists of array so I don't have to do this splitline bullshit.
		//###uuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuuugh hindsight is a wonderful thing uuuuuuuuuuuuuugh

		// "moveUnit - numberUnits - source(sz#) - end(sz#) - midpoint(optional)(sz#) - midpoint(optional)(sz#)"
		
		
		//### really need to un-hard code this.  Make movements a loop; dynamic.
		//### additionally, this splitline business is silly.  Just make it an array of strings; 
		//### this way if a territory is a word rather than a number (e.g. "Gulf of Mexico" etc) it wont break
		String turnReportUnitMove = "";
		
		//iterate through all factions
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders

			for (String orderLine : parsedOrders.get(factionName)) {
			
				if (orderLine.split(" ")[0].equals("moveUnit")) {

					String[] splitLine = orderLine.split(" ");
					String faction = factionName;
					String unitNumber = splitLine[1];
					List<String> moveOrder = new ArrayList<String>();
					moveOrder.add(splitLine[2]);
					for (int i = 4; i < splitLine.length; i++) {
						moveOrder.add(splitLine[i]);
					}
					moveOrder.add(splitLine[3]);
					
					//confirm moveOrder is connected in line
					
					
					
					
					
					
					String source = splitLine[2];
					String target = splitLine[3];
										
					if (splitLine.length == 4) { //move 1 
						//###make sure the territory is enemy or allied
						//###currently it moves through all territories or fails for all.
						//there's a unit in source
						//at least 1 unit that hasn't moved
						//move each unit 1 by 1 until the unitnumber has been met, updating previous and current territories
						if (factions.get(faction).unitIn(source)) {
							int unitsAvailable = 0;
							for (Unit unit : factions.get(faction).getUnitsIn(source)) {
								if (!unit.isMovedThisTurn()) {
									unitsAvailable++;
								}
							}
							if (unitsAvailable == 0) { //all units in that zone have moved already
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
							}
							
							
							//if target territory is not allied, enemy, or ###neutral, then fail
							boolean canPass = false;
							for (String ally : factions.get(faction).getAllies()) {
								if (factions.get(ally).checkOccupiedTerritory(target)) {
									canPass = true;
									break;
								}
							}
							if (!canPass) {
								for (String enemy : factions.get(faction).getEnemies()) {
									if (factions.get(enemy).checkOccupiedTerritory(target)) {
										canPass = true;
										break;
									}
								}
							}
							if (!canPass) { //###seriously, I can reduce this if statement for an "s" down to a couple lines.  This is silly.
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
							}
							
							//if unitsavailable > 0 and unitnumbercopy > 0
							//move 1 unit, decriment unitsavailable and unitnumbercopy
							//when either hit 0
							//if unitnumbercopy != 0, announce that there were only (unitnumber-unitnumbercopy) units available to move
							//else, announce unitnumber of ships moved
							int unitNumberCopy = Integer.parseInt(unitNumber);
							while ((unitNumberCopy > 0)&&(unitsAvailable > 0)) {
								unitNumberCopy--;
								unitsAvailable--;
								
								
								for (Unit unitToMove : factions.get(faction).getUnitsIn(source)) {
									if (!unitToMove.isMovedThisTurn() ) {
										unitToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, target)));
										unitToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (unitNumberCopy != 0) {
								int moved = Integer.parseInt(unitNumber) - unitNumberCopy;
								if (Integer.parseInt(unitNumber) > 1 ) {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + ", but they were only able to move " + moved + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(unitNumber) > 1 ) {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " units from " + source + " to " + target +".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " unit from " + source + " to " + target +".\n";
								}
							}
						//there were no units in the zone to move	
						}
						else {
							if (Integer.parseInt(unitNumber) > 1 ) {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " units from " + source + " to " + target + ", but they don't have any units in that territory!\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " unit from " + source + " to " + target + ", but they don't have any units in that territory!\n";
								continue;
							}
						}
						
						
						//###make sure they have a train route *or* mech infantry
					} else if (splitLine.length == 5) { //move 2 

						String midpoint1 = splitLine[4];
						
						//make sure midpoint is actually connected to both territories 
						//### need to let midpoint be equal to one of these territories, for delaying actions
						if (!(territories.get(midpoint1).getConnectedTerritoriesList().contains(source)&&territories.get(midpoint1).getConnectedTerritoriesList().contains(target))) {
							if (Integer.parseInt(unitNumber) > 1 ) { 
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " units from " + source + " to " + target + " through " + midpoint1 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						if (factions.get(faction).unitIn(source)) {
							int unitsAvailable = 0;
							for (Unit unit : factions.get(faction).getUnitsIn(source)) {
								if (!unit.isMovedThisTurn()) {
									unitsAvailable++;
								}
							}
							if (unitsAvailable == 0) { //all units in that zone have moved already
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
							}
							
							//if target territory is not allied, enemy, or ###neutral, then fail
							//###this doesn't work; it only checks to see if BOTH are allied controled or BOTH ar enemy controlled
							boolean canPass = false;
							for (String ally : factions.get(faction).getAllies()) {
								if (factions.get(ally).checkOccupiedTerritory(midpoint1) || factions.get(ally).checkOccupiedTerritory(target)) {
									canPass = true;
									break;
								}
							}
							if (!canPass) {
								for (String enemy : factions.get(faction).getEnemies()) {
									if (factions.get(enemy).checkOccupiedTerritory(midpoint1) || factions.get(enemy).checkOccupiedTerritory(target)) {
										canPass = true;
										break;
									}
								}
							}
							if (!canPass) { 
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + midpoint1 + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + midpoint1 + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
							}
							
							//move the units
							int unitNumberCopy = Integer.parseInt(unitNumber);
							while ((unitNumberCopy > 0)&&(unitsAvailable > 0)) {
								unitNumberCopy--;
								unitsAvailable--;
								
								
								for (Unit unitToMove : factions.get(faction).getUnitsIn(source)) {
									if (!unitToMove.isMovedThisTurn() ) {
										unitToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, midpoint1, target)));
										unitToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (unitNumberCopy != 0) {
								int moved = Integer.parseInt(unitNumber) - unitNumberCopy;
								if (Integer.parseInt(unitNumber) > 1 ) {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + " through " + midpoint1 + ", but they were only able to move " + moved + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(unitNumber) > 1 ) {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " units from " + source + " to " + target + " through " + midpoint1 + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " unit from " + source + " to " + target + " through " + midpoint1 + ".\n";
								}
							}
						//there were no units in the zone to move	
						}
						else {
							if (Integer.parseInt(unitNumber) > 1 ) {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " units from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory!\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory!\n";
								continue;
							}
						}
					}

					
					else if (splitLine.length == 6) { //move 3

						String midpoint1 = splitLine[4];
						String midpoint2 = splitLine[5];
						
						//check, make sure they have Nuclear Engines
						if (!factions.get(faction).getAllResearchedTech().contains("Nuclear Engines")) {
							turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
									+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have the Nuclear Engines technology researched!\n";
							continue;
						}
						
						//may need to redo this bit; loop: check 1 connected to 2, check 2 connected 3, etc.
						
						//make sure midpoint1 is actually connected to source and midpoint2
						if (!(territories.get(midpoint1).getConnectedTerritoriesList().contains(source)&&territories.get(midpoint1).getConnectedTerritoriesList().contains(midpoint2))) {
							if (Integer.parseInt(unitNumber) > 1 ) { 
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						//make sure midpoint2 is actually connected to target and midpoint1
						if (!(territories.get(midpoint2).getConnectedTerritoriesList().contains(target)&&territories.get(midpoint2).getConnectedTerritoriesList().contains(midpoint1))) {
							if (Integer.parseInt(unitNumber) > 1 ) { 
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						if (factions.get(faction).unitIn(source)) {
							int shipsAvailable = 0;
							for (Unit unit : factions.get(faction).getUnitsIn(source)) {
								if (!unit.isMovedThisTurn()) {
									shipsAvailable++;
								}
							}
							if (shipsAvailable == 0) { //all ships in that zone have moved already
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
							}
							
							//move the ships
							int unitNumberCopy = Integer.parseInt(unitNumber);
							while ((unitNumberCopy > 0)&&(shipsAvailable > 0)) {
								unitNumberCopy--;
								shipsAvailable--;
								
								
								for (Unit unitToMove : factions.get(faction).getUnitsIn(source)) {
									if (!unitToMove.isMovedThisTurn() ) {
										unitToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, midpoint1, midpoint2, target)));
										unitToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (unitNumberCopy != 0) {
								int moved = Integer.parseInt(unitNumber) - unitNumberCopy;
								if (Integer.parseInt(unitNumber) > 1 ) {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they were only able to move " + moved + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(unitNumber) > 1 ) {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ".\n";
								}
							}
						//there were no units in the zone to move	
						}
						else {
							if (Integer.parseInt(unitNumber) > 1 ) {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
						}
						
					}

				//get number of move
				//1
				//confirm source is adjacent to end, move.  
				//
				//2
				//confirm midpoint is adjacent to both end and source, move.
				//
				//3
				//confirm nuclear engines is researched.
				//confirm midpoints are adjacent to one another.  
				//confirm mid1 is adjacent to source
				//confirm mid2 is adjacent to target
				//
				//update previous/current territory
				}
			}
		}
		
		
		return turnReportUnitMove;
	}
	
	

	public static String parseUnitMove() {

		// "moveUnit - numberUnits - source(sz#) - end(sz#) - midpoint(optional)(sz#) - midpoint(optional)(sz#)"
		
		
		//### really need to un-hard code this.  Make movements a loop; dynamic.
		//### additionally, this splitline business is silly.  Just make it an array of strings; 
		//### this way if a territory is a word rather than a number (e.g. "Gulf of Mexico" etc) it wont break
		String turnReportUnitMove = "";
		
		//iterate through all factions
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders

			for (String orderLine : parsedOrders.get(factionName)) {
			
				if (orderLine.split(" ")[0].equals("moveUnit")) {

					//nukebomb startzone endzone
					String[] splitLine = orderLine.split(" ");
					String faction = factionName;
					String unitNumber = splitLine[1];
					String source = splitLine[2];
					String target = splitLine[3];
										
					if (splitLine.length == 4) { //move 1 
						//###make sure the territory is enemy or allied
						//###currently it moves through all territories or fails for all.
						//there's a unit in source
						//at least 1 unit that hasn't moved
						//move each unit 1 by 1 until the unitnumber has been met, updating previous and current territories
						if (factions.get(faction).unitIn(source)) {
							int unitsAvailable = 0;
							for (Unit unit : factions.get(faction).getUnitsIn(source)) {
								if (!unit.isMovedThisTurn()) {
									unitsAvailable++;
								}
							}
							if (unitsAvailable == 0) { //all units in that zone have moved already
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
							}
							
							
							//if target territory is not allied, enemy, or ###neutral, then fail
							boolean canPass = false;
							for (String ally : factions.get(faction).getAllies()) {
								if (factions.get(ally).checkOccupiedTerritory(target)) {
									canPass = true;
									break;
								}
							}
							if (!canPass) {
								for (String enemy : factions.get(faction).getEnemies()) {
									if (factions.get(enemy).checkOccupiedTerritory(target)) {
										canPass = true;
										break;
									}
								}
							}
							if (!canPass) { //###seriously, I can reduce this if statement for an "s" down to a couple lines.  This is silly.
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
							}
							
							//if unitsavailable > 0 and unitnumbercopy > 0
							//move 1 unit, decriment unitsavailable and unitnumbercopy
							//when either hit 0
							//if unitnumbercopy != 0, announce that there were only (unitnumber-unitnumbercopy) units available to move
							//else, announce unitnumber of ships moved
							int unitNumberCopy = Integer.parseInt(unitNumber);
							while ((unitNumberCopy > 0)&&(unitsAvailable > 0)) {
								unitNumberCopy--;
								unitsAvailable--;
								
								
								for (Unit unitToMove : factions.get(faction).getUnitsIn(source)) {
									if (!unitToMove.isMovedThisTurn() ) {
										unitToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, target)));
										unitToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (unitNumberCopy != 0) {
								int moved = Integer.parseInt(unitNumber) - unitNumberCopy;
								if (Integer.parseInt(unitNumber) > 1 ) {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + ", but they were only able to move " + moved + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(unitNumber) > 1 ) {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " units from " + source + " to " + target +".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " unit from " + source + " to " + target +".\n";
								}
							}
						//there were no units in the zone to move	
						}
						else {
							if (Integer.parseInt(unitNumber) > 1 ) {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " units from " + source + " to " + target + ", but they don't have any units in that territory!\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " unit from " + source + " to " + target + ", but they don't have any units in that territory!\n";
								continue;
							}
						}
						
						
						//###make sure they have a train route *or* mech infantry
					} else if (splitLine.length == 5) { //move 2 

						String midpoint1 = splitLine[4];
						
						//make sure midpoint is actually connected to both territories 
						//### need to let midpoint be equal to one of these territories, for delaying actions
						if (!(territories.get(midpoint1).getConnectedTerritoriesList().contains(source)&&territories.get(midpoint1).getConnectedTerritoriesList().contains(target))) {
							if (Integer.parseInt(unitNumber) > 1 ) { 
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " units from " + source + " to " + target + " through " + midpoint1 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						if (factions.get(faction).unitIn(source)) {
							int unitsAvailable = 0;
							for (Unit unit : factions.get(faction).getUnitsIn(source)) {
								if (!unit.isMovedThisTurn()) {
									unitsAvailable++;
								}
							}
							if (unitsAvailable == 0) { //all units in that zone have moved already
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory that haven't already moved!\n";
									continue;
								}
							}
							
							//if target territory is not allied, enemy, or ###neutral, then fail
							//###this doesn't work; it only checks to see if BOTH are allied controled or BOTH ar enemy controlled
							boolean canPass = false;
							for (String ally : factions.get(faction).getAllies()) {
								if (factions.get(ally).checkOccupiedTerritory(midpoint1) || factions.get(ally).checkOccupiedTerritory(target)) {
									canPass = true;
									break;
								}
							}
							if (!canPass) {
								for (String enemy : factions.get(faction).getEnemies()) {
									if (factions.get(enemy).checkOccupiedTerritory(midpoint1) || factions.get(enemy).checkOccupiedTerritory(target)) {
										canPass = true;
										break;
									}
								}
							}
							if (!canPass) { 
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + midpoint1 + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + midpoint1 + ", but that territory belongs to a neutral faction.\n";
									continue;
								}
							}
							
							//move the units
							int unitNumberCopy = Integer.parseInt(unitNumber);
							while ((unitNumberCopy > 0)&&(unitsAvailable > 0)) {
								unitNumberCopy--;
								unitsAvailable--;
								
								
								for (Unit unitToMove : factions.get(faction).getUnitsIn(source)) {
									if (!unitToMove.isMovedThisTurn() ) {
										unitToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, midpoint1, target)));
										unitToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (unitNumberCopy != 0) {
								int moved = Integer.parseInt(unitNumber) - unitNumberCopy;
								if (Integer.parseInt(unitNumber) > 1 ) {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " units from " + source + " to " + target + " through " + midpoint1 + ", but they were only able to move " + moved + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(unitNumber) > 1 ) {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " units from " + source + " to " + target + " through " + midpoint1 + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " unit from " + source + " to " + target + " through " + midpoint1 + ".\n";
								}
							}
						//there were no units in the zone to move	
						}
						else {
							if (Integer.parseInt(unitNumber) > 1 ) {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " units from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory!\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " unit from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any units in that territory!\n";
								continue;
							}
						}
					}

					
					else if (splitLine.length == 6) { //move 3

						String midpoint1 = splitLine[4];
						String midpoint2 = splitLine[5];
						
						//check, make sure they have Nuclear Engines
						if (!factions.get(faction).getAllResearchedTech().contains("Nuclear Engines")) {
							turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
									+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have the Nuclear Engines technology researched!\n";
							continue;
						}
						
						//may need to redo this bit; loop: check 1 connected to 2, check 2 connected 3, etc.
						
						//make sure midpoint1 is actually connected to source and midpoint2
						if (!(territories.get(midpoint1).getConnectedTerritoriesList().contains(source)&&territories.get(midpoint1).getConnectedTerritoriesList().contains(midpoint2))) {
							if (Integer.parseInt(unitNumber) > 1 ) { 
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						//make sure midpoint2 is actually connected to target and midpoint1
						if (!(territories.get(midpoint2).getConnectedTerritoriesList().contains(target)&&territories.get(midpoint2).getConnectedTerritoriesList().contains(midpoint1))) {
							if (Integer.parseInt(unitNumber) > 1 ) { 
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						if (factions.get(faction).unitIn(source)) {
							int shipsAvailable = 0;
							for (Unit unit : factions.get(faction).getUnitsIn(source)) {
								if (!unit.isMovedThisTurn()) {
									shipsAvailable++;
								}
							}
							if (shipsAvailable == 0) { //all ships in that zone have moved already
								if (Integer.parseInt(unitNumber) > 1 ) { 
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
								else {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
							}
							
							//move the ships
							int unitNumberCopy = Integer.parseInt(unitNumber);
							while ((unitNumberCopy > 0)&&(shipsAvailable > 0)) {
								unitNumberCopy--;
								shipsAvailable--;
								
								
								for (Unit unitToMove : factions.get(faction).getUnitsIn(source)) {
									if (!unitToMove.isMovedThisTurn() ) {
										unitToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, midpoint1, midpoint2, target)));
										unitToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (unitNumberCopy != 0) {
								int moved = Integer.parseInt(unitNumber) - unitNumberCopy;
								if (Integer.parseInt(unitNumber) > 1 ) {
									turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they were only able to move " + moved + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(unitNumber) > 1 ) {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ".\n";
								} else {turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] moves " + unitNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ".\n";
								}
							}
						//there were no units in the zone to move	
						}
						else {
							if (Integer.parseInt(unitNumber) > 1 ) {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
							else {
								turnReportUnitMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + unitNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
						}
						
					}

				//get number of move
				//1
				//confirm source is adjacent to end, move.  
				//
				//2
				//confirm midpoint is adjacent to both end and source, move.
				//
				//3
				//confirm nuclear engines is researched.
				//confirm midpoints are adjacent to one another.  
				//confirm mid1 is adjacent to source
				//confirm mid2 is adjacent to target
				//
				//update previous/current territory
				}
			}
		}
		
		
		return turnReportUnitMove;
	}
	

	//---------------------------------
	//  NAVY
	//---------------------------------
	
	
	public static String parseNavyCombat() {
		String turnReportNavyCombat = "";
		int movePhase = 0;
		
		while (shipCanMove(movePhase)) { 
		
			turnReportNavyCombat += "\n[b][i][u]Fleet Turn/Move Phase " + movePhase + "[/u][/i][/b]\n";
			
			HashMap<String, HashMap<String, HashMap<String, Set<Fleet>>>> allShips = new HashMap<String, HashMap<String, HashMap<String, Set<Fleet>>>>(); //curr, prev, faction
		
			//going through each ship from each faction
			//if the path doesn't exist in allShips, we add it
			for (String faction : factions.keySet()) {
				for (Fleet fleet : factions.get(faction).getFleets()) {
					
					fleet.getPrevCurr(movePhase);
					String curr = fleet.getCurrent();
					String prev = fleet.getPrevious();
					
					if (!allShips.containsKey(curr)) {
						allShips.put(curr, new HashMap<String, HashMap<String, Set<Fleet>>>());
					}
						
					if (!allShips.get(curr).containsKey(prev)) {
						allShips.get(curr).put(prev, new HashMap<String, Set<Fleet>>());
					}
					
					if (!allShips.get(curr).get(prev).containsKey(faction)) {
						allShips.get(curr).get(prev).put(faction, new HashSet<Fleet>());
					}
					
					allShips.get(curr).get(prev).get(faction).add(fleet);					
				}
			}
			
			//bypass combat
			for (String currentTerritory : orderSeaZones(allShips.keySet())) {

				for (String previousTerritory : orderSeaZones(allShips.get(currentTerritory).keySet())) {

					for (String currentFaction : orderFactions(allShips.get(currentTerritory).get(previousTerritory).keySet())) { //start parsing through factions in a territory by priority

						if (!fleetCanFight(allShips.get(currentTerritory).get(previousTerritory).get(currentFaction))) { //if this fleet has already been destroyed, skip it
							continue;
						}

						try {
							HashMap<String, Set<Fleet>> crossedFactions = allShips.get(previousTerritory).get(currentTerritory); //if there's at least 1 faction that crossed the path (even self) 
							
							//now check to see if the ships crossed are their own or allied/neutral
							for (String crossedFaction : orderFactions(crossedFactions.keySet())) {

								if (!crossedFaction.equals(currentFaction)) { //if it's not their own ships
									
									if (factions.get(crossedFaction).getDiplomacySpecific(currentFaction).equals("war")) { //if they are at war

										if (!fleetCanFight(allShips.get(previousTerritory).get(currentTerritory).get(crossedFaction))) { //if the enemy fleet has already been destroyed, skip it
											continue;
										}
										if (!fleetCanFight(allShips.get(currentTerritory).get(previousTerritory).get(currentFaction))) { //if the current fleet been destroyed in previous, skip this.
											continue;
										}

										//NOW we can do the combat.
										Set<Fleet> availableCurrentFleet = getFightingShips(allShips.get(currentTerritory).get(previousTerritory).get(currentFaction));
										Set<Fleet> availableCrossedFleet = getFightingShips(allShips.get(previousTerritory).get(currentTerritory).get(crossedFaction));

										 turnReportNavyCombat += runNavyCombat(currentFaction, availableCurrentFleet, crossedFaction, availableCrossedFleet, true);
									}
								}	
							}
						} catch (NullPointerException e) {}
					}	
				}
			}
			
			//rebuild allShips2 for regular combat (remove destroyed ships, build it without previous territory, etc)
			//--
			//remove dead ships from each faction fleet set
			for (String faction : factions.keySet()) {
				Set<Fleet> newFleet = new HashSet<Fleet>();
				for (Fleet fleet : factions.get(faction).getFleets()) {
					if (!fleet.isToBeRemoved()) {
						newFleet.add(fleet);
					}
				}
				factions.get(faction).setFleets(newFleet);
			}
			
			//allships2
			HashMap<String, HashMap<String, Set<Fleet>>> allShips2 = new HashMap<String, HashMap<String, Set<Fleet>>>(); //curr, faction
			for (String faction : factions.keySet()) {
				for (Fleet fleet : factions.get(faction).getFleets()) {
					fleet.getPrevCurr(movePhase); //###redundant, remove this line
					String curr = fleet.getCurrent();
					
					if (!allShips2.containsKey(curr)) {
						allShips2.put(curr, new HashMap<String, Set<Fleet>>());
					}
					
					if (!allShips2.get(curr).containsKey(faction)) {
						allShips2.get(curr).put(faction, new HashSet<Fleet>());
					}
					
					allShips2.get(curr).get(faction).add(fleet);					
				}
			}
			// --
			
			//regular combat
			for (String currentTerritory : orderSeaZones(allShips2.keySet())) {
				
				for (String currentFaction : orderFactions(allShips2.get(currentTerritory).keySet())) { //start parsing through factions in a territory by priority
					
					if (!fleetCanFight(allShips2.get(currentTerritory).get(currentFaction))) { //if this fleet has already been destroyed, skip it.  probably redundant, see duplicate below
						continue;
					}
					try {
						HashMap<String, Set<Fleet>> crossedFactions = allShips2.get(currentTerritory); //if there's at least 1 faction that crossed the path (even self) 
						
						//now check to see if the ships crossed are their own or allied/neutral
						for (String crossedFaction : orderFactions(crossedFactions.keySet())) {
							
							if (!crossedFaction.equals(currentFaction)) { //if it's not their own ships
								
								if (factions.get(crossedFaction).getDiplomacySpecific(currentFaction).equals("war")) { //if they are at war
									
									if (!fleetCanFight(allShips2.get(currentTerritory).get(crossedFaction))) { //if the enemy fleet has already been destroyed, skip it
										continue;
									}
									if (!fleetCanFight(allShips2.get(currentTerritory).get(currentFaction))) { //if the current fleet been destroyed in previous, skip this.
										continue;
									}
									
									//NOW we can do the combat.
									Set<Fleet> availableCurrentFleet = getFightingShips(allShips2.get(currentTerritory).get(currentFaction));
									Set<Fleet> availableCrossedFleet = getFightingShips(allShips2.get(currentTerritory).get(crossedFaction));
									
									turnReportNavyCombat += runNavyCombat(currentFaction, availableCurrentFleet, crossedFaction, availableCrossedFleet, false);
								}
							}	
						}
					} catch (NullPointerException e) {}
				}	
				
			}
			
			//now, remove the destroyed fleets from the factions fleet set
			for (String faction : factions.keySet()) {
				Set<Fleet> newFleet = new HashSet<Fleet>();
				for (Fleet fleet : factions.get(faction).getFleets()) {
					if (!fleet.isToBeRemoved()) {
						newFleet.add(fleet);
					}
				}
				factions.get(faction).setFleets(newFleet);
			}

			//progress movePhase			
			movePhase++;
		}
		
		System.out.println(turnReportNavyCombat);

		return turnReportNavyCombat = "";
		
	}
	
	public static boolean shipCanMove(int movePhase) {
		for (Faction faction : factions.values()) {
			for (Fleet fleet : faction.getFleets()) {
				if (movePhase < fleet.getMoveList().size()) {
					return true;
				}
			}
		}
		return false;		
	}
	
	public static boolean fleetCanFight(Set<Fleet> mixedFleet) {
		for (Fleet fleet : mixedFleet) {
			if (!fleet.isToBeRemoved()) {
				return true;
			}
		}
		return false;
	}
	
	
	public static Set<Fleet> getFightingShips(Set<Fleet> mixedFleet) {
		Set<Fleet> fightingFleet = new HashSet<Fleet>();
		
		for (Fleet fleet : mixedFleet) {
			if (!fleet.isToBeRemoved()) {
				fightingFleet.add(fleet);
			}
		}
		
		return fightingFleet;
	}
	
	public static List<String> orderSeaZones(Set<String> unsortedsz) {
		List<String> sortedsz = new ArrayList<String>();
		sortedsz.addAll(unsortedsz); 

		Collections.sort(sortedsz, new SortBySeaZone());
			
		return sortedsz;
	}
	
	public static List<String> orderFactions(Set<String> unsortedFactions) {
		List<String> sortedFactions = new ArrayList<String>();
		sortedFactions.addAll(unsortedFactions); 

		Collections.sort(sortedFactions, new SortByPriority(factions));
			
		return sortedFactions;
	}
	
	public static String runNavyCombat(String faction1, Set<Fleet> moveGroup1, String faction2, Set<Fleet> moveGroup2, boolean bypass) {
		String combatReport = "";
		Fleet ftemp1 = null;
		
		for (Fleet ftemp : moveGroup1) { ftemp1 = ftemp; break; }
		String territory1 = ftemp1.getCurrent();
		String territory2 = ftemp1.getPrevious();
		if (bypass && !(ftemp1.getCurrent().equals(ftemp1.getPrevious()))) {
			combatReport += "[b]" + facSwap(faction1) + "[/b] and [b]" + facSwap(faction2) + "[/b] encounter one another as they cross the border of " 
					+ territory1 + " and " + territory2 + ".\n[spoiler=Combat: " + facSwap(faction1) + " and " + facSwap(faction2) + " between "+ territory1 + " and " + territory2 + "]\n";
		}
		else {
			String territory = "";
			for (Fleet fleet : moveGroup1) {  //### maybe switch this to some collection method that lets you query a specific element?
				territory = fleet.getCurrent();
				break;
			}
			combatReport += "[b]" + facSwap(faction1) + "[/b] and [b]" + facSwap(faction2) + "[/b] encounter one another in " 
					+ territory + ".\n[spoiler=Combat: " + facSwap(faction1) + " and " + facSwap(faction2) + " in "+ territory + "]\n";
		}
			
			
		int bonus1 = 0;
		int bonus2 = 0;
		//tech check 
		//### maybe one day switch this so that the tech's know what advantage they provide, and a method in the faction that returns the total technological advantage for the requested situation rather than having it hard-coded like this
		//Rocketry
		if (factions.get(faction1).getAllResearchedTech().contains("Rocketry")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Rocketry")) {
			bonus2++;
		}
		//Advanced Rocketry
		if (factions.get(faction1).getAllResearchedTech().contains("Advanced Rocketry")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Advanced Rocketry")) {
			bonus2++;
		}
		//Aircraft Carriers
		if (factions.get(faction1).getAllResearchedTech().contains("Aircraft Carriers")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Aircraft Carriers")) {
			bonus2++;
		}
		//Mixed Fleets
		if (factions.get(faction1).getAllResearchedTech().contains("Mixed Fleets")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Mixed Fleets")) {
			bonus2++;
		}
		//Missile Cruisers
		if (factions.get(faction1).getAllResearchedTech().contains("Missile Cruisers")) {
			bonus1++;
		}
		if (factions.get(faction2).getAllResearchedTech().contains("Missile Cruisers")) {
			bonus2++;
		}
		//Airfield Bonus
		Faction tempFaction = factions.get(faction1);
		tempFaction = factions.get(faction2);
		if (bypass) {
			int range1 = 1;
			if (factions.get(faction1).getAllResearchedTech().contains("Long Range Aircraft")) {
				range1++;
			}
			if (factions.get(faction1).getAllResearchedTech().contains("Jet Planes")) {
				range1++;
			}
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(range1)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= range1) {     //make sure it's within range of the other territory
						if (factions.get(faction1).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus1++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction1).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus1++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
			
			int range2 = 1;
			if (factions.get(faction2).getAllResearchedTech().contains("Long Range Aircraft")) {
				range2++;
			}
			if (factions.get(faction2).getAllResearchedTech().contains("Jet Planes")) {
				range2++;
			}
			found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(range2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= range2) {     //make sure it's within range of the other territory
						if (factions.get(faction2).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus2++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction2).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus2++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
		} 
		if (!bypass) {
			int range1 = 1;
			if (factions.get(faction1).getAllResearchedTech().contains("Long Range Aircraft")) {
				range1++;
			}
			if (factions.get(faction1).getAllResearchedTech().contains("Jet Planes")) {
				range1++;
			}
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(range1)) { //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                   //make sure they have an airfield
					if (factions.get(faction1).checkOccupiedTerritory(territory)) {               //make sure player owns the territory
						bonus1++;                                                                       //if all this is true, give them the airfield bonus
						break;
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction1).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus1++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}
			
			int range2 = 1;
			if (factions.get(faction2).getAllResearchedTech().contains("Long Range Aircraft")) {
				range2++;
			}
			if (factions.get(faction2).getAllResearchedTech().contains("Jet Planes")) {
				range2++;
			}
			for (String territory : territories.get(territory2).getAllWithinDistance(range2)) { //get all territories within range
				if (territories.get(territory).hasImprovement("Airfield")) {                   //make sure they have an airfield
					if (factions.get(faction2).checkOccupiedTerritory(territory)) {               //make sure player owns the territory
						bonus2++;                                                                       //if all this is true, give them the airfield bonus
						break;
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction2).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus2++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}
		}
		
		//Silo Bonus
		if (bypass) {
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= 2) {     //make sure it's within range of the other territory
						if (factions.get(faction1).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus1++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction1).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus1++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
			
			
			found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (territories.get(territory).getDistanceToTarget(territory2) <= 2) {     //make sure it's within range of the other territory
						if (factions.get(faction2).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
							bonus2++;                                                             //if all this is true, give them the airfield bonus
							found = true;
							break;
							
						}
						else { //if player does NOT own the territory, does an ally? 
							for (String alliedFaction : factions.get(faction2).getAllies()) { 
								if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
									bonus2++;
									found = true;
									break;
								}
							}
							if (found) { break; }
						}
					}
				}
			}
		} 
		if (!bypass) {
			boolean found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (factions.get(faction1).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
						bonus1++;                                                             //if all this is true, give them the airfield bonus
						found = true;
						break;
						
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction1).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus1++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}			
			
			found = false;
			for (String territory : territories.get(territory1).getAllWithinDistance(2)) {     //get all territories within range
				if (territories.get(territory).hasImprovement("Silo")) {                       //make sure they have an silo
					if (factions.get(faction2).checkOccupiedTerritory(territory)) {           //make sure player owns the territory
						bonus2++;                                                             //if all this is true, give them the airfield bonus
						found = true;
						break;
						
					}
					else { //if player does NOT own the territory, does an ally? 
						for (String alliedFaction : factions.get(faction2).getAllies()) { 
							if (factions.get(alliedFaction).checkOccupiedTerritory(territory)) {
								bonus2++;
								found = true;
								break;
							}
						}
						if (found) { break; }
					}
				}
			}
		}
		
		//combat loop
		int round = 0;
		while ((moveGroup1.size() > 0)&&(moveGroup2.size() > 0)) {
			round++;
			int roundbonus1 = bonus1;
			int roundbonus2 = bonus2;
			

			if (moveGroup1.size() > moveGroup2.size()) {
				roundbonus1 += (int) Math.floor((moveGroup1.size() - moveGroup2.size())/2);
			}
			if (moveGroup1.size() < moveGroup2.size()) {
				roundbonus2 += (int) Math.floor((moveGroup2.size() - moveGroup1.size())/2);
			}
			
			
			//now for the actual combat! 
			int roll1 = factions.get(faction1).pullCard();
			int roll2 = factions.get(faction2).pullCard();
			int sum1 = roll1 + roundbonus1;
			int sum2 = roll2 + roundbonus2;
			
			combatReport += "[b][u]Round " + round + ":[/u][/b]\n";
			
			//if both roll a 1
			if ((roll1 == 1)&&(roll2 == 1)) {


				if (moveGroup1.size() > 1) {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleets) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleet) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				}
				if (moveGroup2.size() > 1) {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleets) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleet) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				}
				combatReport += "Both sides have rolled a 1.  Both sides lose a fleet!\n\n";
				
				for (Fleet fleet : moveGroup1) {  
					fleet.setToBeRemoved(true);
					moveGroup1.remove(fleet);
					break;
				}
				for (Fleet fleet : moveGroup2) { 
					fleet.setToBeRemoved(true);
					moveGroup2.remove(fleet);
					break;
				}
			}
			//if one rolls a 1
			else if ((roll1 == 1)&&(roll2 != 1)) {
				if (moveGroup1.size() > 1) {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleets) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleet) rolls (1d6 = [b]" + roll1 + "[/b]) + " + roundbonus1 + " = " + sum1 + "\n";
				}
				if (moveGroup2.size() > 1) {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleets) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = " + sum2 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleet) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = " + sum2 + "\n";
				}
				combatReport += "[b]" + facSwap(faction1) + "[/b] has rolled a 1 - [b]" + facSwap(faction2) + "[/b] wins!\n\n";
				
				for (Fleet fleet : moveGroup1) {  
					fleet.setToBeRemoved(true);
					moveGroup1.remove(fleet);
					break;
				}
			}
			//if the other rolls a 1
			else if ((roll1 != 1)&&(roll2 == 1)) {
				if (moveGroup1.size() > 1) {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleets) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = " + sum1 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleet) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = " + sum1 + "\n";
				}
				if (moveGroup2.size() > 1) {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleets) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				} else {
					combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleet) rolls (1d6 = [b]" + roll2 + "[/b]) + " + roundbonus2 + " = " + sum2 + "\n";
				}
				combatReport += "[b]" + facSwap(faction2) + "[/b] has rolled a 1 - [b]" + facSwap(faction1) + "[/b] wins!\n\n";
				
				for (Fleet fleet : moveGroup2) { 
					fleet.setToBeRemoved(true);
					moveGroup2.remove(fleet);
					break;
				}
			}
			//if it's a tie (with bonuses)
			else {
				if ((sum1 == sum2)) { //### should both sides lose a fleet in a tie?  Or should it just bounce and they try again?
					if (moveGroup1.size() > 1) {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleets) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleet) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					}
					if (moveGroup2.size() > 1) {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleets) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleet) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					}
					combatReport += "[b]" + facSwap(faction1) + "[/b] and [b]" + facSwap(faction2) + "[/b] are tied - both sides lose a fleet!\n\n";

					for (Fleet fleet : moveGroup1) {  
						fleet.setToBeRemoved(true);
						moveGroup1.remove(fleet);
						break;
					}
					
					for (Fleet fleet : moveGroup2) { 
						fleet.setToBeRemoved(true);
						moveGroup2.remove(fleet);
						break;
					}
				}

				//if one side has the higher roll (with bonuses)
				else if ((sum1 > sum2)) {
					if (moveGroup1.size() > 1) {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleets) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleet) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					}
					if (moveGroup2.size() > 1) {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleets) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleet) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					}
					combatReport += "[b]" + facSwap(faction1) + "[/b] wins!\n\n";
					
					for (Fleet fleet : moveGroup2) { 
						fleet.setToBeRemoved(true);
						moveGroup2.remove(fleet);
						break;
					}
				}

				//if the other side has the higher roll (with bonuses)
				else if ((sum1 < sum2)) {
					if (moveGroup1.size() > 1) {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleets) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction1) + "[/b] (" + moveGroup1.size() + " fleet) rolls (1d6 = " + roll1 + ") + " + roundbonus1 + " = [b]" + sum1 + "[/b]\n";
					}
					if (moveGroup2.size() > 1) {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleets) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					} else {
						combatReport += "[b]" + facSwap(faction2) + "[/b] (" + moveGroup2.size() + " fleet) rolls (1d6 = " + roll2 + ") + " + roundbonus2 + " = [b]" + sum2 + "[/b]\n";
					}
					combatReport += "[b]" + facSwap(faction2) + "[/b] wins!\n\n";
					
					for (Fleet fleet : moveGroup1) { 
						fleet.setToBeRemoved(true);
						moveGroup1.remove(fleet);
						break;
					}
				}
			}
		}//end combat loop
		
		//find out if one side won or if it was a tie
		if ((moveGroup1.size() == 0)&&(moveGroup2.size() == 0)) {
			combatReport += "Both sides have been destroyed!";
		}
		else if (moveGroup1.size() > 0) {
			if (moveGroup1.size() == 1) {
				combatReport += "[b]" + facSwap(faction1) + "[/b] wins with " + moveGroup1.size() + " fleet remaining.";
			}
			else {
				combatReport += "[b]" + facSwap(faction1) + "[/b] wins with " + moveGroup1.size() + " fleets remaining.";
			}
		}
		else {
			if (moveGroup2.size() == 1) {
				combatReport += "[b]" + facSwap(faction2) + "[/b] wins with " + moveGroup2.size() + " fleet remaining.";
			}
			else {
				combatReport += "[b]" + facSwap(faction2) + "[/b] wins with " + moveGroup2.size() + " fleets remaining.";
			}
		}
		
		combatReport += "\n[/spoiler]\n\n";
		
		return combatReport;		
	}
	
	
	public static void resetNavyMove() {
		for (String facName : factions.keySet()) {//HashMap<String, List<Fleet>> fleets 
			for (Fleet fleet : factions.get(facName).getFleets()) {
				List<String> temp = new ArrayList<String>();
				temp.add(fleet.getMoveList().get(fleet.getMoveList().size()-1));
				fleet.setMoveList(temp);
			} 
		}
	}

	public static String parseNavyMove() {

		// "moveFleet - numberUnits - source(sz#) - end(sz#) - midpoint(optional)(sz#) - midpoint(optional)(sz#)"
		
		String turnReportNavyMove = "";
		
		//iterate through all factions
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders

			for (String orderLine : parsedOrders.get(factionName)) {
			
				if (orderLine.split(" ")[0].equals("moveFleet")) {

					//nukebomb startzone endzone
					String[] splitLine = orderLine.split(" ");
					String faction = factionName;
					String fleetNumber = splitLine[1];
					String source = splitLine[2];
					String target = splitLine[3];
										
					if (splitLine.length == 4) { //move 1 
						//there's a fleet in source
						//at least 1 fleet that hasn't moved
						//move each fleet 1 by 1 until the fleetnumber has been met, updating previous and current territories
						if (factions.get(faction).fleetIn(source)) {
							int shipsAvailable = 0;
							for (Fleet fleet : factions.get(faction).getFleetsIn(source)) {
								if (!fleet.isMovedThisTurn()) {
									shipsAvailable++;
								}
							}
							if (shipsAvailable == 0) { //all ships in that zone have moved already
								if (Integer.parseInt(fleetNumber) > 1 ) { 
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ships from " + source + " to " + target + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
								else {
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ship from " + source + " to " + target + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
							}
							
							//if shipsavailable > 0 and fleetnumbercopy > 0
							//move 1 ship, decriment shipsavailable and fleetnumbercopy
							//when either hit 0
							//if fleetnumbercopy != 0, announce that there were only (fleetnumber-fleetnumbercopy) ships available to move
							//else, announce fleetnumber of ships moved
							int fleetNumberCopy = Integer.parseInt(fleetNumber);
							while ((fleetNumberCopy > 0)&&(shipsAvailable > 0)) {
								fleetNumberCopy--;
								shipsAvailable--;
								
								
								for (Fleet fleetToMove : factions.get(faction).getFleetsIn(source)) {
									if (!fleetToMove.isMovedThisTurn() ) {
										fleetToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, target)));
										fleetToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (fleetNumberCopy != 0) {
								int moved = Integer.parseInt(fleetNumber) - fleetNumberCopy;
								if (Integer.parseInt(fleetNumber) > 1 ) {
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ships from " + source + " to " + target + ", but they were only able to move " + moved + ".\n";
								} else {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ship from " + source + " to " + target + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(fleetNumber) > 1 ) {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] moves " + fleetNumber 
											+ " ships from " + source + " to " + target +".\n";
								} else {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] moves " + fleetNumber 
											+ " ship from " + source + " to " + target +".\n";
								}
							}
						//there were no fleets in the zone to move	
						}
						else {
							if (Integer.parseInt(fleetNumber) > 1 ) {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ships from " + source + " to " + target + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
							else {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ship from " + source + " to " + target + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
						}
						
						
					} else if (splitLine.length == 5) { //move 2 

						String midpoint1 = splitLine[4];
						
						//make sure midpoint is actually connected to both territories 
						//### need to let midpoint be equal to one of these territories, for delaying actions
						if (!(territories.get(midpoint1).getConnectedTerritoriesList().contains(source)&&territories.get(midpoint1).getConnectedTerritoriesList().contains(target))) {
							if (Integer.parseInt(fleetNumber) > 1 ) { 
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						if (factions.get(faction).fleetIn(source)) {
							int shipsAvailable = 0;
							for (Fleet fleet : factions.get(faction).getFleetsIn(source)) {
								if (!fleet.isMovedThisTurn()) {
									shipsAvailable++;
								}
							}
							if (shipsAvailable == 0) { //all ships in that zone have moved already
								if (Integer.parseInt(fleetNumber) > 1 ) { 
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
								else {
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
							}
							
							//move the ships
							int fleetNumberCopy = Integer.parseInt(fleetNumber);
							while ((fleetNumberCopy > 0)&&(shipsAvailable > 0)) {
								fleetNumberCopy--;
								shipsAvailable--;
								
								
								for (Fleet fleetToMove : factions.get(faction).getFleetsIn(source)) {
									if (!fleetToMove.isMovedThisTurn() ) {
										fleetToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, midpoint1, target)));
										fleetToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (fleetNumberCopy != 0) {
								int moved = Integer.parseInt(fleetNumber) - fleetNumberCopy;
								if (Integer.parseInt(fleetNumber) > 1 ) {
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + ", but they were only able to move " + moved + ".\n";
								} else {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(fleetNumber) > 1 ) {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] moves " + fleetNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + ".\n";
								} else {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] moves " + fleetNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + ".\n";
								}
							}
						//there were no fleets in the zone to move	
						}
						else {
							if (Integer.parseInt(fleetNumber) > 1 ) {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
							else {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
						}
					}

					else if (splitLine.length == 6) { //move 3

						String midpoint1 = splitLine[4];
						String midpoint2 = splitLine[5];
						
						//check, make sure they have Nuclear Engines
						if (!factions.get(faction).getAllResearchedTech().contains("Nuclear Engines")) {
							turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
									+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have the Nuclear Engines technology researched!\n";
							continue;
						}
						
						//may need to redo this bit; loop: check 1 connected to 2, check 2 connected 3, etc.
						
						//make sure midpoint1 is actually connected to source and midpoint2
						if (!(territories.get(midpoint1).getConnectedTerritoriesList().contains(source)&&territories.get(midpoint1).getConnectedTerritoriesList().contains(midpoint2))) {
							if (Integer.parseInt(fleetNumber) > 1 ) { 
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						//make sure midpoint2 is actually connected to target and midpoint1
						if (!(territories.get(midpoint2).getConnectedTerritoriesList().contains(target)&&territories.get(midpoint2).getConnectedTerritoriesList().contains(midpoint1))) {
							if (Integer.parseInt(fleetNumber) > 1 ) { 
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
							else {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but that path is invalid.\n";
								continue;
							}
						}
						
						if (factions.get(faction).fleetIn(source)) {
							int shipsAvailable = 0;
							for (Fleet fleet : factions.get(faction).getFleetsIn(source)) {
								if (!fleet.isMovedThisTurn()) {
									shipsAvailable++;
								}
							}
							if (shipsAvailable == 0) { //all ships in that zone have moved already
								if (Integer.parseInt(fleetNumber) > 1 ) { 
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
								else {
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone that haven't already moved!\n";
									continue;
								}
							}
							
							//move the ships
							int fleetNumberCopy = Integer.parseInt(fleetNumber);
							while ((fleetNumberCopy > 0)&&(shipsAvailable > 0)) {
								fleetNumberCopy--;
								shipsAvailable--;
								
								
								for (Fleet fleetToMove : factions.get(faction).getFleetsIn(source)) {
									if (!fleetToMove.isMovedThisTurn() ) {
										fleetToMove.setMoveList(new ArrayList<String>(Arrays.asList(source, midpoint1, midpoint2, target)));
										fleetToMove.setMovedThisTurn(true);
										break;
									}
								}
							}
							
							//anouncement - checking to see if a partial move was available
							if (fleetNumberCopy != 0) {
								int moved = Integer.parseInt(fleetNumber) - fleetNumberCopy;
								if (Integer.parseInt(fleetNumber) > 1 ) {
									turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they were only able to move " + moved + ".\n";
								} else {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they were only able to move " + moved + ".\n";
								}
							} else {
								if (Integer.parseInt(fleetNumber) > 1 ) {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] moves " + fleetNumber 
											+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ".\n";
								} else {turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] moves " + fleetNumber 
											+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ".\n";
								}
							}
						//there were no fleets in the zone to move	
						}
						else {
							if (Integer.parseInt(fleetNumber) > 1 ) {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ships from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
							else {
								turnReportNavyMove += "[b]" + facSwap(faction) + "[/b] attempts to move " + fleetNumber 
										+ " ship from " + source + " to " + target + " through " + midpoint1 + " and " + midpoint2 + ", but they don't have any ships in that sea zone!\n";
								continue;
							}
						}
						
					}

				//get number of move
				//1
				//confirm source is adjacent to end, move.  
				//
				//2
				//confirm midpoint is adjacent to both end and source, move.
				//
				//3
				//confirm nuclear engines is researched.
				//confirm midpoints are adjacent to one another.  
				//confirm mid1 is adjacent to source
				//confirm mid2 is adjacent to target
				//
				//update previous/current territory
				}
			}
		}
		
		
		return turnReportNavyMove;
	}
	

	public static String processFalloutDamage() {
		//get list of all irradiated territories
		//flip through all factions, check if they have a unit in one of those territories
		//if yes, remove 1 unit

		String turnReportFalloutDamage = "";
		List<String> irradiatedTerritories = new ArrayList<String>();
		for (String territoryID : territories.keySet()) {
			if (territories.get(territoryID).getFallout() > 0) {
				irradiatedTerritories.add(territoryID);
			}
		}
		
		if (irradiatedTerritories.size()>0) {
			for (String faction : orderFactions(factions.keySet())) {
				for (String territory : irradiatedTerritories) {
					for (Unit unit : factions.get(faction).getUnitsIn(territory)) {
						unit.setToBeRemoved(true);
						turnReportFalloutDamage += "[b]" + facSwap(faction) + "[/b] loses a unit in " + territory + " due to fallout.\n";
						break;
					}
				}
			}
		}
			
//			for (String territory : irradiatedTerritories) {
//				for (String factionName : orderFactions(factions.keySet())) {
//					if (factions.get(factionName).getUnits().containsKey(territory)) {
//						factions.get(factionName).removeUnit(territory);
//						turnReportFalloutDamage += "[b]" + facSwap(factionName) + "[/b] loses a unit in " + territory + " due to fallout.\n";
//					}
//				}
//			}
		
		//---
		//remove dead units from each faction unit set
		for (String faction : factions.keySet()) {
			Set<Unit> newUnit = new HashSet<Unit>();
			for (Unit unit : factions.get(faction).getUnits()) {
				if (!unit.isToBeRemoved()) {
					newUnit.add(unit);
				}
			}
			factions.get(faction).setUnits(newUnit);
		}
		//---
		
		return turnReportFalloutDamage;
	}

	public static String parseNukeMissile() {
		//nuclear bomb launched from silo
		//requires the "Nuclear Missiles" technology and a silo
		//silos that have already launched airstrikes cannot launch nuke strikes
		//max number of nukes per turn equals a nations PI/3
		//successful nukes destroy 2 random improvements and deposit 1-6 fallout.
		
		String turnReportNukeMissile = "";
		
		//since an airbase can be destroyed, first we verify orders and store the correct ones in destroyedImprovements.  Then we run it at the end and possibly bomb airfields.
		HashMap<String, List<String>> destroyedImprovements = new HashMap<String, List<String>>();
		
		//iterate through all factions
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders

			for (String orderLine : parsedOrders.get(factionName)) {
			
				if (orderLine.split(" ")[0].equals("nukemissile")) {

					//nukebomb startzone endzone
					String[] splitLine = orderLine.split(" ");
					String faction = factionName;
					String source = splitLine[1];
					String target = splitLine[2];
					
					//get the owner of the territory
					String targetFaction = "";
					for (String key : factions.keySet()) {
						if (factions.get(key).checkOccupiedTerritory(target)) {
							targetFaction = key;
						}
					}
					

					//get max range for players missiles (it's always 4, for now)
					int maxRange = 4;
					
					//get distance to target
					int targetDistance = territories.get(source).getDistanceToTarget(target);
										
					//make sure they have the technology needed
					if (!factions.get(factionName).getAllResearchedTech().contains("Nuclear Missiles")) {
						turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
								+ target + " from " + source +", but they don't have the Nuclear Missiles technology researched yet.\n";
						continue;
					}
					
					//make sure they haven't exceeded their PI Nuke Missile limit (equal to their PI)
					if (factions.get(factionName).getPi() <= factions.get(factionName).getNukeMissileThisTurn()) {
						if (factions.get(factionName).getNukeMissileThisTurn() > 0 ) {
							turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
									+ target + " from " + source +", but the don't have any more nuclear missiles left.\n";
							continue;
						}
						else {
							turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
									+ target + " from " + source +", but they don't have any nuclear missiles built this turn - their PI is too low!\n";
							continue;
						}
						
					}
					
					//make sure the source is valid (has silo)
					if (territories.get(source).isMissileSilo()) { //if there's a silo
						if (!territories.get(source).isLaunchedNukeMissile()) { //haven't launched an airstrike yet
							territories.get(source).setLaunchedNukeMissile(true);
						}
						else {
							turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
									+ target + " from " + source +", but that missile silo has already launched a strike this turn.\n";
							continue;
						}
					}
					else {
						turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
								+ target + " from " + source +", but they don't have a silo in that territory to launch the strike.\n";
						continue;
					}
					//incriment the number of nuclear airstrikes theyve done this turn.
					factions.get(factionName).incNukeMissileThisTurn(); 
					
					//check diplomacy
					if (!factions.get(factionName).getDiplomacySpecific(targetFaction).equals("war")) {
						turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
								+ target + " from " + source +", but the strike was aborted since they're not actually at war with [b]" 
								+ facSwap(targetFaction) + "[/b].\n";
						continue;
					}
					
					//check target is within range
					if (targetDistance > maxRange) {
						turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
								+ target + " from " + source +", but the target is out of range.\n";
						continue;
					}

					//check to make sure they aren't bombing a sea zone
					if (territories.get(target).isOcean()) {
						turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
								+ target + " from " + source +", but the strike was aborted.  Sea zones are not valid targets!\n";
						continue;
					}
					
					//check to make sure they aren't bombing themselves
					if (factionName.equals(targetFaction)) {
						turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear missile strike on " 
								+ target + " from " + source +", but the strike was aborted - that's their own territory!\n";
						continue;
					}
					
					
					//check interception
					//things that intercept: AA(33), and only with Advanced Rocketry
					
					//check for AA
					//if aa, check adv rocketry and roll for success
					//if fail, add the strike to the destroyedImprovements hashmap
					turnReportNukeMissile += "[b]" + facSwap(factionName) + "[/b] launches a nuclear missile strike on "
					+ target + " from " + source +"!";
					if (territories.get(target).isAa()&&factions.get(targetFaction).getAllResearchedTech().contains("Advanced Rocketry")) {
						int threshold = 2;
						
						int defensiveAARoll = factions.get(targetFaction).pullCard();
						
						turnReportNukeMissile += " [b]" + facSwap(targetFaction) 
								+ "[/b]'s AA Battery fires ("+threshold+" or lower needed: 1d6="+defensiveAARoll+")";
						
						if (defensiveAARoll <= threshold) {//successful! AA hits!
							turnReportNukeMissile += " and manages to repel the missile strike!\n";
							continue;
						}
						else {
							turnReportNukeMissile += " but the missile got through.";
						}
					}
					
					//announce the strike and add to destroyedImprovements
					//check populous - set false and announce
					//randomly get 2 improvements to destroy - make sure they haven't already been destroyed by another nuke strike!!
					//kill half the units in the territory rounding down
					turnReportNukeMissile += " The missile hits,";
					List<String> availableImprovements = territories.get(target).getAllImprovements();
					
					if (availableImprovements.size() > 0) { //so long as there's something to destroy...
						if (destroyedImprovements.containsKey(target)) { //check to see if it's already been hit
							for (String improv : destroyedImprovements.get(target)) { //if it has, remove things that have already been destroyed.
								availableImprovements.remove(availableImprovements.indexOf(improv));
							}
						}
						if (availableImprovements.size() > 0) { //checking again to make sure there's still something to destroy
							int toDestroyIndex = (int) (Math.random() * availableImprovements.size());
							String toDestroy = availableImprovements.get(toDestroyIndex);		
							
							if (destroyedImprovements.containsKey(target)) {
								destroyedImprovements.get(target).add(toDestroy);
							}
							else {
								List<String> destImprovList = new ArrayList<String>();
								destImprovList.add(toDestroy);
								destroyedImprovements.put(target, destImprovList);
							}
							
							availableImprovements.remove(toDestroyIndex);		
							turnReportNukeMissile += " destroying the " + toDestroy;
						}
						else {	turnReportNukeMissile += " but there are no improvements left to destroy";	}
						
						if (availableImprovements.size() > 0) { //second destroyed improvement
							int toDestroyIndex = (int) (Math.random() * availableImprovements.size());
							String toDestroy = availableImprovements.get(toDestroyIndex);		
							
							if (destroyedImprovements.containsKey(target)) {
								destroyedImprovements.get(target).add(toDestroy);
							}
							else {
								List<String> destImprovList = new ArrayList<String>();
								destImprovList.add(toDestroy);
								destroyedImprovements.put(target, destImprovList);
							}
							
							availableImprovements.remove(toDestroyIndex);			
							turnReportNukeMissile += " and the " + toDestroy;
						}
						turnReportNukeMissile += ".";
					}
					else {
						turnReportNukeMissile += " but there are no improvements to destroy.";
					}
					
					//populous check
					if (territories.get(target).isPopulous()) {
						turnReportNukeMissile += " " + target + " is no longer Populous as civilians flee the irradiated landscape!";
						territories.get(target).setPopulous(false);
					}
					
					//add the random amount of fallout
					int falloutAmount = factions.get(faction).pullCard();
					territories.get(target).addFallout(falloutAmount);
					if (falloutAmount > 1) {
						turnReportNukeMissile += " " + falloutAmount + " units of fallout settle on the territory.";
					}
					else {
						turnReportNukeMissile += " " + falloutAmount + " unit of fallout settles on the territory.";
					}
					
					//checking to see if any troops to destroy.
					//iterate through all factions
					for (String factionTemp : factions.keySet() ) {
						Set<Unit> endangeredUnits = factions.get(factionTemp).getUnitsIn(target); //do they have units in the territory?
						if (endangeredUnits != null) {
							int numToDestroy = (int) Math.floor(((double)endangeredUnits.size())/2);
							int i = 0;
							for (Unit unitToKill : endangeredUnits) {
								if (i < numToDestroy) {
									unitToKill.setToBeRemoved(true);
									i++;
								}
								else {
									break;
									}
							}
							if (numToDestroy > 1) {
								turnReportNukeMissile += " [b]" + facSwap(factionTemp) + "[/b] loses " + numToDestroy + " units.";
							}
							else {
								turnReportNukeMissile += " [b]" + facSwap(factionTemp) + "[/b] loses " + numToDestroy + " unit.";								
							}
						}
						//remove dead units from the factions army set
						Set<Unit> newArmy = new HashSet<Unit>();
						for (Unit unit : factions.get(faction).getUnits()) {
							if (!unit.isToBeRemoved()) {
								newArmy.add(unit);
							}
						}
						factions.get(faction).setUnits(newArmy);
					}
					
					turnReportNukeMissile += "\n";
					//end of this airstrike check.
					
				}//end of check
			}//end order loop
		}//end faction loop

		//run destroyedImprovements
		for (String key : destroyedImprovements.keySet()) {
			for (String improvement : destroyedImprovements.get(key)) {
				territories.get(key).removeImprovement(improvement);
			}
		}
		
		return turnReportNukeMissile;
	}//end method
	
	
	
	public static String parseNukeAirstrike() {
		//nuclear bomb dropped from plane
		//requires the "Nuclear Power" technology and an airfield
		//airfields that have already launched airstrikes cannot launch nuke strikes
		//max number of nukes per turn equals a nations PI/2
		//successful nukes destroy 2 random improvements and deposit 6 fallout.
		
		String turnReportNukeAirstrike = "";
		
		//since an airbase can be destroyed, first we verify orders and store the correct ones in destroyedImprovements.  Then we run it at the end and possibly bomb airfields.
		HashMap<String, List<String>> destroyedImprovements = new HashMap<String, List<String>>();
		
		//iterate through all factions
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders
			for (String orderLine : parsedOrders.get(factionName)) {
			
				if (orderLine.split(" ")[0].equals("nukebomb")) {

					//nukebomb startzone endzone
					String[] splitLine = orderLine.split(" ");
					String faction = factionName;
					String source = splitLine[1];
					String target = splitLine[2];
					
					//get the owner of the territory
					String targetFaction = "";
					for (String key : factions.keySet()) {
						if (factions.get(key).checkOccupiedTerritory(target)) {
							targetFaction = key;
						}
					}

					//get max range for players bombers
					int maxRange = 1;
					if (factions.get(factionName).getAllResearchedTech().contains("Long-Range Airplanes")) {	maxRange++;	}
					if (factions.get(factionName).getAllResearchedTech().contains("Jet Planes")) {	maxRange++;	}
					
					//get distance to target
					int targetDistance = territories.get(source).getDistanceToTarget(target);
										
					//make sure they have the technology needed
					if (!factions.get(factionName).getAllResearchedTech().contains("Nuclear Power")) {
						turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
								+ target + " from " + source +", but they don't have the Nuclear Power technology researched yet.\n";
						continue;
					}
					
					//make sure they haven't exceeded their PI Nuke bomb limit (PI/2 rounding down)
					if (factions.get(factionName).getNukeAirLimit() <= factions.get(factionName).getNukeAirThisTurn()) {
						if (factions.get(factionName).getNukeAirThisTurn() > 0 ) {
							turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
									+ target + " from " + source +", but the don't have any more nuclear bombs left.\n";
							continue;
						}
						else {
							turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
									+ target + " from " + source +", but they don't have any nuclear bombs built this turn - their PI is too low!\n";
							continue;
						}
					}
					
					//make sure the source is valid (has airfield or fleet with carriers)
					//if it's a sea zone source....
					if (source.substring(0, 1).equals("s")) {
						//check to see if they have carriers researched...
						if (!factions.get(faction).getAllResearchedTech().contains("Aircraft Carriers")) {
							turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
									 + target + " from " + source +", but they don't have the Aircraft Carriers technology researched yet.\n";
							continue;
						}
						//check to see if they have fleets available
						if (factions.get(faction).fleetIn(source)) {
							boolean hasAvailableFleet = false;
							for (Fleet fleet : factions.get(faction).getFleetsIn(source)) {
								if (fleet.isAirstrike() == false) { //this fleet hasn't airstriked yet
									hasAvailableFleet = true;
									fleet.setAirstrike(true);
									break;
								}
							}
							//didnt have a fleet that hasnt airstrike yet
							if (hasAvailableFleet == false) {
								turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
										+ target + " from " + source +", but all carriers in that zone have already launched strikes.\n";
								continue;
							}
						}
						//didn't have a fleet in that zone to begin with
						else {
							turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
									+ target + " from " + source +", but they don't have a fleet in that zone to carry it out.\n";
							continue;
						}
					}
					//if it's a land source...
					else {
						if (territories.get(source).isAirfield()) { //if there's an airfield
							if (!territories.get(source).isLaunchedAirstrike()) { //haven't launched an airstrike yet
								territories.get(source).setLaunchedAirstrike(true);
							}
							else {
								turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
										+ target + " from " + source +", but that airfield has already launched a strike this turn.\n";
								continue;
							}
						}
						else {
							turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
									+ target + " from " + source +", but they don't have an airfield in that territory to launch the strike.\n";
							continue;
						}
					}
					//incriment the number of nuclear airstrikes theyve done this turn.
					factions.get(factionName).incNukeAirThisTurn(); 
					
					//check diplomacy
					if (!factions.get(factionName).getDiplomacySpecific(targetFaction).equals("war")) {
						turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
								+ target + " from " + source +", but the strike was aborted since they're not actually at war with [b]" 
								+ facSwap(targetFaction) + "[/b].\n";
						continue;
					}
					
					//check target is within range
					if (targetDistance > maxRange) {
						turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
								+ target + " from " + source +", but the target is out of range.\n";
						continue;
					}

					//check to make sure they aren't bombing a sea zone
					if (territories.get(target).isOcean()) {
						turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
								+ target + " from " + source +", but the strike was aborted.  Sea zones are not valid targets!\n";
						continue;
					}
					
					//check to make sure they aren't bombing themselves
					if (factionName.equals(targetFaction)) {
						turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch a nuclear airstrike on " 
								+ target + " from " + source +", but the strike was aborted - that's their own territory!\n";
						continue;
					}
					
					
					//check interception
					//things that intercept: AA, Airfields, Rocketry(33-50),   Advanced Rocketry(50-66)
					
					//check if there's an airfield.
					//if yes, check jet planes and compare value to Airfield Interceptions
					//if valid, incriment airfield interceptions
					if (territories.get(target).isAirfield()) {
						int maxIntercepts = 1;
						//Decided against this bit, leaving it in, in case I change my mind
						//if (factions.get(targetFaction).getAllResearchedTech().contains("Jet Planes")) {
						//	maxIntercepts++;
						//}
						if (territories.get(target).getInterceptions() < maxIntercepts) {
							territories.get(target).incInterceptions();

							turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] launches a nuclear airstrike on " 
									+ target + " from " + source +", but [b]" + facSwap(targetFaction) 
									+ "[/b]'s Airfield manages to intercept the strike!\n";
							continue;
						}
					}
					//if no airfield or max intercepts has been achieved, check for AA
					//if aa, check rocketry and adv rocketry and roll for success
					//if fail, add the airstrike to the destroyedImprovements hashmap
					turnReportNukeAirstrike += "[b]" + facSwap(factionName) + "[/b] launches a nuclear airstrike on "
					+ target + " from " + source +"!";
					if (territories.get(target).isAa()) {
						int threshold = 2;
						if (factions.get(targetFaction).getAllResearchedTech().contains("Rocketry")) {
							threshold++;
						}
						if (factions.get(targetFaction).getAllResearchedTech().contains("Advanced Rocketry")) {
							threshold++;
						}
						int defensiveAARoll = factions.get(targetFaction).pullCard();
						
						turnReportNukeAirstrike += " [b]" + facSwap(targetFaction) 
								+ "[/b]'s AA Battery fires ("+threshold+" or lower needed: 1d6="+defensiveAARoll+")";
						
						if (defensiveAARoll <= threshold) {//successful! AA hits!
							turnReportNukeAirstrike += " and manages to repel the airstrike!\n";
							continue;
						}
						else {
							turnReportNukeAirstrike += " but the bombers get through.";
						}
					}
					
					//announce the airstrike and add to destroyedImprovements
					//check populous - set false and announce
					//randomly get 2 improvements to destroy - make sure they haven't already been destroyed by another nuke strike!!
					//kill half the units in the territory
					turnReportNukeAirstrike += " The bombs fall,";
					List<String> availableImprovements = territories.get(target).getAllImprovements();
					
					if (availableImprovements.size() > 0) { //so long as there's something to destroy...
						if (destroyedImprovements.containsKey(target)) { //check to see if it's already been hit
							for (String improv : destroyedImprovements.get(target)) { //if it has, remove things that have already been destroyed.
								availableImprovements.remove(availableImprovements.indexOf(improv));
							}
						}
						if (availableImprovements.size() > 0) { //checking again to make sure there's still something to destroy
							int toDestroyIndex = (int) (Math.random() * availableImprovements.size());
							String toDestroy = availableImprovements.get(toDestroyIndex);		
							
							if (destroyedImprovements.containsKey(target)) {
								destroyedImprovements.get(target).add(toDestroy);
							}
							else {
								List<String> destImprovList = new ArrayList<String>();
								destImprovList.add(toDestroy);
								destroyedImprovements.put(target, destImprovList);
							}
							
							availableImprovements.remove(toDestroyIndex);		
							turnReportNukeAirstrike += " destroying the " + toDestroy;
						}
						else {	turnReportNukeAirstrike += " but there are no improvements left to destroy";	}
						
						if (availableImprovements.size() > 0) { //second destroyed improvement
							int toDestroyIndex = (int) (Math.random() * availableImprovements.size());
							String toDestroy = availableImprovements.get(toDestroyIndex);		
							
							if (destroyedImprovements.containsKey(target)) {
								destroyedImprovements.get(target).add(toDestroy);
							}
							else {
								List<String> destImprovList = new ArrayList<String>();
								destImprovList.add(toDestroy);
								destroyedImprovements.put(target, destImprovList);
							}
							
							availableImprovements.remove(toDestroyIndex);			
							turnReportNukeAirstrike += " and the " + toDestroy;
						}
						turnReportNukeAirstrike += ".";
					}
					else {
						turnReportNukeAirstrike += " but there are no improvements to destroy.";
					}
					
					//populous check
					if (territories.get(target).isPopulous()) {
						turnReportNukeAirstrike += " " + target + " is no longer Populous as civilians flee the irradiated landscape!";
						territories.get(target).setPopulous(false);
					}
					
					//add the random amount of fallout
					int falloutAmount = factions.get(faction).pullCard();
					territories.get(target).addFallout(falloutAmount);
					if (falloutAmount > 1) {
						turnReportNukeAirstrike += " " + falloutAmount + " units of fallout settle on the territory.";
					}
					else {
						turnReportNukeAirstrike += " " + falloutAmount + " unit of fallout settles on the territory.";
					}
					
					//checking to see if any troops to destroy.
					//iterate through all factions
					//checking to see if any troops to destroy.
					//iterate through all factions
					for (String factionTemp : factions.keySet() ) {
						Set<Unit> endangeredUnits = factions.get(factionTemp).getUnitsIn(target); //do they have units in the territory?
						if (endangeredUnits != null) {
							int numToDestroy = (int) Math.floor(((double)endangeredUnits.size())/2);
							int i = 0;
							for (Unit unitToKill : endangeredUnits) {
								if (i < numToDestroy) {
									unitToKill.setToBeRemoved(true);
									i++;
								}
								else {
									break;
									}
							}
							if (numToDestroy > 1) {
								turnReportNukeAirstrike += " [b]" + facSwap(factionTemp) + "[/b] loses " + numToDestroy + " units.";
							}
							else {
								turnReportNukeAirstrike += " [b]" + facSwap(factionTemp) + "[/b] loses " + numToDestroy + " unit.";								
							}
						}
						//remove dead units from the factions army set
						Set<Unit> newArmy = new HashSet<Unit>();
						for (Unit unit : factions.get(faction).getUnits()) {
							if (!unit.isToBeRemoved()) {
								newArmy.add(unit);
							}
						}
						factions.get(faction).setUnits(newArmy);
					}
					turnReportNukeAirstrike += "\n";
					//end of this airstrike check.
					
					
				}//end of check
			}//end of order iteration
		}//end of faction iteration
		
		//run destroyedImprovements
		for (String key : destroyedImprovements.keySet()) {
			for (String improvement : destroyedImprovements.get(key)) {
				territories.get(key).destroyImprovement(improvement);
			}
		}
		
		return turnReportNukeAirstrike;
	}
	
	public static String parseAirstrike() {
		// airstrike
		// "airstrike - startzone# - endzone# - improvement"
		//check range, check target, check defense, check source, check diplomacy
		//Missile Railroad Academy Harbor HQ Fortifications Airfield AA(improvements)
		//"Long Range Aircraft"//Airfields range of 2. Airraids range of 2
		//"Jet Planes"//Airfields range of 3. Airraids range of 3. 
		//"Advanced Rocketry"//+1 to all attack rolls.
		String turnReportAirstrike = "";
		
		//since an airbase can be destroyed, first we verify orders and store the correct ones in destroyedImprovements.  Then we run it at the end and possibly bomb airfields.
		HashMap<String, List<String>> destroyedImprovements = new HashMap<String, List<String>>();
		
		//iterate through all factions
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders
			for (String orderLine : parsedOrders.get(factionName)) {
			
				if (orderLine.split(" ")[0].equals("airstrike")) {

					String[] splitLine = orderLine.split(" ");
					String faction = factionName;
					String source = splitLine[1];
					String target = splitLine[2];
					String improvement = splitLine[3];
					
					
					//get the owner of the territory
					String targetFaction = "";
					for (String key : factions.keySet()) {
						if (factions.get(key).checkOccupiedTerritory(target)) {
							targetFaction = key;
						}
					}
					
					//get max range for players bombers
					int maxRange = 1;
					if (factions.get(factionName).getAllResearchedTech().contains("Long Range Aircraft")) {	maxRange++;	}
					if (factions.get(factionName).getAllResearchedTech().contains("Jet Planes")) {	maxRange++;	}
					
					//get distance to target
					int targetDistance = territories.get(source).getDistanceToTarget(target);
										
					//make sure the source is valid (has airfield or fleet with carriers)
					//if it's a sea zone source....
					if (source.substring(0, 1).equals("s")) {
						//check to see if they have carriers researched...
						if (!factions.get(faction).getAllResearchedTech().contains("Aircraft Carriers")) {
							turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
									+ improvement + " in " + target + " from " + source +", but they don't have the Aircraft Carriers technology researched yet.\n";
							continue;
						}
						//check to see if they have fleets available
						if (factions.get(faction).fleetIn(source)) {
							boolean hasAvailableFleet = false;
							for (Fleet fleet : factions.get(faction).getFleetsIn(source)) {
								if (fleet.isAirstrike() == false) { //this fleet hasn't airstriked yet
									hasAvailableFleet = true;
									fleet.setAirstrike(true);
									break;
								}
							}
							//didnt have a fleet that hasnt airstrike yet
							if (hasAvailableFleet == false) {
								turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
										+ improvement + " in " + target + " from " + source +", but all carriers in that zone have already launched strikes.\n";
								continue;
							}
						}
						//didn't have a fleet in that zone to begin with
						else {
							turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
									+ improvement + " in " + target + " from " + source +", but they don't have a fleet in that zone to carry it out.\n";
							continue;
						}
					}
					//if it's a land source...
					else {
						if (territories.get(source).isAirfield()) { //if there's an airfield
							if (!territories.get(source).isLaunchedAirstrike()) { //haven't launched an airstrike yet
								territories.get(source).setLaunchedAirstrike(true);
							}
							else {
								turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
										+ improvement + " in " + target + " from " + source +", but that airfield has already launched a strike this turn.\n";
								continue;
							}
						}
						else {
							turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
									+ improvement + " in " + target + " from " + source +", but they don't have an airfield in that territory to launch the strike.\n";
							continue;
						}
					}
					
					//check diplomacy
					if (!factions.get(factionName).getDiplomacySpecific(targetFaction).equals("war")) {
						turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
								+ improvement + " in " + target + " from " + source +", but the strike was aborted since they're not actually at war with [b]" 
								+ facSwap(targetFaction) + "[/b].\n";
						continue;
					}
					
					//check target is within range
					if (targetDistance > maxRange) {
						turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
								+ improvement + " in " + target + " from " + source +", but the target is out of range.\n";
						continue;
					}
					
					//check to make sure they aren't bombing a sea zone
					if (territories.get(target).isOcean()) {
						turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on " 
								+ target + " from " + source +", but the strike was aborted.  Sea zones are not valid targets!\n";
						continue;
					}
					
					//check improvement exists
					if (!territories.get(target).hasImprovement(improvement)) {//territory does NOT have the improvement
						turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
								+ improvement + " in " + target + " from " + source +", but the target is nowhere to be found.\n";
						continue;
					}
					//check to make sure improvement hasn't already been hit
					if (destroyedImprovements.containsKey(target)) {
						if (destroyedImprovements.get(target).contains(improvement)) {
							turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
									+ improvement + " in " + target + " from " + source +", but it has already been destroyed!\n";
							continue;
						}
					}
					
					//check to make sure they aren't bombing themselves
					if (factionName.equals(targetFaction)) {
						turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] attempts to launch an airstrike on the " 
								+ improvement + " in " + target + " from " + source +", but the strike was aborted - that's their own territory!\n";
						continue;
						
					}
					
					
					//check interception
					//things that intercept: AA, Airfields, Rocketry(33-50),   Advanced Rocketry(50-66)
					
					//check if there's an airfield.
					//if yes, check jet planes and compare value to Airfield Interceptions
					//if valid, incriment airfield interceptions
					if (territories.get(target).isAirfield()) {
						int maxIntercepts = 1;
						//Decided against this bit, leaving it in, in case I change my mind
						//if (factions.get(targetFaction).getAllResearchedTech().contains("Jet Planes")) {
						//	maxIntercepts++;
						//}
						if (territories.get(target).getInterceptions() < maxIntercepts) {
							territories.get(target).incInterceptions();

							turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] launches an airstrike on the " 
									+ improvement + " in " + target + " from " + source +", but [b]" + facSwap(targetFaction) 
									+ "[/b]'s Airfield manages to intercept the strike!\n";
							continue;
						}
					}
					//if no airfield or max intercepts has been achieved, check for AA
					//if aa, check rocketry and adv rocketry and roll for success
					//if fail, add the airstrike to the destroyedImprovements hashmap
					turnReportAirstrike += "[b]" + facSwap(factionName) + "[/b] launches an airstrike on the "
					+ improvement + " in " + target + " from " + source +"!";
					if (territories.get(target).isAa()) {
						int threshold = 2;
						if (factions.get(targetFaction).getAllResearchedTech().contains("Rocketry")) {
							threshold++;
						}
						if (factions.get(targetFaction).getAllResearchedTech().contains("Advanced Rocketry")) {
							threshold++;
						}
						int defensiveAARoll = factions.get(targetFaction).pullCard();
						
						turnReportAirstrike += " [b]" + facSwap(targetFaction) 
								+ "[/b]'s AA Battery fires ("+threshold+" or lower needed: 1d6="+defensiveAARoll+")";
						
						if (defensiveAARoll <= threshold) {//successful! AA hits!
							turnReportAirstrike += " and manages to repel the airstrike!\n";
							continue;
						}
						else {
							turnReportAirstrike += " but the bombers get through.";
						}
					}
					
					//announce the airstrike and add to destroyedImprovements
					turnReportAirstrike += " The "+improvement+" has been destroyed!\n";
					
					if (destroyedImprovements.containsKey(target)) {
						destroyedImprovements.get(target).add(improvement);
					}
					else {
						List<String> destImprovList = new ArrayList<String>();
						destImprovList.add(improvement);
						destroyedImprovements.put(target, destImprovList);
					}
					
					
					//end of this airstrike check.
				}
			}  //end of orders for a faction
		}  //end of faction loop
		
		//run removeImprovement
		for (String key : destroyedImprovements.keySet()) {
			for (String improvement : destroyedImprovements.get(key)) {
				territories.get(key).removeImprovement(improvement);
			}
		}
		
		
		return turnReportAirstrike;
	}
	
	public static void fillVacantOrders() {
		for (String factionName : factions.keySet()) {
			boolean ordersExist = false;
			for (String factionOrders : parsedOrders.keySet()) {
				if (factionName.equals(factionOrders)) {
					ordersExist = true;
				}
			}
			if (ordersExist == false) {
				List<String> emptyList = new ArrayList<String>();
				emptyList.add("");
				parsedOrders.put(factionName, emptyList);
			}
		}
	}
	
	
	//###need to set the split to be "|" rather than white space
	public static String parseDiplomacy() {
		String turnReportDiplo = "";
		for (String factionName : parsedOrders.keySet()) {
			//iterate through their orders
			for (String orderLine : parsedOrders.get(factionName)) {
			
				//diplomacy attempt #2 - i know this is inefficient, but it's way better than my first attempt.
				//And no, I don't know why a nations stance with themselves changes.  please let me know if you figure it out.
				if (orderLine.split(" ")[0].equals("diplomacy")) {
					String[] splitLine = orderLine.split(" ");
					String source = factionName;
					String target = splitLine[1];
					String diplomacy = splitLine[2];
					
					//war
					if (diplomacy.equals("war")) {
						factions.get(source).changeDiplomacy(target, "war");
						factions.get(target).changeDiplomacy(source, "war");
						
						//checking to see if the war was mutual for the report and to clear it
						boolean mutual = false;
						for (String orderLine2 : parsedOrders.get(target)) {
							String[] splitLine2 = orderLine2.split(" ");
							if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) &&  splitLine2[2].equals("war")) {
								turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have declared war on one another!";
								int index = parsedOrders.get(target).indexOf(orderLine2);
								parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
								mutual = true;
							}
						}
						if (mutual == false) {
							turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] has declared war on [b]" + facSwap(target) +"[/b]!";
							for (String orderLine2 : parsedOrders.get(target)) {
								String[] splitLine2 = orderLine2.split(" ");
								if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) &&  splitLine2[2].equals("alliance")) {
									turnReportDiplo += "  [b]" + facSwap(target) + "[/b]'s attempts at an alliance are in vain.";
									int index = parsedOrders.get(target).indexOf(orderLine2);
									parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
								}
							}
							for (String orderLine2 : parsedOrders.get(target)) {
								String[] splitLine2 = orderLine2.split(" "); //this could be incorrect, but it requires them to ask for peace while already at peace (or declare war while at war)
								if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) &&  splitLine2[2].equals("peace")) {
									turnReportDiplo += "  [b]" + facSwap(target) + "[/b]'s attempts to peacefully break their alliance are in vain.";
									int index = parsedOrders.get(target).indexOf(orderLine2);
									parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
								}
							}
						}
						
						//check exchange, break if possible
						if (factions.get(source).breakExchangeTreaty(target) &&	factions.get(target).breakExchangeTreaty(source)) {
							turnReportDiplo += "\n -The Exchange Treaty between the two nations has been broken!";
						}
						
						
					}
					
					//peace
					else if (diplomacy.equals("peace")) {
						if (factions.get(source).getDiplomacySpecific(target).equals("alliance")) {
							factions.get(source).changeDiplomacy(target, "peace");
							factions.get(target).changeDiplomacy(source, "peace");
							//checking to see if breaking the alliance was mutual for the report and to clear it if it was
							boolean mutual = false;
							for (String orderLine2 : parsedOrders.get(target)) {
								String[] splitLine2 = orderLine2.split(" ");
								if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) && splitLine2[2].equals("peace")) {
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have mutually agreed to end their alliance with one another.";
									int index = parsedOrders.get(target).indexOf(orderLine2);
									parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
									mutual = true;
								}
								else if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) &&  splitLine2[2].equals("war")) {
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] attempts to peacefully end their alliance with [b]" + facSwap(target) + "[/b], but [b]" + facSwap(target) + "[/b] has declared war on them!";
									factions.get(source).changeDiplomacy(target, "war");
									factions.get(target).changeDiplomacy(source, "war");
									int index = parsedOrders.get(target).indexOf(orderLine2);
									parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
									mutual = true;
									//check exchange, break if possible
									if (factions.get(source).breakExchangeTreaty(target) &	factions.get(target).breakExchangeTreaty(source)) {
										turnReportDiplo += "\n -The Exchange Treaty between the two nations has been broken!";
									}
								}
							}
							if (mutual == false) {
								turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] has broken their alliance with [b]" + facSwap(target) +"[/b]!";
							}
							
							
						} else if (factions.get(source).getDiplomacySpecific(target).equals("war")) {
							//check to make sure they want peace, too
							boolean mutual = false;
							for (String orderLine2 : parsedOrders.get(target)) {
								String[] splitLine2 = orderLine2.split(" ");
								if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) &&  splitLine2[2].equals("peace")) {
									factions.get(source).changeDiplomacy(target, "peace");
									factions.get(target).changeDiplomacy(source, "peace");
									int index = parsedOrders.get(target).indexOf(orderLine2);
									parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have signed a peace treaty.";
									mutual = true;
								}
							}
							if (mutual == false) {
								turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] attempts to negotiate a ceasefire with [b]" + facSwap(target) +"[/b], but [b]" + facSwap(target) + "[/b] is unwilling to negotiate.";
							}
						}
					}
					
					//alliance
					else if (diplomacy.equals("alliance")) {
						//check to make sure they want alliance, too
						boolean mutual = false;
						for (String orderLine2 : parsedOrders.get(target)) {
							String[] splitLine2 = orderLine2.split(" ");
							if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) && splitLine2[2].equals("alliance")) {
								if (factions.get(source).getDiplomacySpecific(target).equals("war")) {
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have gone from enemies to allies! They have joined together in an alliance.";
								}
								else {
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have joined together in an alliance.";
								}
								factions.get(source).changeDiplomacy(target, "alliance");
								factions.get(target).changeDiplomacy(source, "alliance");
								int index = parsedOrders.get(target).indexOf(orderLine2);
								parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
								
								mutual = true;
							}
							else if (splitLine2[0].equals("diplomacy") && splitLine2[1].equals(source) && splitLine2[2].equals("war")) {
								turnReportDiplo += "\n[b]" + facSwap(target) + "[/b] has declared war on [b]" + facSwap(source) +"[/b]!";
								turnReportDiplo += "  [b]" + facSwap(source) + "[/b]'s attempts at an alliance are in vain.";
								factions.get(source).changeDiplomacy(target, "war");
								factions.get(target).changeDiplomacy(source, "war");
								int index = parsedOrders.get(target).indexOf(orderLine2);
								parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
								mutual = true;
							}
						}	
						if (mutual == false) {
							turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] attempts to negotiate an alliance with [b]" + facSwap(target) + "[/b], but their attempts are in vain.";
						}
					}
					
					//exchange
					else if (diplomacy.equals("exchange")) {
						//check to make sure they want exchange pact, too
						boolean mutual = false;
						for (String orderLine2 : parsedOrders.get(target)) {
							
							if (orderLine2.split(" ")[0].equals("diplomacy") && orderLine2.split(" ")[1].equals(source) && orderLine2.split(" ")[2].equals("exchange")) {
								//check to make sure both have available slots AND are not at war with each other AND they don't already have a pact with each other
								if (factions.get(source).checkExchangeTreatyAvailable(target) && factions.get(target).checkExchangeTreatyAvailable(source)) {
									if (!factions.get(source).getDiplomacySpecific(target).equals("war")) {
										factions.get(source).putExchangeTreaty(target);
										factions.get(target).putExchangeTreaty(source);
										turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have agreed to an Exchange Pact.";
										mutual = true;
									}		
									else {
										turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] attempt to sign an Exchange Pact, but the two nations are currently at war.";
										mutual = true;
									}
								}
								else {
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] attempt to sign a Exchange Pact, but are unable to at this time.";
									mutual = true;
								}
							}
							int index = parsedOrders.get(target).indexOf(orderLine2);
							parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
						}
						if (mutual == false) {
							turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] attempts to negotiate an Exchange Pact with [b]" + facSwap(target) + "[/b], but they seem uninterested.";
						}
					}
					
					//endexchange
					else if (diplomacy.equals("endexchange")) {
						if (factions.get(source).breakExchangeTreaty(target) && factions.get(target).breakExchangeTreaty(source)) {
							for (String orderLine2 : parsedOrders.get(target)) {
								if (orderLine2.split(" ")[0].equals("diplomacy") && orderLine2.split(" ")[1].equals(source) && orderLine2.split(" ")[2].equals("endexchange")) {
									int index = parsedOrders.get(target).indexOf(orderLine2);
									parsedOrders.get(target).set(index, ""); //their order has already been processed, so this prevents it from being repeated.
									turnReportDiplo += "\nBoth [b]" + facSwap(source) + "[/b] and [b]" + facSwap(target) + "[/b] have ended their Exchange Pact with one another.";
								}
								else {
									turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] has terminated their Exchange Pact with [b]" + facSwap(target) + "[/b].";
								}
							}
						}
						else {
							turnReportDiplo += "\n[b]" + facSwap(source) + "[/b] attempts to terminate their Exchange Pact with [b]" + facSwap(target) + "[/b], but the two are not currently engaged in an Exchange Pact.";
						}
					}	//end of endexchange
				}  //end of diplomacy search
			} //end of order loop
		} //end of all faction orders
		
		return turnReportDiplo;
	}
	
	public static List<String> facOrder(HashMap<String, Faction> factionMap) {
		int i = factionMap.size();
		List<String> factionsOrdered = new ArrayList<String>();
		for (int j = 1; j <= i; j++) {
			for (String key : factionMap.keySet()) {
				if (factionMap.get(key).getPriority() == j) {
					factionsOrdered.add(key);
				}
			}
		}
		return factionsOrdered;
	}

	public static String facSwap(String nation) {
		// denmark, greece, romania, yugoslavia, czechoslovakia, finland, sweden,
		// turkey, spain, germany, italy, uk, france, russia
		return factions.get(nation).getFactionName();
	}
	
	public static String readTextFile(String fileName) {
		String outPutString = "";
		String filePath = System.getProperty("user.dir") + "\\src\\TurnOrders\\" + fileName;
		try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			String sCurrentLine;
			while ((sCurrentLine = br.readLine()) != null) {
				outPutString += sCurrentLine + "\n";
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return outPutString;
	}
	
	
	

	 
 	
	public int getTurnNumber() {
		return turn;
	}
	public static void setTurnNumber(int Turn) {
		turn = Turn;
	}
	public static void incrimentTurn() {
		turn = turn++;
		incrimentMonth();
	}
	//###this month-year stuff is very specific.  Abstract it out, so users can decide how to name turns.
	public static int getYear() {
		return year;
	}
	public static void incrimentYear() {
		year = year + 1;
	}	
	public static void setYear(int Year) {
		year = Year;
	}
	public static String getMonth() {
		return month;
	}
	public static void setMonth(String Month) {
		month = Month;
	}
	public static void incrimentMonth() {
		if (month.equals("January")) {
			month = "February";
		} else if (month.equals("February")) {
			month = "March";
		} else if (month.equals("March")) {
			month = "April";
		} else if (month.equals("April")) {
			month = "May";
		} else if (month.equals("May")) {
			month = "June";
		} else if (month.equals("June")) {
			month = "July";
		} else if (month.equals("July")) {
			month = "August";
		} else if (month.equals("August")) {
			month = "September";
		} else if (month.equals("September")) {
			month = "October";
		} else if (month.equals("October")) {
			month = "November";
		} else if (month.equals("November")) {
			month = "December";
		} else if (month.equals("December")) {
			month = "January";
			incrimentYear();
		} 
	}
 	

	public void addFaction(String facName, String facShort, int priority, int r, int g, int b) {
		Faction tempFaction = new Faction();
		tempFaction.setFactionName(facName);
		tempFaction.setPriority(priority);
		tempFaction.setFactionColor(new Color(r, g, b));
		factions.put(facShort, tempFaction);
	}
	
	
	public Faction getFaction(String facName) {
		if (factions.get(facName) != null) {
			return factions.get(facName);
		} 
		return null;
	}
	
	public HashMap<String, Faction> getAllFactions() {
		return factions;
	}
	
	public void giveTechToFaction(String facName, String tech) {
		techs.get(tech).addFactionToTech(facName);
	}
	
	
	
}

