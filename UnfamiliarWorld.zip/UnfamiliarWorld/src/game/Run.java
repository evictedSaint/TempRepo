package game;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.awt.Color;
import javax.imageio.ImageIO;

public class Run {

	
	//private HashMap<Faction, List<String>> orders = new HashMap<Faction, List<String>>();

	private static Game game;
	

	public static void main(String[] args) throws IOException, ClassNotFoundException {
	    
		/* ###
		IDK where to put this, but I need to isolate game-specific icons and configs (improvements, techs, etc) into "save" files.
		Non-game-specific (numbers, letters, fallout, etc) should be in "game" files.  
		Separate these out later, would make it easier to slot in and out different game types.
		This ties into gameType config saves, so this should all be handled at once (or at least, gameType configs first)
		*/
		
		//Initializing the game, so we can test a turn.
		//###This should be the gameType - i.e. "unfamiliar world" or "age of steel" - which gametype config to look through.  
		//###Also need to modify the raws to hold these config files.
		Initializer.initializeAll(""); 
		Turn turn = new Turn(0, 1939, "December");  //###Months should probably be in some gameType config...basically, what turn-names are.
		
		turn.startRound();
	}
}
		
		
		
		/*
		//###need to reset all the fleet and unit movemnets for ALL factions 
		game.getTurn().getFaction("denmark").resetFleetMovement();
		game.getTurn().getFaction("germany").resetFleetMovement();
		game.getTurn().getFaction("france").resetFleetMovement();
		game.getTurn().getFaction("turkey").resetFleetMovement();
		*/
		
		/*
		//run the turn
		game.getTurn().startRound(game.getMap().getTerritoriesMap());
		game.getMap().putColors(game.getTurn().getAllFactions(), game.getTurn().getYear(), game.getTurn().getMonth());
		game.getMap().putNumbers("unfamiliar_world", game.getTurn().getYear(), game.getTurn().getMonth());
		game.getMap().putUnits(game.getTurn().getAllFactions(), game.getTurn().getYear(), game.getTurn().getMonth());
		game.getMap().putFleets(game.getTurn().getAllFactions(), game.getTurn().getYear(), game.getTurn().getMonth());
		System.out.println("Map drawn!");
		
		
		
		
		game.getTurn().getFaction("denmark");
		
		
	 }
	
		public static Turn getTurn() {
		return turn;
	}

	public static void setTurn(Turn turn) {
		Game.turn = turn;
	}
	
}
*/
