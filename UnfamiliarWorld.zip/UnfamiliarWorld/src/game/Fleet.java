package game;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Fleet implements Serializable {

	private List<String> moveList = new ArrayList<String>();
	private String current = "";
	private String previous = "";
	private boolean movedThisTurn = true;
	private boolean primed = false;
	private boolean airstrike = false;
	private boolean toBeRemoved = false;
	
	public Fleet(String spawnPoint) {

		String current = spawnPoint;
		String previous = spawnPoint;
		this.moveList.add(spawnPoint);
		this.primed = false;
		this.airstrike = false;
	}

	public List<String> getPrevCurr(int movePhase) {
		String current = "";
		String previous = "";
		//current
		if (moveList.size() >= movePhase+1) { //on a phase equal to or lower than the moves left
			current = moveList.get(movePhase);
		}
		else {									//fleet has moved as far as possible
			current = moveList.get(moveList.size()-1);
		}
		//previous
		if (movePhase == 0 ) {
			previous = current;
		}
		else {
			if (moveList.size() < movePhase+1) {
				previous = current;
			}
			else {
				previous = moveList.get(movePhase-1);
			}
		}
		this.previous = previous;
		this.current = current;
		List<String> prevCurr = new ArrayList<String>();
		prevCurr.add(previous);
		prevCurr.add(current);
		return prevCurr;
	}
	
	public String getCurrent() {
		return current;
	}

	public void setCurrent(String current) {
		this.current = current;
	}

	public String getPrevious() {
		return previous;
	}

	public void setPrevious(String previous) {
		this.previous = previous;
	}

	public boolean isToBeRemoved() {
		return toBeRemoved;
	}
	
	public void setToBeRemoved(boolean toBeRemoved) {
		this.toBeRemoved = toBeRemoved;
	}

	public List<String> getMoveList() {
		return moveList;
	}

	public void setMoveList(List<String> moveList) {
		this.moveList = moveList;
	}

	public boolean isMovedThisTurn() {
		return movedThisTurn;
	}

	public void setMovedThisTurn(boolean movedThisTurn) {
		this.movedThisTurn = movedThisTurn;
	}

	public boolean isPrimed() {
		return primed;
	}

	public void setPrimed(boolean primed) {
		this.primed = primed;
	}

	public boolean isAirstrike() {
		return airstrike;
	}

	public void setAirstrike(boolean airstrike) {
		this.airstrike = airstrike;
	}
	
}
