package game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FactionsManager extends Game {
	
	private static String factionsDirectory = System.getProperty("user.dir") + "\\src\\raws\\";
	
	public FactionsManager() {
	}
	
	public static void initializeFactions(String gameType) {
		loadFactions(factionsDirectory + gameType + "factions"); //###gonna need to mod this when I isolate gameType saves...
		baseNeutrality();
	}
	
		
	private static void loadFactions(String loadFile) {
		File dir = new File(loadFile);
		File[] dirListing = dir.listFiles();
		if (dirListing != null) {
			for (File factionChild : dirListing) {
				if (factionChild.isFile()) { //make sure this is actually a file, not a directory that somehow found its way in
					
					Faction newFaction = new Faction();
					String factionRaw = "";
					try {
						factionRaw = readFile(factionChild.getPath());
					} catch (IOException e) {
						e.printStackTrace();
					}
					if (!factionRaw.isEmpty()) {
						try {
							newFaction.parseFaction(factionRaw);
							factions.put(newFaction.getFactionName(), newFaction);							
						} 
						catch (Exception e) {
							System.out.println("Error reading loading Faction - unable to parse."); //###These system.out's really need to be replaced with logs.
						}
					}
				}
			}
		}
		else {
			System.out.println("Warning: No faction files found in raw/factions!");
		}		
	}
	
	private static void baseNeutrality() {

		//setting neutrality for all factions with all other factions, if no diplomacy is already set.
		for (Faction faction1 : factions.values()) {
			for (Faction faction2 : factions.values()) {
				if (faction1.getFactionName() != faction2.getFactionName()) {
					if (!faction1.getDiplomacy().containsKey(faction2.getFactionName()) || (faction1.getDiplomacy().get(faction2.getFactionName()) == null)) { 
						//if faction2 isn't listed in faction1's diplomacy map, OR if they are listed but don't have a value, then they need to be initialized as neutral:
						faction1.changeDiplomacy(faction2.getFactionName(), "neutral");
					}
				}
			}
		}
	}
	
	
	//this code stolen from: https://stackoverflow.com/questions/4716503/reading-a-plain-text-file-in-java
	private static String readFile(String fileName) throws FileNotFoundException, IOException { //###string appending is slow and silly.  I should switch to Apache IOUtils when I get the chance. see link above.
		String everything = "";
		try(BufferedReader br = new BufferedReader(new FileReader(fileName))) {
		    StringBuilder sb = new StringBuilder();
		    String line = br.readLine();

		    while (line != null) {
		        sb.append(line);
		        sb.append(System.lineSeparator());
		        line = br.readLine();
		    }
		    everything = sb.toString();
		}
		catch(Exception e) {
			System.out.println("Could not read factions file: " + fileName);
			e.printStackTrace();
		}
		return everything;
	}
	
	
	public static void addFaction(Faction faction) {
		factions.put(faction.getFactionName(), faction);
	}
	
	public static void removeFaction(String faction) {
		factions.remove(faction);
	}
	
	public static void setFactions(HashMap<String, Faction> factions) {
		Game.factions = factions;
	}



}