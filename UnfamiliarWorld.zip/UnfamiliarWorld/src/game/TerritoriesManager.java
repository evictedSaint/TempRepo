package game;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TerritoriesManager extends Game {

	//###the game map and coords should be isolated in a file you can swap in and out other than just "maps"
	private static String territoryDirectory = System.getProperty("user.dir") + "\\src\\raws\\";
	//###Need to move most of the Map class over to this class.  Map shouldnt be doing all the building.
	
	
	public TerritoriesManager() {
		
	}
	
	public static void initializeTerritories(String gameType) {
		loadTerritories(gameType);
		populateImprovements(); //###this could probably be skipped, if it's more intelligently handled.  Would remove the improvement-territory dependency.
	}
	
	//This fills each territory's improvement hashmap with all the improvements - by default, should be blank.
	//###is this really necessary?  Could this be skipped - add improvements to a territory's hashmap as they appear, checking to see if it exists/is true?
	private static void populateImprovements() {
		for (Territory territory : territories.values()) {
			territory.populateImprovements(improvements);
		}
	}

	private static void loadTerritories(String gameType) {
		String mapDirectoryPath = territoryDirectory + gameType + "\\maps\\" + gameType + "_coordinates.txt";  //###not really a fitting variablename.  Find something more suitable later.
		File dir = new File(mapDirectoryPath);
		
		//read all the territory txt files in the directory
		if (dir.isDirectory()) {
			File[] dirListing = dir.listFiles();
			String territoriesRaw = "";
			if (dirListing != null) {
				for (File territoryChild : dirListing) {
					if (territoryChild.isFile()&&Pattern.compile(".*?\\.txt$").matcher(territoryChild.getName()).find()) { //make sure the files we are looking at are .txt files
					
						try (BufferedReader br = new BufferedReader(new FileReader(territoryChild.getPath()))) {
							String sCurrentLine;
							while ((sCurrentLine = br.readLine()) != null) {
								territoriesRaw += sCurrentLine;
							}
						} catch (FileNotFoundException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}
			}
			else {
				System.out.println("Map Directory '" + mapDirectoryPath + "' is empty. Unable to buildTerritoryList.");
			}
				
			//now we parse each line and add the territories to the list
			String tokenRegex = ".*?\\[(.*?)\\].*?";
			Matcher match = Pattern.compile(tokenRegex).matcher(territoriesRaw);

			List<Integer> temp = new ArrayList<Integer>();
			if (match.find()) {
				do {
					String[] token = match.group(1).split(":");
					
					Territory thisTerritory = new Territory();
					try {
						switch(token[0]) {
						//base values    
						case "id":
							if (!thisTerritory.getID().equals("")) {
								addTerritory(thisTerritory);
							}
							thisTerritory = new Territory();
							thisTerritory.setID(token[1]);
							break;				
						case "regex":
							thisTerritory.setRegex(match.group(1).substring(match.group(1).indexOf(":")+1));
							break;
						case "xcoord":
							thisTerritory.setxCoord(Integer.valueOf(token[1]));
							break;
						case "ycoord":
							thisTerritory.setyCoord(Integer.valueOf(token[1]));
							break;
						case "adjacent":
							for (int i = 1; i < token.length; i++) {
								thisTerritory.addConnectedTerritory(token[i]);
							}
							break;
						case "chokepoint":
							for (int i = 1; i < token.length; i++) {
								thisTerritory.addConnectedChokepoint(token[i]);
							}
							break;
						case "impassable":
							for (int i = 1; i < token.length; i++) {
								thisTerritory.addConnectedImpassable(token[i]);
							}
							break;
						}	
						addTerritory(thisTerritory);
					} catch(Exception e) {
						System.out.println("Error reading territory file: " + territoriesRaw);
					}
					
				} while (match.find());
			}
			
			//now we make the territories find the distances between one another
			for (String key : territories.keySet()) {
				territories.get(key).setDistanceMap(territories);
			}
		}
	}
								

	public static void addTerritory(Territory territory) {
		territories.put(territory.getID(), territory);
	}
	
	public static void removeTerritory(String territory) {
		territories.remove(territory);
	}
	
	public static void setTerritories(HashMap<String, Territory> territories) {
		Game.territories = territories;
	}
	
	
}
	
	

