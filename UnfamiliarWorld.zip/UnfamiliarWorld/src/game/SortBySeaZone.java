package game;

import java.util.Comparator;

public class SortBySeaZone implements Comparator<String> { 	
	public SortBySeaZone( ) {
	}

	@Override
	public int compare(String sz1, String sz2) {
		
		int SZ1 = Integer.parseInt(sz1.substring(2));
		int SZ2 = Integer.parseInt(sz2.substring(2));
		
		if (SZ1 < SZ2) return -1;
		else if (SZ1 == SZ2) return 0;
		else return 1;
	}
}