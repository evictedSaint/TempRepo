package GameEngine;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import ComponentClasses.Weapon.WeaponType;  

public class SaveManager {
	
	
	
	/* What all do we need to have the save manager handle?
	 * 
	 * 
	 * We need a repository of game files, which is the "overall" save.  This holds distances, repair time, etc, and points to the additional saves which make up this save.
	 * We need a repository of gamemodes, which contain component classes.
	 * We need a repository of ship objects, which contain their sections and shipcomponents and whatnot.
	 * 
	 */

	private static String saveString = System.getProperty("user.dir") + "\\src\\Saves"; //the save directory
	
	//Game Files 
	public static boolean saveGameFile(Game game, String gameName) {
		checkSaveDirectories(gameName);
		GsonBuilder builder = new GsonBuilder(); 
		Gson gson = builder.setPrettyPrinting().create(); 
		
		FileWriter writer;
		try {
			//making a saveslot.  If one already exists, we make a new one with the append "_n+1" and start fresh.
			File turnSaveSlot = new File(saveString + "\\SavedGames\\" + gameName + "\\turn_" + Game.turn + ".json");
			//this "if" ensures the save name is unique
			if (turnSaveSlot.exists() && !turnSaveSlot.isDirectory()) {
				boolean saveSlotFound = false;
				int version = 1;
				while (!saveSlotFound) {
					turnSaveSlot = new File(saveString + "\\SavedGames\\" + gameName + "\\turn_" + Game.turn + "_" + version + ".json");
					if (turnSaveSlot.exists() && !turnSaveSlot.isDirectory()) {
						version++;
					}
					else {
						saveSlotFound = true;
					}
				}
			}
			//now to actually write the file.
			writer = new FileWriter(turnSaveSlot);
			//prepareGameForSave(game);
			writer.write(gson.toJson(game));   
			writer.close(); 
			//
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}   
			   
		return true;
	}
	
	
	
	public boolean loadGameFile(String gameName, String saveName) {
		//gameName is the subfolder under SavedGames, which is all of the same game.
		//saveName is the specific gson save in that subfolder - this lets you load "earlier" saves, in case of errors.
		GsonBuilder builder = new GsonBuilder(); 
		Gson gson = builder.create(); 
		try {
			BufferedReader bufferedReader = new BufferedReader(new FileReader("student.json"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}   
		  
		//Student student = gson.fromJson(bufferedReader, Student.class); 
		
		return true;
	}
	
	

	public static void clearVariablesForSave() {
		for (Ship s : Game.ships) {
			s.report = "";
		}
	}
	
	
	public static void checkSaveDirectories(String gameName) {
		//checking to make sure the save directory (and subfolders) exists...
		File saveDirectory = new File(saveString);
		if (!saveDirectory.exists() || !saveDirectory.isDirectory()) { 
			new File(saveString).mkdir();
			new File(saveString + "\\GameModes").mkdir();
			new File(saveString + "\\SavedGames").mkdir();
		}

		//checking to see if the gametype directories we need exist...
		File gameTypeSaveDirectory = new File(saveString + "\\SavedGames\\" + gameName);
		if (!gameTypeSaveDirectory.exists() || !gameTypeSaveDirectory.isDirectory()) { //if the file directory for this gameName doesn't exist (and checking to make sure we're dealing with a directory)
			//expect to do this on the very first initial save
			new File(saveString + "\\SavedGames\\" + gameName).mkdir();
		} 
	}
	
	/*
		
		
		
	}
}

	 */
	
	
	//GameModes
	public boolean saveGameMode(String gameModeName) {
		
		return true;
	}
	
	public boolean loadGameMode(String gameModeName) {
		
		
		return true;
	}
	
	//Ships
	public boolean saveShip(Ship ship) {
		
		return true;
	}
	
	public boolean loadShip(String shipName) {
		
		return true;
	}
}
