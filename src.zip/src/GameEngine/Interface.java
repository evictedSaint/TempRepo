package GameEngine;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Interface {
	/** Please note that this is my first time implementing Swing, or really any
	 * dedicated java gui.  If this is written poorly, know that I'm doing my best.
	 * 
	 */
	public static void Interface() {
		
		HomePage();
		
	}
	
	public static void HomePage() {
		JFrame mainFrame = new JFrame("Dreadnoughts " + Game.version);
		JPanel controlPanel = new JPanel();
		JPanel buttonPanel = new JPanel();

		GridLayout buttonLayout = new GridLayout(0, 1, 10, 15);
		
		controlPanel.setLayout(new FlowLayout());
		buttonPanel.setLayout(buttonLayout);
		
		JButton ng = new JButton("New Game");
		JButton lg = new JButton("Load Game");
		JButton dg = new JButton("Delete Game");
		JButton ngm = new JButton("New GameMode");
		
		ng.setSize(100, 30);
		lg.setSize(100, 30);
		dg.setSize(100, 30);
		ngm.setSize(100, 30);
		
		buttonPanel.add(ng);
		buttonPanel.add(lg);
		buttonPanel.add(dg);
		buttonPanel.add(ngm);
		
		mainFrame.add(controlPanel);
		controlPanel.add(buttonPanel);
		buttonPanel.setVisible(true);
		
		mainFrame.setSize(400, 500);
		mainFrame.setVisible(true);
		mainFrame.setLocationRelativeTo(null); //puts window in center of screen
		
		ng.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//action
			}
		});
		
		lg.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//action
			}
		});

		dg.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//action
			}
		});

		ngm.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//action
			}
		});
	}

}
