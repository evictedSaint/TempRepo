package GameEngine;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import ComponentClasses.Weapon.WeaponType;

public class Game implements Serializable {
	

	protected static Game single_instance = null;
	
	
	
	public static String version = "v0.1.0";

	
	//I am aware this sucks.  I got downvoted to hell when I asked how to make it better on stackoverflow, so sue me.
	public static List<Ship> ships = new ArrayList<Ship>();
	
	public static int damconTime = 2;

	public static int turn = 0;
	
    public static int repairTime = 3;

    public static HashMap<String, HashMap<WeaponType, Integer>> bankDefenseProjectileTypeDamage = new HashMap<String, HashMap<WeaponType, Integer>>();

    public static HashMap<Integer, String> distances = new HashMap<Integer, String>();
    
    //Do not modify this enum, it will break the Damage/Repair sections elsewhere.
    public enum Status
    {
        INTACT,
        DAMAGED,
        REPAIRING,
        JURY_RIGGED,
        RIGGING,
        DESTROYED,
        OBLITERATED
    }
    
    
    
    
    //Singleton stuff ========================
    public static Game getInstance() 
    { 
        if (single_instance == null) 
            single_instance = new Game(); 
  
        return single_instance; 
    } 
    
    protected Object readResolve() 
    { 
        return single_instance; 
    } 
    //end singleton stuff=======================
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    public Game() {
    	//TODO: this is a bit of a placeholder, should be handled by the gameModes
    	int counter = 6;
    	for (String s : Arrays.asList("EXTREME", "VERY LONG", "LONG", "MEDIUM", "SHORT", "CLOSE", "MELEE")) { //the further the distance, the higher the number.  closest is 0.
    		distances.put(counter, s);
    		counter--;
    	}
    	
    	MapManager.distances = this.distances;
    }

    public void test() {
    	ships.add(new Ship(version, version, version));
    	
    }
}
