package GameEngine;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import ComponentClasses.Defense;
import ComponentClasses.DefenseRolling;

public class Turn {

	
	
	/*
	 * 
	 * I'd allow some degree of aiming at Sections, each weapon would have a Heavy version that shot 
	 * less but penetrated defences,and there be an additional base cost per Sector when designing a
	 *  ship. Finally I wanted to make it possible to hit Internals before Extendable.  Each of those 
	 *  should help counter the "bigger is better than more" problem
	 * 
	 * 
It is as follows:
1. Weapons fire 
2. DC, Jumps, Long range Missiles tick
3. Weapon hit rolls
4. Countermeasures (PD, Shields, then Armor, blocking preferred projectile first)
5. Weapon damage
6. Check DC, and Jump completion criteria
7. Reset all ShipComponent miscCounters
Thus, a just-completed jump or repair attempt could get disrupted by enemy fire
	 */
	
	public void runTurn() {
		
	}
	
	public void parseCommands(String commandBlock) {
		/* Possible commands:
		 * 
		 * 1) fire - target.
		 * 2) turn on/off component via section.
		 * 3) turn on/off damcon via section.
		 * 4) move towards/away from target.
		 * 
		 * 1) Fire - shipname
		 * 2) Power - on/off - section - component
		 * 3) Damcon - on/off - section - component
		 * 4) Move - towards/away - shipname - distance(optional)
		 *
		 * 
		 */
		HashMap<String, HashMap<String, List<List<String>>>> commands = new HashMap<String, HashMap<String, List<List<String>>>>(); //ship, commandtype, commands, command components 
		
		
		
	}
	
	public void weaponsFire() {
		
	}
	
	public void damageControlInitializeAndtick() {
		
	}
	
	public void jumpInitializeAndTick() {
		
	}
	
	public static void hitsAndDefense() {
		/* So, each ship keeps track of the projectiles fired at it.
		 * 
		 * Currently, defenses are measured in three tiers:
		 * 1) Die roll defenses
		 * 2) Banked defenses
		 * 3) Static defenses
		 * 
		 * We process countermeasures by ship, by tier, by defense preference. 
		 */
		
		String counterMeasuresReport = "[spoiler=Action Report]";
		
		for (Ship s : Game.ships) {
			
			
			if (!s.isAlive) { //we don't process damage for dead ships
				continue;
			}
			
			counterMeasuresReport += "\n[b]" + s.team + " " + s.shipName + " (" + s.playerName + ")[/b]\n";
			
			// hits, defense, etc.
			counterMeasuresReport += s.projectilesHit() + "\n[hr]\n";
		}
		counterMeasuresReport += "[/spoiler]";
		
		System.out.println(counterMeasuresReport);
		
	}
	
	
	public void projectileTick() {
		
	}
	
	public void damageControlResolve() {
		
	}
	
	public void jumpResolve() {
		
	}
}
