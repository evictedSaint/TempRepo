package ComponentClasses;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import GameEngine.Game;

public class Component {
	
	
	public String componentName;
	
	public int powerRequirement = 0;
	
	public boolean canBeDamaged = true; //means this component is a viable target when dealing damage. TODO: this isn't used.
	public boolean repairable = true;
	
	public boolean augmentSlot = false;
	
	/*public enum Type {
		GENERIC,
		POWERSUPPLY,
		PASSIVEDEFENSE,
		WEAPON,
		DEFENSE,
		JUMPDRIVE,
		AUGMENT
	}*/
	
	
	public Component(String componentName) {
		this.componentName = componentName;
	}

}

