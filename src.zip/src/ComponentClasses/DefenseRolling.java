package ComponentClasses;

import java.util.HashMap;

import ComponentClasses.Weapon.WeaponType;
import GameEngine.Game.Status;

public class DefenseRolling extends Defense {

	public HashMap<Status, HashMap<WeaponType, Integer>> projectileTypeRoll = new HashMap<Status, HashMap<WeaponType, Integer>>(); //weapon type, roll required 
	
	public boolean shutsDownOnSuccess = true; //i.e. can this defense be used multiple times in a turn.	
	public int stackingMalus = 0; //penalty to each following defense attempt.  Positive=more effective, negative=less effective.
		
	/** Like Point Defense.
	 */
	public DefenseRolling(String componentName) {
		super(componentName);

		HashMap<WeaponType, Integer> tempHashMap = new HashMap<WeaponType, Integer>();
		for (WeaponType wt : WeaponType.values()) {
			tempHashMap.put(wt, 0);
		}
		for (Status s : Status.values()) {
			HashMap<WeaponType, Integer> tempHashMap1 = new HashMap<WeaponType, Integer>();
			tempHashMap1.putAll(tempHashMap);
			projectileTypeRoll.put(s, tempHashMap1);
		}
	}
}
